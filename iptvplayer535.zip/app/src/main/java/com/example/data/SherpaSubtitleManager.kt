package com.example.data

import android.app.ActivityManager
import android.content.Context
import android.os.Handler
import android.os.Looper
import android.util.Log
import androidx.media3.common.C
import androidx.media3.common.audio.AudioProcessor
import androidx.media3.common.audio.BaseAudioProcessor
import com.example.debug.GlobalDebugSystem
import com.k2fsa.sherpa.onnx.EndpointConfig
import com.k2fsa.sherpa.onnx.FeatureConfig
import com.k2fsa.sherpa.onnx.OnlineModelConfig
import com.k2fsa.sherpa.onnx.OnlineRecognizer
import com.k2fsa.sherpa.onnx.OnlineRecognizerConfig
import com.k2fsa.sherpa.onnx.OnlineStream
import com.k2fsa.sherpa.onnx.OnlineTransducerModelConfig
import com.k2fsa.sherpa.onnx.getEndpointConfig
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.asCoroutineDispatcher
import kotlinx.coroutines.channels.BufferOverflow
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File
import java.io.FileOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicLong
import kotlin.math.sqrt

/**
 * Informations sur un modèle vocal Sherpa-ONNX streaming zipformer
 */
data class SherpaModelInfo(
    val id: String,
    val code: String,
    val name: String,
    val size: String,
    val baseUrl: String,
    val dirName: String,
    val fileNames: List<String>
) {
    val displayName: String get() = name
    val sizeDescription: String get() = size
}

typealias VoskModelInfo = SherpaModelInfo

/**
 * Gestionnaire de sous-titrage vocal haute précision et synchronisé basé sur Sherpa-ONNX.
 * Remplace Vosk pour une transcription continue, fluide et parfaitement synchronisée avec la vidéo.
 */
object SherpaSubtitleManager {
    private const val TAG = "SherpaSubtitleMgr"
    private const val SAMPLE_RATE = 16000

    val allModels = mapOf(
        "fr" to "sherpa-onnx-streaming-zipformer-fr-2023-04-14",
        "en" to "sherpa-onnx-streaming-zipformer-en-20M-2023-02-17",
        "ar" to "sherpa-onnx-streaming-zipformer-ar_en_id_ja_ru_th_vi_zh-2025-02-10",
        "es" to "sherpa-onnx-streaming-zipformer-fr-2023-04-14",
        "de" to "sherpa-onnx-streaming-zipformer-en-20M-2023-02-17",
        "it" to "sherpa-onnx-streaming-zipformer-fr-2023-04-14",
        "pt" to "sherpa-onnx-streaming-zipformer-fr-2023-04-14",
        "tr" to "sherpa-onnx-streaming-zipformer-en-20M-2023-02-17",
        "ru" to "sherpa-onnx-streaming-zipformer-ar_en_id_ja_ru_th_vi_zh-2025-02-10"
    )

    val AVAILABLE_MODELS = listOf(
        SherpaModelInfo(
            id = "fr",
            code = "fr",
            name = "Français (Zipformer FR)",
            size = "~128 Mo",
            baseUrl = "https://huggingface.co/shaojieli/sherpa-onnx-streaming-zipformer-fr-2023-04-14/resolve/main/",
            dirName = "sherpa-onnx-streaming-zipformer-fr-2023-04-14",
            fileNames = listOf(
                "tokens.txt",
                "encoder-epoch-29-avg-9-with-averaged-model.int8.onnx",
                "decoder-epoch-29-avg-9-with-averaged-model.int8.onnx",
                "joiner-epoch-29-avg-9-with-averaged-model.int8.onnx"
            )
        ),
        SherpaModelInfo(
            id = "en",
            code = "en",
            name = "Anglais (Zipformer EN 20M)",
            size = "~44 Mo",
            baseUrl = "https://huggingface.co/csukuangfj/sherpa-onnx-streaming-zipformer-en-20M-2023-02-17/resolve/main/",
            dirName = "sherpa-onnx-streaming-zipformer-en-20M-2023-02-17",
            fileNames = listOf(
                "tokens.txt",
                "encoder-epoch-99-avg-1.int8.onnx",
                "decoder-epoch-99-avg-1.int8.onnx",
                "joiner-epoch-99-avg-1.int8.onnx"
            )
        ),
        SherpaModelInfo(
            id = "ar",
            code = "ar",
            name = "Arabe & Multilingue (Zipformer)",
            size = "~339 Mo",
            baseUrl = "https://huggingface.co/csukuangfj/sherpa-onnx-streaming-zipformer-ar_en_id_ja_ru_th_vi_zh-2025-02-10/resolve/main/",
            dirName = "sherpa-onnx-streaming-zipformer-ar_en_id_ja_ru_th_vi_zh-2025-02-10",
            fileNames = listOf(
                "tokens.txt",
                "bpe.model",
                "encoder-epoch-75-avg-11-chunk-16-left-128.int8.onnx",
                "decoder-epoch-75-avg-11-chunk-16-left-128.onnx",
                "joiner-epoch-75-avg-11-chunk-16-left-128.int8.onnx"
            )
        )
    )

    // États observables pour l'UI
    private val _isDownloadingModel = MutableStateFlow(false)
    val isDownloadingModel: StateFlow<Boolean> = _isDownloadingModel.asStateFlow()

    private val _downloadProgress = MutableStateFlow(0f)
    val downloadProgress: StateFlow<Float> = _downloadProgress.asStateFlow()

    private val _downloadStatusMessage = MutableStateFlow<String?>(null)
    val downloadStatusMessage: StateFlow<String?> = _downloadStatusMessage.asStateFlow()

    private val _selectedVoiceModelId = MutableStateFlow("fr")
    val selectedVoiceModelId: StateFlow<String> = _selectedVoiceModelId.asStateFlow()

    private val _isVoiceRecognitionActive = MutableStateFlow(false)
    val isVoiceRecognitionActive: StateFlow<Boolean> = _isVoiceRecognitionActive.asStateFlow()

    private val _recognizedSpeechText = MutableStateFlow<String?>(null)
    val recognizedSpeechText: StateFlow<String?> = _recognizedSpeechText.asStateFlow()

    private val _isSpeechDetected = MutableStateFlow(false)
    val isSpeechDetected: StateFlow<Boolean> = _isSpeechDetected.asStateFlow()

    private val _syncOffsetMs = MutableStateFlow(0)
    val syncOffsetMs: StateFlow<Int> = _syncOffsetMs.asStateFlow()

    private val _isAutoCalibrationEnabled = MutableStateFlow(true)
    val isAutoCalibrationEnabled: StateFlow<Boolean> = _isAutoCalibrationEnabled.asStateFlow()

    private val _autoCalibratedOffsetMs = MutableStateFlow(0)
    val autoCalibratedOffsetMs: StateFlow<Int> = _autoCalibratedOffsetMs.asStateFlow()

    private val _autoClearDelaySeconds = MutableStateFlow(6)
    val autoClearDelaySeconds: StateFlow<Int> = _autoClearDelaySeconds.asStateFlow()

    private val _isIntelligentDurationEnabled = MutableStateFlow(true)
    val isIntelligentDurationEnabled: StateFlow<Boolean> = _isIntelligentDurationEnabled.asStateFlow()

    private val _isStreamingMode = MutableStateFlow(true)
    val isStreamingMode: StateFlow<Boolean> = _isStreamingMode.asStateFlow()

    // Gestion interne du moteur Sherpa-ONNX
    private var currentRecognizer: OnlineRecognizer? = null
    private var currentStream: OnlineStream? = null
    private var currentLoadedLanguage: String? = null
    private val recognizerLock = Any()
    private val downloadMutex = Mutex()

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    // Dispatcher dédié en arrière-plan optimisé pour Google TV & Smartphone (priorité normale pour ne pas être bridé par le kernel TV)
    private val recognitionDispatcher = java.util.concurrent.Executors.newSingleThreadExecutor { runnable ->
        Thread(runnable, "SherpaWorkerThread").apply {
            priority = Thread.NORM_PRIORITY
        }
    }.asCoroutineDispatcher()

    // Canal audio séquentiel non bloquant (capacité 64 pour absorber les pics CPU sur TV sans perte)
    private val audioProcessingChannel = Channel<FloatArray>(
        capacity = 64,
        onBufferOverflow = BufferOverflow.DROP_OLDEST
    )
    private var workerJob: Job? = null
    private var loadModelJob: Job? = null
    private var activeDownloadJob: Job? = null
    private var activeDownloadModelId: String? = null
    private val isResetRequested = AtomicBoolean(false)

    // Accumulateur d'échantillons float (100ms = 1600 float samples @ 16kHz)
    private val sampleAccumulator = FloatArray(6400)
    private var sampleAccumulatorSize = 0
    private val sampleLock = Any()
    @Volatile private var lastAudioFeedTime = 0L
    @Volatile private var lastPartialText = ""

    // Jobs de temporisation pour l'affichage
    private var autoClearJob: Job? = null
    private var delayedEmitJob: Job? = null

    // Callbacks demandés par l'utilisateur
    private var onPartialListener: ((text: String) -> Unit)? = null
    private var onFinalListener: ((text: String, startTime: Float, endTime: Float) -> Unit)? = null
    private var onSpeechResultListener: ((rawText: String) -> Unit)? = null

    @Volatile private var appContext: Context? = null

    private val httpClient by lazy {
        OkHttpClient.Builder()
            .connectTimeout(60, TimeUnit.SECONDS)
            .readTimeout(300, TimeUnit.SECONDS)
            .writeTimeout(60, TimeUnit.SECONDS)
            .retryOnConnectionFailure(true)
            .followRedirects(true)
            .followSslRedirects(true)
            .build()
    }

    @Volatile private var isRecognizerReady = false
    @Volatile private var isStreamReady = false

    // Les callbacks UI sont postés sur le thread principal SANS bloquer le worker audio
    // (l'ancien withContext(Main) faisait attendre le décodage quand l'UI TV était chargée -> perte d'audio).
    private val mainHandler = Handler(Looper.getMainLooper())

    // Ligne à retard : chaque résultat est numéroté, les résultats périmés (reset/seek) sont ignorés
    private val emitSequence = AtomicLong(0)
    private val emitLock = Any()
    private var lastEmittedSequence = 0L
    @Volatile var lastEmittedIsFinal: Boolean = false
        private set

    // Gain adaptatif lissé (évite le "pompage" du gain d'un chunk à l'autre)
    private var agcGain = 1.0f

    private val standaloneEnglishI = Regex("\\bi\\b")

    // ---- Diagnostic affiché à l'écran (utile sur TV où il n'y a pas de logcat) ----
    @Volatile private var diagFormat = "format audio inconnu"
    @Volatile private var diagInputCalls = 0L
    @Volatile private var diagChunksQueued = 0L
    @Volatile private var diagChunksDecoded = 0L
    @Volatile private var diagLastRms = 0f
    private val _diagnostics = MutableStateFlow("")
    val diagnostics: StateFlow<String> = _diagnostics.asStateFlow()

    // ---- Chargement du modèle : file unique (jamais deux chargements en parallèle) ----
    private val loadMutex = Mutex()
    @Volatile private var requestedModelId: String? = null
    @Volatile private var loadingSinceMs = 0L
    @Volatile private var lastLoadError: String? = null
    @Volatile private var loadFailures = 0
    @Volatile private var nativeLibError: String? = null

    private fun buildDiagnostics(): String {
        val loaded = synchronized(recognizerLock) { currentRecognizer != null && isRecognizerReady }
        val model = when {
            _isDownloadingModel.value -> "téléchargement…"
            loaded -> "prêt (${currentLoadedLanguage ?: "?"})"
            loadingSinceMs > 0L -> "chargement en cours (${(System.currentTimeMillis() - loadingSinceMs) / 1000} s)"
            lastLoadError != null -> "ÉCHEC (${lastLoadError})"
            else -> "NON chargé (en attente)"
        }
        val audio = if (diagInputCalls == 0L) {
            "AUCUN audio PCM reçu du lecteur ($diagFormat)"
        } else {
            "$diagFormat | reçu $diagChunksQueued | décodé $diagChunksDecoded | niveau ${"%.3f".format(diagLastRms)}"
        }
        val status = _downloadStatusMessage.value
        val libs = nativeLibError?.let { "\nLib native: $it" } ?: ""
        return "Voix - modèle: $model | $audio" + libs + if (!status.isNullOrBlank()) "\n$status" else ""
    }

    /** Relance le chargement si la reconnaissance est active mais qu'aucun modèle n'est chargé ni en cours de chargement. */
    private fun loadWatchdog() {
        if (!_isVoiceRecognitionActive.value) return
        if (_isDownloadingModel.value || loadMutex.isLocked) return
        if (loadFailures >= 3) return
        val loaded = synchronized(recognizerLock) { currentRecognizer != null && isRecognizerReady }
        if (loaded) return
        val ctx = appContext ?: return
        if (requestedModelId == null) {
            requestedModelId = getModelInfoForLanguage(_selectedVoiceModelId.value).id
        }
        Log.w(TAG, "Watchdog: modèle non chargé, relance du chargement (${requestedModelId})")
        launchLoader(ctx)
    }

    init {
        // Chaque bibliothèque est chargée séparément : l'échec d'une lib optionnelle
        // (ex. c-api / cxx-api absentes de l'AAR) ne doit plus empêcher le chargement des suivantes.
        for (lib in listOf("onnxruntime", "sherpa-onnx-jni")) {
            try {
                System.loadLibrary(lib)
            } catch (t: Throwable) {
                Log.w(TAG, "Sherpa-ONNX native library '$lib' notice: ${t.message}")
                nativeLibError = "$lib: ${t.message}"
            }
        }
        startAudioWorker()
        scope.launch(Dispatchers.Default) {
            var tick = 0
            while (isActive) {
                delay(1000)
                tick++
                _diagnostics.value = if (_isVoiceRecognitionActive.value) buildDiagnostics() else ""
                if (tick % 4 == 0) {
                    try { loadWatchdog() } catch (t: Throwable) { Log.w(TAG, "watchdog: ${t.message}") }
                }
            }
        }
    }

    fun initialize(context: Context) {
        appContext = context.applicationContext
    }

    // ---- Garde-fou anti boucle de plantage -------------------------------------------------------
    // Un plantage NATIF (manque de mémoire pendant le chargement du modèle de 300 Mo, ou erreur JNI)
    // tue le process sans exception Java. On note donc "chargement en cours" AVANT de charger ; si l'app
    // redémarre avec cette note encore présente, c'est que le chargement précédent a planté : le modèle
    // est alors bloqué au lieu de replanter en boucle à chaque lancement.
    private fun guardPrefs(context: Context) =
        context.applicationContext.getSharedPreferences("sherpa_load_guard", Context.MODE_PRIVATE)

    private fun isModelBlocked(context: Context, modelId: String): Boolean {
        val prefs = guardPrefs(context)
        if (prefs.getString("loading_model", null) == modelId) {
            // Le dernier chargement n'a jamais fini -> crash natif
            prefs.edit().remove("loading_model").putBoolean("blocked_$modelId", true).apply()
        }
        return prefs.getBoolean("blocked_$modelId", false)
    }

    /** Débloque un modèle (à appeler quand l'utilisateur le supprime / le retélécharge explicitement). */
    fun unblockModel(context: Context, modelId: String) {
        guardPrefs(context).edit().remove("blocked_$modelId").remove("loading_model").apply()
    }

    private fun availableMemoryMb(context: Context): Long {
        return try {
            val am = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
            val mi = ActivityManager.MemoryInfo()
            am.getMemoryInfo(mi)
            mi.availMem / (1024 * 1024)
        } catch (t: Throwable) {
            Long.MAX_VALUE
        }
    }

    fun isRecognizerValid(recognizer: OnlineRecognizer?): Boolean {
        return recognizer != null && isRecognizerReady
    }

    fun isStreamValid(stream: OnlineStream?): Boolean {
        return stream != null && isStreamReady
    }

    fun setOnPartialListener(listener: ((text: String) -> Unit)?) {
        onPartialListener = listener
    }

    fun setOnFinalListener(listener: ((text: String, startTime: Float, endTime: Float) -> Unit)?) {
        onFinalListener = listener
    }

    fun setOnSpeechResultListener(listener: ((rawText: String) -> Unit)?) {
        onSpeechResultListener = listener
    }

    fun setSyncOffsetMs(offset: Int) {
        _syncOffsetMs.value = offset.coerceIn(-2000, 5000)
    }

    fun setAutoCalibrationEnabled(enabled: Boolean) {
        _isAutoCalibrationEnabled.value = enabled
    }

    fun setAutoClearDelaySeconds(seconds: Int) {
        _autoClearDelaySeconds.value = seconds.coerceIn(2, 10)
    }

    fun setIntelligentDurationEnabled(enabled: Boolean) {
        _isIntelligentDurationEnabled.value = enabled
    }

    fun setStreamingMode(enabled: Boolean) {
        _isStreamingMode.value = enabled
    }

    fun setSelectedVoiceModelId(modelId: String) {
        val clean = modelId.trim().lowercase()
        val safeId = if (allModels.containsKey(clean) || AVAILABLE_MODELS.any { it.id == clean }) clean else "fr"
        _selectedVoiceModelId.value = safeId
    }

    private fun startAudioWorker() {
        workerJob?.cancel()
        workerJob = scope.launch(recognitionDispatcher) {
            val flushTicker = launch {
                while (isActive) {
                    delay(200)
                    if (System.currentTimeMillis() - lastAudioFeedTime >= 300L) {
                        flushAccumulator()
                    }
                }
            }

            lastPartialText = ""

            for (samples in audioProcessingChannel) {
                diagChunksDecoded++
                if (isResetRequested.getAndSet(false)) {
                    synchronized(recognizerLock) {
                        try {
                            val stream = currentStream
                            val recognizer = currentRecognizer
                            if (isStreamValid(stream) && isRecognizerValid(recognizer)) {
                                recognizer!!.reset(stream!!)
                            }
                        } catch (t: Throwable) { }
                    }
                }

                if (!_isVoiceRecognitionActive.value) continue

                // Conditionnement acoustique léger et lissé
                applyAcousticNormalization(samples, samples.size)

                var finalResult: String? = null
                var partialResult: String? = null
                var startTime = 0f
                var endTime = 0f
                val decodeStartTime = System.currentTimeMillis()

                synchronized(recognizerLock) {
                    val recognizer = currentRecognizer ?: return@synchronized
                    val stream = currentStream ?: return@synchronized
                    if (!isRecognizerValid(recognizer) || !isStreamValid(stream)) {
                        return@synchronized
                    }
                    try {
                        stream.acceptWaveform(samples, SAMPLE_RATE)
                        var decodeSteps = 0
                        // Décodage plafonné pour ne jamais monopoliser le CPU d'un boîtier Google TV
                        while (isRecognizerValid(recognizer) && isStreamValid(stream) && recognizer.isReady(stream) && decodeSteps < 30 && !isResetRequested.get()) {
                            recognizer.decode(stream)
                            decodeSteps++
                        }
                        if (isRecognizerValid(recognizer) && isStreamValid(stream)) {
                            val isEndpointDetected = recognizer.isEndpoint(stream)
                            val res = recognizer.getResult(stream)
                            val clean = cleanRecognizedSpeech(res.text)

                            if (isEndpointDetected) {
                                if (clean.isNotBlank()) {
                                    finalResult = clean
                                    try {
                                        val timestamps = res.timestamps
                                        if (timestamps.isNotEmpty()) {
                                            startTime = timestamps.first()
                                            endTime = timestamps.last()
                                        }
                                    } catch (t: Throwable) { }
                                }
                                if (isRecognizerValid(recognizer) && isStreamValid(stream)) {
                                    recognizer.reset(stream)
                                }
                            } else if (clean.isNotBlank() && clean != lastPartialText) {
                                // CORRECTIF : on ne met PAS à jour lastPartialText ici.
                                // Avant, la valeur était écrasée avant le test de nouveauté plus bas
                                // et les sous-titres partiels (temps réel) n'étaient jamais émis.
                                partialResult = clean
                            }
                        }
                    } catch (t: Throwable) {
                        Log.w(TAG, "Erreur décodage Sherpa-ONNX: ${t.message}")
                    }
                }

                // Calibrage automatique : latence de décodage mesurée (sans délai artificiel de base)
                val decodeElapsed = (System.currentTimeMillis() - decodeStartTime)
                if (finalResult != null || partialResult != null) {
                    val measuredLag = decodeElapsed.toInt().coerceIn(0, 400)
                    _autoCalibratedOffsetMs.value = (0.85f * _autoCalibratedOffsetMs.value + 0.15f * measuredLag).toInt()
                }

                val safeFinal = finalResult
                val safePartial = partialResult
                if (safeFinal != null && safeFinal.isNotBlank()) {
                    lastPartialText = ""
                    val shown = formatForDisplay(safeFinal, 160)
                    val st = startTime
                    val et = endTime
                    GlobalDebugSystem.logFunctionCall(
                        "Sherpa_OnFinal",
                        "text" to shown,
                        "startTime" to st,
                        "endTime" to et
                    )
                    mainHandler.post {
                        try {
                            onFinalListener?.invoke(shown, st, et)
                        } catch (t: Throwable) {
                            Log.e(TAG, "Erreur onFinalListener: ${t.message}")
                        }
                    }
                    dispatchSpeechResult(shown, isFinal = true)
                } else if (safePartial != null && safePartial.isNotBlank()) {
                    lastPartialText = safePartial
                    val shown = formatForDisplay(safePartial, 96)
                    mainHandler.post {
                        try {
                            onPartialListener?.invoke(shown)
                        } catch (t: Throwable) {
                            Log.e(TAG, "Erreur onPartialListener: ${t.message}")
                        }
                    }
                    if (_isStreamingMode.value) {
                        dispatchSpeechResult(shown, isFinal = false)
                    }
                }
            }
            flushTicker.cancel()
        }
    }

    /**
     * Mise en forme pour l'affichage TV :
     * - les modèles anglais renvoient du TEXTE EN MAJUSCULES -> passage en casse normale ;
     * - majuscule en début de phrase ;
     * - fenêtre glissante (les dernières ~2 lignes) pour ne jamais noyer l'écran sous 10 s de texte.
     */
    private fun formatForDisplay(raw: String, maxChars: Int): String {
        var s = raw.trim()
        if (s.isEmpty()) return s
        val letters = s.count { it.isLetter() }
        if (letters >= 4) {
            val upper = s.count { it.isUpperCase() }
            if (upper.toFloat() / letters.toFloat() > 0.7f) {
                s = s.lowercase()
            }
        }
        if (currentLoadedLanguage == "en") {
            s = s.replace(standaloneEnglishI, "I")
        }
        s = s.replaceFirstChar { if (it.isLowerCase()) it.titlecase() else it.toString() }
        if (s.length > maxChars) {
            val cut = s.length - maxChars
            val space = s.indexOf(' ', cut)
            s = if (space in 0 until (s.length - 1)) s.substring(space + 1) else s.substring(cut)
        }
        return s
    }

    private fun notifySpeechResult(text: String) {
        mainHandler.post {
            try {
                onSpeechResultListener?.invoke(text)
            } catch (t: Throwable) {
                Log.e(TAG, "Erreur onSpeechResultListener: ${t.message}")
            }
        }
    }

    private fun enqueueChunk(chunk: FloatArray) {
        lastAudioFeedTime = System.currentTimeMillis()
        diagChunksQueued++
        if (audioProcessingChannel.trySend(chunk).isFailure) {
            audioProcessingChannel.tryReceive()
            audioProcessingChannel.trySend(chunk)
        }
    }

    /**
     * Sélectionne et recharge le modèle de la langue source Sherpa-ONNX.
     * Télécharge automatiquement le modèle depuis HuggingFace s'il n'est pas encore installé.
     */
    fun setSourceLanguage(code: String, customContext: Context? = null) {
        val cleanCode = code.trim().lowercase()
        val requestedId = if (allModels.containsKey(cleanCode) || AVAILABLE_MODELS.any { it.id == cleanCode }) cleanCode else "fr"
        setSelectedVoiceModelId(requestedId)

        // On travaille désormais avec le modèle RÉEL (ex. "ru" -> modèle multilingue),
        // ce qui évite aussi de recharger inutilement le même modèle sous un autre code.
        val modelInfo = getModelInfoForLanguage(requestedId)
        val safeId = modelInfo.id
        if (AVAILABLE_MODELS.none { it.id == requestedId }) {
            _downloadStatusMessage.value = "Pas de modèle vocal hors-ligne dédié pour « $requestedId » : le modèle ${modelInfo.name} est utilisé (transcription approximative)."
        }

        val context = customContext ?: appContext
        if (context == null) {
            Log.w(TAG, "Context non disponible pour setSourceLanguage($safeId)")
            return
        }

        synchronized(recognizerLock) {
            if (currentLoadedLanguage == safeId && currentRecognizer != null && currentStream != null) {
                _isVoiceRecognitionActive.value = true
                resetRecognitionState()
                return
            }
        }

        // Demande explicite : on mémorise le modèle voulu et on (re)lance le chargeur.
        // Le chargeur est sérialisé (loadMutex) : plus aucun chargement parallèle, plus d'annulation
        // d'un chargement natif en cours (qui ne peut pas être interrompu et saturait la RAM de la TV).
        requestedModelId = safeId
        loadFailures = 0
        launchLoader(context)
    }

    private fun launchLoader(context: Context) {
        loadModelJob = scope.launch(Dispatchers.IO) {
            loadMutex.withLock {
                var iterations = 0
                while (iterations++ < 4) {
                    val targetId = requestedModelId ?: break
                    val info = AVAILABLE_MODELS.firstOrNull { it.id == targetId } ?: break
                    val already = synchronized(recognizerLock) {
                        currentLoadedLanguage == targetId && currentRecognizer != null && currentStream != null && isRecognizerReady
                    }
                    if (already) break
                    val ok = try {
                        loadModelBlocking(context, info)
                    } catch (e: CancellationException) {
                        throw e
                    } catch (t: Throwable) {
                        Log.e(TAG, "Erreur chargement Sherpa modèle $targetId: ${t.message}", t)
                        lastLoadError = t.message ?: t.javaClass.simpleName
                        _downloadStatusMessage.value = "Erreur chargement Sherpa: ${lastLoadError}"
                        false
                    }
                    if (!ok) {
                        loadFailures++
                        break
                    }
                    loadFailures = 0
                }
            }
        }
    }

    /** Télécharge si besoin puis charge le modèle. Appelé uniquement sous loadMutex. */
    private suspend fun loadModelBlocking(context: Context, modelInfo: SherpaModelInfo): Boolean {
        loadingSinceMs = System.currentTimeMillis()
        lastLoadError = null
        try {
            val safeId = modelInfo.id
            val modelDir = getModelDirectory(context, modelInfo)

            if (!isModelInstalled(context, modelInfo)) {
                _downloadStatusMessage.value = "Téléchargement modèle Sherpa ${modelInfo.name}..."
                val downloaded = downloadAndExtractModel(context, modelInfo)
                if (!downloaded || !isModelInstalled(context, modelInfo)) {
                    lastLoadError = "téléchargement incomplet"
                    _downloadStatusMessage.value = "Échec du téléchargement pour ${modelInfo.name}"
                    return false
                }
            }

            if (isModelBlocked(context, safeId)) {
                lastLoadError = "modèle bloqué après un plantage"
                _downloadStatusMessage.value = "Le chargement de « ${modelInfo.name} » a fait planter l'application (mémoire insuffisante probable sur cette TV). Modèle désactivé : choisis un modèle plus léger (Français / Anglais)."
                return false
            }

            // Estimation de la mémoire nécessaire : ~1,5 x la taille des fichiers du modèle.
            // Simple avertissement (availMem sous-estime souvent la mémoire réellement récupérable) ;
            // le garde-fou anti-plantage protège en cas de vrai manque de mémoire.
            val modelBytes = modelInfo.fileNames.sumOf { File(modelDir, it).length() }
            val neededMb = (modelBytes * 3 / 2) / (1024 * 1024)
            val freeMb = availableMemoryMb(context)
            if (freeMb < neededMb / 2) {
                lastLoadError = "mémoire insuffisante (${freeMb} Mo libres, ~${neededMb} Mo requis)"
                _downloadStatusMessage.value = "Mémoire insuffisante pour « ${modelInfo.name} » : ${freeMb} Mo libres, ~${neededMb} Mo nécessaires. Ferme d'autres applications ou choisis un modèle plus léger."
                return false
            } else if (freeMb < neededMb) {
                Log.w(TAG, "Mémoire juste pour ${modelInfo.name}: ${freeMb} Mo libres, ~${neededMb} Mo requis. Tentative de chargement.")
            }

            _downloadStatusMessage.value = "Chargement du modèle ${modelInfo.name}..."
            guardPrefs(context).edit().putString("loading_model", safeId).commit()
            val ok = loadRecognizerFromDirectory(modelDir, safeId)
            // Arrivé ici : pas de crash natif pendant le chargement
            guardPrefs(context).edit().remove("loading_model").apply()
            return ok
        } finally {
            loadingSinceMs = 0L
        }
    }

    fun startVoiceRecognition(context: Context) {
        initialize(context)
        _isVoiceRecognitionActive.value = true
        resetRecognitionState()
        if (currentRecognizer == null) {
            setSourceLanguage(_selectedVoiceModelId.value, context)
        }
    }

    fun stopVoiceRecognition() {
        _isVoiceRecognitionActive.value = false
        resetRecognitionState()
    }

    fun resetRecognitionState() {
        lastPartialText = ""
        isResetRequested.set(true)
        synchronized(sampleLock) {
            sampleAccumulatorSize = 0
        }
        while (audioProcessingChannel.tryReceive().isSuccess) { }
        delayedEmitJob?.cancel()
        delayedEmitJob = null
        // Invalide tous les résultats encore en attente dans la ligne à retard
        synchronized(emitLock) {
            lastEmittedSequence = emitSequence.get()
        }
        autoClearJob?.cancel()
        autoClearJob = null
        _recognizedSpeechText.value = null
        _isSpeechDetected.value = false
        notifySpeechResult("")
    }

    fun flushAccumulator() {
        synchronized(sampleLock) {
            if (sampleAccumulatorSize > 0) {
                val chunk = sampleAccumulator.copyOf(sampleAccumulatorSize)
                audioProcessingChannel.trySend(chunk)
                sampleAccumulatorSize = 0
            }
        }
    }

    fun feedAudioPcm(pcmData: ByteArray, length: Int) {
        if (!_isVoiceRecognitionActive.value || length < 2) return

        val energy = calculateRmsEnergy(pcmData, length)
        if (energy > 25.0) {
            _isSpeechDetected.value = true
        }

        val totalSamples = length / 2
        val floatBlock = FloatArray(totalSamples)
        var sIdx = 0
        for (i in 0 until (length - 1) step 2) {
            val low = pcmData[i].toInt() and 0xFF
            val high = pcmData[i + 1].toInt()
            val s = ((high shl 8) or low).toShort()
            floatBlock[sIdx++] = s / 32768.0f
        }

        feedAudioSamples(floatBlock, totalSamples)
    }

    fun feedAudioSamples(samples: FloatArray, count: Int) {
        if (!_isVoiceRecognitionActive.value || count <= 0) return

        synchronized(sampleLock) {
            var srcOffset = 0
            var remaining = count
            lastAudioFeedTime = System.currentTimeMillis()

            while (remaining > 0) {
                val available = sampleAccumulator.size - sampleAccumulatorSize
                if (available <= 0) {
                    val chunk = sampleAccumulator.copyOf(sampleAccumulatorSize)
                    audioProcessingChannel.trySend(chunk)
                    sampleAccumulatorSize = 0
                }
                val toCopy = minOf(remaining, sampleAccumulator.size - sampleAccumulatorSize)
                if (toCopy <= 0) {
                    sampleAccumulatorSize = 0
                    continue
                }
                System.arraycopy(samples, srcOffset, sampleAccumulator, sampleAccumulatorSize, toCopy)
                sampleAccumulatorSize += toCopy
                srcOffset += toCopy
                remaining -= toCopy

                if (sampleAccumulatorSize >= 2400) { // 150ms de son @ 16kHz optimisé pour Android & Google TV
                    val chunk = sampleAccumulator.copyOf(sampleAccumulatorSize)
                    if (audioProcessingChannel.trySend(chunk).isFailure) {
                        audioProcessingChannel.tryReceive() // Éviter l'accumulation pour latence 0
                        audioProcessingChannel.trySend(chunk)
                    }
                    sampleAccumulatorSize = 0
                }
            }
        }
    }

    private fun calculateRmsEnergy(pcmData: ByteArray, length: Int): Double {
        if (length < 2) return 0.0
        var sumSquares = 0.0
        var count = 0
        var i = 0
        while (i < length - 1) {
            val low = pcmData[i].toInt() and 0xFF
            val high = pcmData[i + 1].toInt()
            val sample = ((high shl 8) or low).toShort().toDouble()
            sumSquares += (sample * sample)
            count++
            i += 4
        }
        if (count == 0) return 0.0
        return sqrt(sumSquares / count)
    }

    /**
     * Conditionnement acoustique : amplifie adaptativement les signaux vocaux faibles
     * et équilibre le spectre pour faire ressortir les consonnes douces et accents sans distorsion.
     */
    private fun applyAcousticNormalization(samples: FloatArray, count: Int) {
        if (count <= 0) return
        var sumSquares = 0.0
        for (i in 0 until count) {
            val s = samples[i]
            if (s.isNaN() || s.isInfinite()) {
                samples[i] = 0.0f
                continue
            }
            sumSquares += (s * s)
        }
        val rms = sqrt(sumSquares / count)
        if (rms.isNaN() || rms.isInfinite()) return
        diagLastRms = rms.toFloat()

        // Hystérésis : l'indicateur "parole détectée" retombe enfin quand le silence revient
        if (rms > 0.006) {
            _isSpeechDetected.value = true
        } else if (rms < 0.002 && _recognizedSpeechText.value == null) {
            _isSpeechDetected.value = false
        }

        val target = if (rms in 0.004..0.22) (0.24 / rms).toFloat().coerceIn(1.0f, 2.6f) else 1.0f
        // Descente rapide (évite la saturation), montée lente (évite le pompage / la remontée du bruit)
        agcGain += (target - agcGain) * (if (target < agcGain) 0.6f else 0.15f)
        if (agcGain <= 1.01f) return
        val gain = agcGain
        for (i in 0 until count) {
            val amplified = samples[i] * gain
            samples[i] = if (amplified > 0.95f) 0.95f else if (amplified < -0.95f) -0.95f else amplified
        }
    }

    private fun dispatchSpeechResult(text: String, isFinal: Boolean) {
        val seq = emitSequence.incrementAndGet()
        // Choix intelligent automatique ou manuel selon la configuration
        val effectiveOffset = if (_isAutoCalibrationEnabled.value) {
            _autoCalibratedOffsetMs.value
        } else {
            _syncOffsetMs.value
        }

        if (effectiveOffset <= 0) {
            emitSpeechResultNow(seq, text, isFinal)
        } else {
            // Ligne à retard : chaque résultat a son propre job (l'ancien code annulait le précédent
            // à chaque partiel, donc avec un offset > 0 rien ne s'affichait tant que la parole continuait).
            scope.launch(Dispatchers.Default) {
                delay(effectiveOffset.toLong())
                emitSpeechResultNow(seq, text, isFinal)
            }
        }
    }

    private fun emitSpeechResultNow(seq: Long, text: String, isFinal: Boolean) {
        synchronized(emitLock) {
            if (seq <= lastEmittedSequence) return
            lastEmittedSequence = seq
        }
        lastEmittedIsFinal = isFinal
        _recognizedSpeechText.value = text
        notifySpeechResult(text)
        resetAutoClearTimer(text)
    }

    /**
     * Durée d'affichage adaptée à la lecture d'un sous-titre TV (~17 caractères/seconde) :
     * 1,5 s de base + 60 ms par caractère, bornée entre 2,5 s et 8 s.
     * (L'ancien calcul donnait 7 à 18 s : l'ancien texte restait collé à l'écran.)
     */
    fun calculateIntelligentDisplayDurationMs(text: String): Long {
        if (text.isBlank()) return 3000L
        if (!_isIntelligentDurationEnabled.value) {
            return (_autoClearDelaySeconds.value * 1000L).coerceIn(2000L, 12000L)
        }
        val computed = 1500L + (text.trim().length * 60L)
        return computed.coerceIn(2500L, 8000L)
    }

    fun refreshAutoClearTimer(text: String) {
        if (text.isBlank()) return
        resetAutoClearTimer(text)
    }

    private fun resetAutoClearTimer(text: String) {
        autoClearJob?.cancel()
        val delayMs = calculateIntelligentDisplayDurationMs(text)
        autoClearJob = scope.launch(Dispatchers.Default) {
            delay(delayMs)
            _recognizedSpeechText.value = null
            _isSpeechDetected.value = false
            notifySpeechResult("")
        }
    }

    fun injectSimulationSpeech(text: String) {
        _isSpeechDetected.value = true
        lastEmittedIsFinal = true
        _recognizedSpeechText.value = text
        notifySpeechResult(text)
        resetAutoClearTimer(text)
    }

    private fun getModelInfoForLanguage(langCode: String): SherpaModelInfo {
        val clean = langCode.trim().lowercase()
        AVAILABLE_MODELS.find { it.id == clean || it.code == clean }?.let { return it }
        // Langue sans modèle dédié : utiliser le modèle prévu par la table allModels
        // (ex. "ru" -> modèle multilingue au lieu du modèle français).
        val mappedDir = allModels[clean]
        return AVAILABLE_MODELS.find { it.dirName == mappedDir } ?: AVAILABLE_MODELS.first()
    }

    private fun getModelDirectory(context: Context, modelInfo: SherpaModelInfo): File {
        val baseDir = File(context.filesDir, "sherpa-models")
        if (!baseDir.exists()) baseDir.mkdirs()
        return File(baseDir, modelInfo.dirName)
    }

    private fun formatBytes(bytes: Long): String {
        if (bytes <= 0) return "0 Mo"
        val mb = bytes.toDouble() / (1024.0 * 1024.0)
        return if (mb < 1.0) {
            String.format(java.util.Locale.US, "%.0f Ko", bytes.toDouble() / 1024.0)
        } else {
            String.format(java.util.Locale.US, "%.1f Mo", mb)
        }
    }

    private fun getExpectedFileSize(fileName: String, modelId: String): Long {
        return when {
            modelId == "ar" && fileName == "tokens.txt" -> 195_244L
            modelId == "ar" && fileName == "bpe.model" -> 476_049L
            modelId == "ar" && fileName.contains("encoder") -> 296_583_597L
            modelId == "ar" && fileName.contains("decoder") -> 33_837_085L
            modelId == "ar" && fileName.contains("joiner") -> 8_257_421L

            modelId == "fr" && fileName == "tokens.txt" -> 4_819L
            modelId == "fr" && fileName.contains("encoder") -> 126_655_903L
            modelId == "fr" && fileName.contains("decoder") -> 1_307_157L
            modelId == "fr" && fileName.contains("joiner") -> 259_572L

            modelId == "en" && fileName == "tokens.txt" -> 5_048L
            modelId == "en" && fileName.contains("encoder") -> 42_845_182L
            modelId == "en" && fileName.contains("decoder") -> 539_499L
            modelId == "en" && fileName.contains("joiner") -> 259_572L

            fileName.endsWith(".onnx") -> 20_000_000L
            fileName.endsWith(".txt") -> 5_000L
            fileName.endsWith(".model") -> 500_000L
            else -> 1_000_000L
        }
    }

    fun isModelInstalled(context: Context, model: SherpaModelInfo): Boolean {
        val dir = getModelDirectory(context, model)
        if (!dir.exists() || !dir.isDirectory) return false
        for (fileName in model.fileNames) {
            val file = File(dir, fileName)
            if (!file.exists()) return false
            val minExpected = when {
                fileName.contains("encoder") -> 20_000_000L
                fileName.contains("decoder") -> 400_000L
                fileName.contains("joiner") -> 200_000L
                fileName.endsWith(".txt") -> 500L
                fileName.endsWith(".model") -> 100_000L
                else -> 100L
            }
            if (file.length() < minExpected) return false
        }
        return true
    }

    suspend fun downloadAndExtractModel(context: Context, model: SherpaModelInfo): Boolean = withContext(Dispatchers.IO) {
        downloadMutex.withLock {
            _isDownloadingModel.value = true
            _downloadProgress.value = 0f
            _downloadStatusMessage.value = "Préparation du téléchargement (${model.name})..."

            val dir = getModelDirectory(context, model)
            if (!dir.exists()) dir.mkdirs()

            try {
                val totalModelBytes = model.fileNames.sumOf { getExpectedFileSize(it, model.id) }.coerceAtLeast(1L)
                var completedFilesBytes = 0L

                for (fileName in model.fileNames) {
                    val destFile = File(dir, fileName)
                    val expectedSize = getExpectedFileSize(fileName, model.id)
                    val minExpected = when {
                        fileName.endsWith(".onnx") -> 100_000L
                        fileName.endsWith(".txt") -> 100L
                        fileName.endsWith(".model") -> 10_000L
                        else -> 50L
                    }

                    // Si le fichier existe déjà et est valide, le compter comme complété
                    if (destFile.exists() && destFile.length() >= minExpected) {
                        completedFilesBytes += destFile.length()
                        val initialProgress = (completedFilesBytes.toDouble() / totalModelBytes.toDouble()).toFloat().coerceIn(0f, 1f)
                        _downloadProgress.value = initialProgress
                        continue
                    } else if (destFile.exists()) {
                        destFile.delete() // Nettoyer un ancien fichier corrompu
                    }

                    val tmpFile = File(dir, "$fileName.tmp")
                    val candidateUrls = listOf(
                        model.baseUrl + fileName,
                        model.baseUrl + fileName + "?download=true",
                        model.baseUrl.replace("https://huggingface.co/", "https://hf-mirror.com/") + fileName
                    ).distinct()

                    var fileCompleted = false
                    var lastException: Exception? = null

                    for (attempt in 1..4) {
                        val currentUrl = candidateUrls[(attempt - 1) % candidateUrls.size]
                        try {
                            var existingBytes = if (tmpFile.exists()) tmpFile.length() else 0L

                            val reqBuilder = Request.Builder()
                                .url(currentUrl)
                                .header("User-Agent", "Mozilla/5.0 (Linux; Android 13; Mobile) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36")
                                .header("Accept", "*/*")

                            if (existingBytes > 0L) {
                                reqBuilder.header("Range", "bytes=$existingBytes-")
                            }

                            val req = reqBuilder.build()
                            httpClient.newCall(req).execute().use { response ->
                                if (response.code == 416) {
                                    tmpFile.delete()
                                    existingBytes = 0L
                                    throw Exception("HTTP 416 Range réinitialisé")
                                }
                                if (!response.isSuccessful) {
                                    throw Exception("HTTP ${response.code} pour $currentUrl")
                                }

                                val body = response.body ?: throw Exception("Réponse vide pour $currentUrl")
                                val isAppend = response.code == 206
                                if (!isAppend) {
                                    existingBytes = 0L
                                }

                                val remoteRemaining = body.contentLength()
                                val fileTotal = if (remoteRemaining > 0) existingBytes + remoteRemaining else expectedSize

                                FileOutputStream(tmpFile, isAppend).use { output ->
                                    body.byteStream().use { input ->
                                        val buffer = ByteArray(65536)
                                        var bytesRead: Int
                                        var currentFileDownloaded = existingBytes
                                        var lastUpdate = 0L

                                        while (input.read(buffer).also { bytesRead = it } != -1) {
                                            output.write(buffer, 0, bytesRead)
                                            currentFileDownloaded += bytesRead
                                            val now = System.currentTimeMillis()
                                            if (now - lastUpdate > 150L) {
                                                lastUpdate = now
                                                val overallBytes = completedFilesBytes + currentFileDownloaded
                                                val progress = (overallBytes.toDouble() / totalModelBytes.toDouble()).toFloat().coerceIn(0f, 0.99f)
                                                _downloadProgress.value = progress
                                                val pct = (progress * 100).toInt()
                                                _downloadStatusMessage.value = "Téléchargement $fileName : ${formatBytes(currentFileDownloaded)} / ${formatBytes(fileTotal)} ($pct%)"
                                            }
                                        }
                                    }
                                }
                            }

                            if (tmpFile.length() < minExpected) {
                                tmpFile.delete()
                                throw Exception("Fichier incomplet (${tmpFile.length()} octets)")
                            }

                            if (destFile.exists()) destFile.delete()
                            var renamed = tmpFile.renameTo(destFile)
                            if (!renamed) {
                                try {
                                    tmpFile.inputStream().use { inp ->
                                        destFile.outputStream().use { outp ->
                                            inp.copyTo(outp)
                                        }
                                    }
                                    tmpFile.delete()
                                    renamed = true
                                } catch (e: Exception) {
                                    renamed = false
                                }
                            }

                            if (renamed) {
                                fileCompleted = true
                                completedFilesBytes += destFile.length()
                                break
                            } else {
                                throw Exception("Échec de sauvegarde finale pour $fileName")
                            }
                        } catch (e: Exception) {
                            lastException = e
                            Log.w(TAG, "Tentative $attempt/4 pour $fileName a échoué: ${e.message}")
                            if (attempt < 4) {
                                _downloadStatusMessage.value = "Reprise automatique $fileName ($attempt/4)..."
                                delay(1500L * attempt)
                            }
                        }
                    }

                    if (!fileCompleted) {
                        throw lastException ?: Exception("Échec du téléchargement pour $fileName après 4 tentatives")
                    }
                }

                _downloadProgress.value = 1f
                _downloadStatusMessage.value = "Modèle ${model.name} prêt !"
                Log.d(TAG, "[dlog] Sherpa-ONNX modèle téléchargé avec succès: ${model.id}")
                true
            } catch (e: Exception) {
                Log.e(TAG, "Erreur téléchargement modèle ${model.id}: ${e.message}", e)
                _downloadStatusMessage.value = "Erreur téléchargement: ${e.message}"
                false
            } finally {
                _isDownloadingModel.value = false
            }
        }
    }

    fun deleteModel(context: Context, model: SherpaModelInfo): Boolean {
        return try {
            synchronized(recognizerLock) {
                if (currentLoadedLanguage == model.id) {
                    try {
                        if (isStreamValid(currentStream)) currentStream?.release()
                    } catch (t: Throwable) { }
                    currentStream = null
                    try {
                        if (isRecognizerValid(currentRecognizer)) currentRecognizer?.release()
                    } catch (t: Throwable) { }
                    currentRecognizer = null
                    currentLoadedLanguage = null
                }
            }
            unblockModel(context, model.id)
            val dir = getModelDirectory(context, model)
            if (dir.exists()) {
                dir.deleteRecursively()
            } else true
        } catch (e: Exception) {
            Log.e(TAG, "Erreur suppression modèle: ${e.message}")
            false
        }
    }

    /**
     * Nettoie les artefacts de tokenisation SentencePiece et BPE pour le français, l'arabe et le multilingue.
     */
    fun cleanRecognizedSpeech(raw: String): String {
        if (raw.isBlank()) return ""
        var s = raw
            .replace("\u2581", " ") // Symbole de séparation de mot SentencePiece
            .replace(" ", " ")
            .replace("@@", "") // Connecteur BPE
            .replace(Regex("<0x[0-9A-Fa-f]{2}>"), "") // Éliminer les fragments d'octets bruts
            .replace(Regex("\\s+"), " ")
            .trim()
        return s
    }

    private fun loadRecognizerFromDirectory(modelDir: File, languageCode: String): Boolean {
        try {
            val tokensFile = File(modelDir, "tokens.txt")
            val files = modelDir.listFiles().orEmpty()
            val encoderFile = files.find { it.name.contains("encoder") && it.name.endsWith(".onnx") }
            val decoderFile = files.find { it.name.contains("decoder") && it.name.endsWith(".onnx") }
            val joinerFile = files.find { it.name.contains("joiner") && it.name.endsWith(".onnx") }
            val bpeFile = File(modelDir, "bpe.model").takeIf { it.exists() }

            if (encoderFile == null || decoderFile == null || joinerFile == null || !tokensFile.exists()) {
                Log.w(TAG, "Modèle Sherpa incomplet dans $modelDir")
                _downloadStatusMessage.value = "Modèle incomplet, téléchargement requis"
                lastLoadError = "modèle incomplet"
                return false
            }

            if (encoderFile.length() < 1_000_000L || decoderFile.length() < 100_000L || joinerFile.length() < 50_000L || tokensFile.length() < 50L) {
                Log.w(TAG, "Fichiers ONNX invalides ou incomplets dans $modelDir")
                _downloadStatusMessage.value = "Fichiers corrompus, retéléchargement requis"
                lastLoadError = "fichiers corrompus"
                return false
            }

            // Libérer l'ancien modèle AVANT d'en créer un nouveau : sinon les deux coexistent en mémoire
            // (FR ~130 Mo + AR ~340 Mo) et une TV à 2 Go tue l'application.
            synchronized(recognizerLock) {
                isRecognizerReady = false
                isStreamReady = false
                try { currentStream?.release() } catch (t: Throwable) { }
                try { currentRecognizer?.release() } catch (t: Throwable) { }
                currentStream = null
                currentRecognizer = null
                currentLoadedLanguage = null
            }
            System.gc()

            val transducerConfig = OnlineTransducerModelConfig(
                encoder = encoderFile.absolutePath,
                decoder = decoderFile.absolutePath,
                joiner = joinerFile.absolutePath
            )

            val liveTvEndpointConfig = EndpointConfig(
                rule1 = com.k2fsa.sherpa.onnx.EndpointRule(mustContainNonSilence = false, minTrailingSilence = 0.9f, minUtteranceLength = 0.0f),
                rule2 = com.k2fsa.sherpa.onnx.EndpointRule(mustContainNonSilence = true, minTrailingSilence = 0.5f, minUtteranceLength = 0.0f),
                rule3 = com.k2fsa.sherpa.onnx.EndpointRule(mustContainNonSilence = false, minTrailingSilence = 0.0f, minUtteranceLength = 10.0f)
            )

            // 1 thread sur les petits SoC (2 coeurs), 2 threads dès 4 coeurs : un seul thread int8 sur un
            // Cortex-A53/A55 de boîtier Google TV décode parfois moins vite que le temps réel
            // (l'audio en retard était alors jeté par le canal DROP_OLDEST -> mots perdus).
            val optimalThreads = if (languageCode == "ar") 1 else if (Runtime.getRuntime().availableProcessors() >= 4) 2 else 1

            // Dans Sherpa-ONNX 1.10+, les modèles zipformer utilisent zipformer2
            val candidateTypes = if (bpeFile != null && bpeFile.exists()) {
                listOf("zipformer2", "", "zipformer")
            } else {
                listOf("", "zipformer2", "zipformer")
            }
            var testRecognizer: OnlineRecognizer? = null
            var testStream: OnlineStream? = null
            var lastInitError: String? = null

            for (typeCandidate in candidateTypes) {
                try {
                    val mConfig = OnlineModelConfig(
                        transducer = transducerConfig,
                        tokens = tokensFile.absolutePath,
                        numThreads = optimalThreads,
                        debug = false,
                        provider = "cpu",
                        modelType = typeCandidate,
                        bpeVocab = ""
                    )
                    val rConfig = OnlineRecognizerConfig(
                        featConfig = FeatureConfig(sampleRate = SAMPLE_RATE, featureDim = 80),
                        modelConfig = mConfig,
                        endpointConfig = liveTvEndpointConfig,
                        enableEndpoint = true
                    )
                    val rec = OnlineRecognizer(config = rConfig)
                    val str = rec.createStream()
                    testRecognizer = rec
                    testStream = str
                    Log.d(TAG, "[dlog] Sherpa-ONNX initialisé avec succès ($languageCode, threads=$optimalThreads, modelType='$typeCandidate')")
                    break
                } catch (t: Throwable) {
                    Log.w(TAG, "Tentative init Sherpa avec modelType='$typeCandidate' a échoué: ${t.message}")
                    lastInitError = "${t.javaClass.simpleName}: ${t.message}"
                }
            }

            if (testRecognizer == null || testStream == null) {
                throw Exception("Échec création OnlineRecognizer Sherpa-ONNX (${lastInitError ?: "?"})")
            }

            synchronized(recognizerLock) {
                isRecognizerReady = false
                isStreamReady = false
                try { currentStream?.release() } catch (t: Throwable) { }
                try { currentRecognizer?.release() } catch (t: Throwable) { }
                currentRecognizer = testRecognizer
                currentStream = testStream
                currentLoadedLanguage = languageCode
                isRecognizerReady = true
                isStreamReady = true
            }

            _isVoiceRecognitionActive.value = true
            GlobalDebugSystem.logStateChange("SherpaLoadedModel", "none", languageCode)
            Log.d(TAG, "[dlog] Sherpa-ONNX prêt: $languageCode")
            lastLoadError = null
            _downloadStatusMessage.value = "Modèle vocal chargé ✓ ($languageCode)"
            return true
        } catch (t: Throwable) {
            Log.e(TAG, "Erreur initialisation OnlineRecognizer Sherpa: ${t.message}", t)
            lastLoadError = t.message ?: t.javaClass.simpleName
            _downloadStatusMessage.value = "Erreur init Sherpa: ${t.message}"
            return false
        }
    }

    /**
     * Crée un AudioProcessor Media3 qui capture le flux PCM sans couper ni altérer l'audio d'origine.
     */
    fun createMedia3AudioProcessor(): AudioProcessor {
        return SherpaCaptureAudioProcessor()
    }

    /**
     * Filtre passe-bas biquad (Butterworth 2e ordre) utilisé comme filtre anti-repliement
     * avant la décimation vers 16 kHz.
     */
    private class Biquad {
        private var b0 = 1.0
        private var b1 = 0.0
        private var b2 = 0.0
        private var a1 = 0.0
        private var a2 = 0.0
        private var x1 = 0.0
        private var x2 = 0.0
        private var y1 = 0.0
        private var y2 = 0.0

        fun setLowPass(cutoffHz: Double, sampleRate: Double) {
            val w0 = 2.0 * Math.PI * cutoffHz / sampleRate
            val cosW = Math.cos(w0)
            val alpha = Math.sin(w0) / (2.0 * 0.70710678)
            val a0 = 1.0 + alpha
            b0 = (1.0 - cosW) / 2.0 / a0
            b1 = (1.0 - cosW) / a0
            b2 = b0
            a1 = -2.0 * cosW / a0
            a2 = (1.0 - alpha) / a0
            reset()
        }

        fun reset() {
            x1 = 0.0
            x2 = 0.0
            y1 = 0.0
            y2 = 0.0
        }

        fun process(x: Float): Float {
            val xd = x.toDouble()
            val y = b0 * xd + b1 * x1 + b2 * x2 - a1 * y1 - a2 * y2
            x2 = x1
            x1 = xd
            y2 = y1
            y1 = y
            return y.toFloat()
        }
    }

    /**
     * Processeur Audio Media3 : copie l'audio tel quel vers la sortie (aucune altération du son)
     * et alimente Sherpa-ONNX en mono 16 kHz.
     *
     * Correctif qualité : l'ancienne version décimait 48 kHz -> 16 kHz en prenant 1 échantillon sur 3
     * SANS filtre, ce qui replie les hautes fréquences (sifflantes, bruit) dans la bande de la voix
     * et dégrade nettement la reconnaissance. Ici : downmix -> passe-bas 7 kHz (2 x biquad) ->
     * interpolation linéaire avec état conservé d'un buffer à l'autre (pas de rupture de phase).
     * Gère PCM 8/16/24/32 bits et Float, mono, stéréo et 5.1/7.1 (canal central privilégié).
     */
    private class SherpaCaptureAudioProcessor : BaseAudioProcessor() {
        private var inputSampleRate: Int = 48000
        private var inputChannelCount: Int = 2
        private var inputEncoding: Int = C.ENCODING_PCM_16BIT
        private var bytesPerSample: Int = 2
        private val targetSampleRate = 16000

        private val lowPassA = Biquad()
        private val lowPassB = Biquad()
        private var useLowPass = false
        private var step = 3.0
        private var readPos = 0.0
        private var prevSample = 0f
        private var monoBuffer = FloatArray(8192)
        private val outChunk = FloatArray(1600) // 100 ms @ 16 kHz
        private var outSize = 0

        override fun onConfigure(inputAudioFormat: AudioProcessor.AudioFormat): AudioProcessor.AudioFormat {
            if (inputAudioFormat.encoding != C.ENCODING_PCM_16BIT &&
                inputAudioFormat.encoding != C.ENCODING_PCM_FLOAT &&
                inputAudioFormat.encoding != C.ENCODING_PCM_24BIT &&
                inputAudioFormat.encoding != C.ENCODING_PCM_32BIT &&
                inputAudioFormat.encoding != C.ENCODING_PCM_8BIT
            ) {
                diagFormat = "format audio NON PCM (passthrough ? encodage=${inputAudioFormat.encoding})"
                return AudioProcessor.AudioFormat.NOT_SET
            }
            inputEncoding = inputAudioFormat.encoding
            inputSampleRate = if (inputAudioFormat.sampleRate > 0) inputAudioFormat.sampleRate else 48000
            inputChannelCount = if (inputAudioFormat.channelCount > 0) inputAudioFormat.channelCount else 2
            diagFormat = "${inputSampleRate} Hz, ${inputChannelCount} ch, " + when (inputEncoding) {
                C.ENCODING_PCM_16BIT -> "PCM16"
                C.ENCODING_PCM_FLOAT -> "PCM float"
                C.ENCODING_PCM_24BIT -> "PCM24"
                C.ENCODING_PCM_32BIT -> "PCM32"
                else -> "PCM8"
            }
            bytesPerSample = when (inputEncoding) {
                C.ENCODING_PCM_FLOAT, C.ENCODING_PCM_32BIT -> 4
                C.ENCODING_PCM_24BIT -> 3
                C.ENCODING_PCM_8BIT -> 1
                else -> 2
            }
            step = inputSampleRate.toDouble() / targetSampleRate.toDouble()
            useLowPass = inputSampleRate > targetSampleRate
            if (useLowPass) {
                val cutoff = minOf(7000.0, inputSampleRate * 0.45)
                lowPassA.setLowPass(cutoff, inputSampleRate.toDouble())
                lowPassB.setLowPass(cutoff, inputSampleRate.toDouble())
            }
            resetState()
            return inputAudioFormat
        }

        override fun onFlush() {
            resetState()
        }

        override fun onReset() {
            resetState()
        }

        private fun resetState() {
            readPos = 0.0
            prevSample = 0f
            outSize = 0
            lowPassA.reset()
            lowPassB.reset()
        }

        override fun queueInput(inputBuffer: ByteBuffer) {
            val remaining = inputBuffer.remaining()
            if (remaining == 0) return
            diagInputCalls++

            // Vue indépendante pour Sherpa : inputBuffer reste intact pour la sortie
            val sherpaView: ByteBuffer? = if (_isVoiceRecognitionActive.value) {
                inputBuffer.duplicate().order(inputBuffer.order())
            } else null

            // Priorité absolue : l'audio d'origine part immédiatement vers la sortie
            val out = replaceOutputBuffer(remaining)
            out.put(inputBuffer)
            out.flip()

            if (sherpaView != null) {
                try {
                    captureForSherpa(sherpaView)
                } catch (t: Throwable) {
                    // Ne jamais casser le pipeline ExoPlayer
                }
            }
        }

        private fun sampleAt(view: ByteBuffer, offset: Int): Float {
            return when (inputEncoding) {
                C.ENCODING_PCM_FLOAT -> view.getFloat(offset)
                C.ENCODING_PCM_32BIT -> view.getInt(offset) / 2147483648.0f
                C.ENCODING_PCM_24BIT -> {
                    val raw = (view.get(offset + 2).toInt() shl 16) or
                        ((view.get(offset + 1).toInt() and 0xFF) shl 8) or
                        (view.get(offset).toInt() and 0xFF)
                    raw / 8388608.0f
                }
                C.ENCODING_PCM_8BIT -> ((view.get(offset).toInt() and 0xFF) - 128) / 128.0f
                else -> view.getShort(offset) / 32768.0f
            }
        }

        private fun downmixFrame(view: ByteBuffer, offset: Int, channels: Int): Float {
            if (channels == 1) return sampleAt(view, offset)
            val l = sampleAt(view, offset)
            val r = sampleAt(view, offset + bytesPerSample)
            if (channels >= 6) {
                // 5.1 / 7.1 : ordre Android FL, FR, FC, LFE... -> le dialogue est dans le canal central
                val c = sampleAt(view, offset + 2 * bytesPerSample)
                return c * 0.5f + (l + r) * 0.25f
            }
            return (l + r) * 0.5f
        }

        private fun pushSample(v: Float) {
            outChunk[outSize++] = if (v > 1f) 1f else if (v < -1f) -1f else v
            if (outSize >= outChunk.size) {
                enqueueChunk(outChunk.copyOf(outSize))
                outSize = 0
            }
        }

        private fun captureForSherpa(view: ByteBuffer) {
            val channels = inputChannelCount.coerceIn(1, 8)
            val bytesPerFrame = channels * bytesPerSample
            if (bytesPerFrame <= 0) return
            val base = view.position()
            val frames = (view.limit() - base) / bytesPerFrame
            if (frames <= 0) return
            if (monoBuffer.size < frames) monoBuffer = FloatArray(frames + 1024)
            val mono = monoBuffer

            // 1. Downmix mono + filtre anti-repliement
            var off = base
            for (f in 0 until frames) {
                var m = downmixFrame(view, off, channels)
                if (m.isNaN() || m.isInfinite()) m = 0f
                if (useLowPass) m = lowPassB.process(lowPassA.process(m))
                mono[f] = m
                off += bytesPerFrame
            }

            // 2. Rééchantillonnage linéaire vers 16 kHz (position fractionnaire conservée entre buffers)
            var t = readPos
            val last = frames - 1
            while (true) {
                val i0 = Math.floor(t).toInt() // t >= -1 ; i0 == -1 -> échantillon précédent
                if (i0 + 1 > last) break
                val frac = (t - i0).toFloat()
                val a = if (i0 < 0) prevSample else mono[i0]
                val b = mono[i0 + 1]
                pushSample(a + (b - a) * frac)
                t += step
            }
            readPos = t - frames
            prevSample = mono[last]
        }
    }
}
