package com.example.ui

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.PlaylistItem

// ---------------------------------------------------------------------------------------------
// Partage / copie des données de connexion des playlists (écran Réglages)
// ---------------------------------------------------------------------------------------------

private fun typeLabel(p: PlaylistItem): String = when {
    p.type.equals("xtream", ignoreCase = true) -> "XTREAM"
    p.type.equals("stalker", ignoreCase = true) -> "STALKER"
    else -> "M3U"
}

private fun typeColor(p: PlaylistItem): Color = when (typeLabel(p)) {
    "XTREAM" -> Color(0xFF8B5CF6)
    "STALKER" -> Color(0xFFF59E0B)
    else -> Color(0xFF10B981)
}

/** Texte structuré pour UNE playlist (selon son type). */
fun buildPlaylistShareText(p: PlaylistItem): String {
    val sb = StringBuilder()
    sb.appendLine("📺 ${p.name}")
    sb.appendLine("Type : ${typeLabel(p)}")
    when (typeLabel(p)) {
        "XTREAM" -> {
            sb.appendLine("Serveur / URL : ${p.url}")
            sb.appendLine("Utilisateur : ${p.username.orEmpty()}")
            sb.appendLine("Mot de passe : ${p.password.orEmpty()}")
        }
        "STALKER" -> {
            sb.appendLine("Portail : ${p.url}")
            sb.appendLine("Adresse MAC : ${p.macAddress.orEmpty()}")
            if (!p.ipAddress.isNullOrBlank()) sb.appendLine("IP : ${p.ipAddress}")
            if (!p.customIp.isNullOrBlank()) sb.appendLine("IP personnalisée : ${p.customIp}")
        }
        else -> {
            sb.appendLine("URL : ${p.url}")
            if (!p.username.isNullOrBlank()) sb.appendLine("Utilisateur : ${p.username}")
            if (!p.password.isNullOrBlank()) sb.appendLine("Mot de passe : ${p.password}")
        }
    }
    return sb.toString().trimEnd()
}

/** Récapitulatif de TOUTES les playlists. */
fun buildAllPlaylistsShareText(playlists: List<PlaylistItem>): String {
    if (playlists.isEmpty()) return ""
    val sb = StringBuilder()
    sb.appendLine("=== Mes playlists IPTV (${playlists.size}) ===")
    playlists.forEachIndexed { index, p ->
        sb.appendLine()
        sb.appendLine("--- ${index + 1}/${playlists.size} ---")
        sb.appendLine(buildPlaylistShareText(p))
    }
    return sb.toString().trimEnd()
}

fun copyTextToClipboard(context: Context, label: String, text: String) {
    try {
        val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText(label, text))
        Toast.makeText(context, "Copié dans le presse-papiers", Toast.LENGTH_SHORT).show()
    } catch (t: Throwable) {
        Toast.makeText(context, "Copie impossible : ${t.message}", Toast.LENGTH_LONG).show()
    }
}

/** Ouvre la feuille de partage native Android. */
fun shareText(context: Context, subject: String, text: String) {
    try {
        val send = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_SUBJECT, subject)
            putExtra(Intent.EXTRA_TEXT, text)
        }
        val chooser = Intent.createChooser(send, "Partager via").apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(chooser)
    } catch (t: Throwable) {
        // Beaucoup de Google TV n'ont aucune application de partage : on copie à la place
        copyTextToClipboard(context, subject, text)
        Toast.makeText(context, "Aucune application de partage : texte copié à la place", Toast.LENGTH_LONG).show()
    }
}

@Composable
private fun ShareActionButton(
    label: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    color: Color,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Row(
        modifier = modifier
            .background(color.copy(alpha = 0.15f), RoundedCornerShape(8.dp))
            .tvFocusable(focusedColor = color, borderRadius = 8.dp, onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 10.dp),
        horizontalArrangement = Arrangement.Center,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, contentDescription = null, tint = color, modifier = Modifier.size(18.dp))
        Spacer(modifier = Modifier.width(8.dp))
        Text(label, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold)
    }
}

/** Carte « Partage des Données de Playlists » à placer dans les Réglages. */
@Composable
fun PlaylistSharingCard(playlists: List<PlaylistItem>, onShowDetails: () -> Unit) {
    val context = LocalContext.current
    Card(
        colors = CardDefaults.cardColors(containerColor = Color(0xFF171C26)),
        border = BorderStroke(1.dp, Color(0xFF10B981).copy(alpha = 0.4f)),
        shape = RoundedCornerShape(12.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Icon(Icons.Default.Share, contentDescription = null, tint = Color(0xFF10B981), modifier = Modifier.size(22.dp))
                Text("Partage des Données de Playlists", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
            }
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = if (playlists.isEmpty()) "Aucune playlist enregistrée pour le moment."
                else "${playlists.size} playlist(s) : type, nom, URL, identifiants Xtream ou adresses MAC Stalker.",
                color = Color.Gray,
                fontSize = 14.sp
            )
            Spacer(modifier = Modifier.height(12.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                ShareActionButton("Partager Toutes", Icons.Default.Share, Color(0xFF10B981), Modifier.weight(1f)) {
                    if (playlists.isEmpty()) {
                        Toast.makeText(context, "Aucune playlist à partager", Toast.LENGTH_SHORT).show()
                    } else {
                        shareText(context, "Mes playlists IPTV", buildAllPlaylistsShareText(playlists))
                    }
                }
                ShareActionButton("Copier Tout", Icons.Default.ContentCopy, Color(0xFF00E5FF), Modifier.weight(1f)) {
                    if (playlists.isEmpty()) {
                        Toast.makeText(context, "Aucune playlist à copier", Toast.LENGTH_SHORT).show()
                    } else {
                        copyTextToClipboard(context, "Playlists IPTV", buildAllPlaylistsShareText(playlists))
                    }
                }
            }
            Spacer(modifier = Modifier.height(10.dp))
            ShareActionButton("Détails / Par Playlist", Icons.Default.Share, Color(0xFFF59E0B), Modifier.fillMaxWidth()) {
                onShowDetails()
            }
        }
    }
}

/** Dialogue : liste détaillée + Copier / Partager pour chaque playlist. */
@Composable
fun PlaylistDetailsDialog(playlists: List<PlaylistItem>, onDismiss: () -> Unit) {
    val context = LocalContext.current
    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Card(
            colors = CardDefaults.cardColors(containerColor = Color(0xFF0F172A)),
            border = BorderStroke(1.dp, Color(0xFF1E293B)),
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier.fillMaxWidth(0.85f).heightIn(max = 560.dp)
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                Text("Détails des playlists", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(12.dp))
                if (playlists.isEmpty()) {
                    Text("Aucune playlist enregistrée.", color = Color.Gray, fontSize = 15.sp)
                } else {
                    LazyColumn(
                        modifier = Modifier.weight(1f, fill = false),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        items(playlists, key = { it.id }) { p ->
                            Card(
                                colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B)),
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(modifier = Modifier.padding(14.dp)) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Box(
                                            modifier = Modifier
                                                .background(typeColor(p).copy(alpha = 0.2f), RoundedCornerShape(20.dp))
                                                .padding(horizontal = 10.dp, vertical = 3.dp)
                                        ) {
                                            Text(typeLabel(p), color = typeColor(p), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                        }
                                        Spacer(modifier = Modifier.width(10.dp))
                                        Text(p.name, color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                                    }
                                    Spacer(modifier = Modifier.height(8.dp))
                                    Text(
                                        buildPlaylistShareText(p).lines().drop(2).joinToString("\n"),
                                        color = Color(0xFFCBD5E1),
                                        fontSize = 12.sp,
                                        fontFamily = FontFamily.Monospace
                                    )
                                    Spacer(modifier = Modifier.height(10.dp))
                                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                                        ShareActionButton("Copier", Icons.Default.ContentCopy, Color(0xFF00E5FF), Modifier.weight(1f)) {
                                            copyTextToClipboard(context, p.name, buildPlaylistShareText(p))
                                        }
                                        ShareActionButton("Partager", Icons.Default.Share, Color(0xFF10B981), Modifier.weight(1f)) {
                                            shareText(context, p.name, buildPlaylistShareText(p))
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                Spacer(modifier = Modifier.height(12.dp))
                ShareActionButton("Fermer", Icons.Default.Share, Color(0xFF94A3B8), Modifier.fillMaxWidth()) { onDismiss() }
            }
        }
    }
}
