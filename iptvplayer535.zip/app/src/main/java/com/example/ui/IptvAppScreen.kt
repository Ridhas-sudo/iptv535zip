package com.example.ui

import com.example.data.*

import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.alpha
import android.util.Log
import android.widget.FrameLayout
import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.clickable
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.focusable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.draw.scale
import androidx.compose.ui.input.key.*
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.PointerEventType
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import coil.compose.AsyncImage
import com.example.data.ChannelItem
import com.example.data.PlaylistItem
import com.example.data.RecordingItem
import com.example.data.EpgProgram
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import androidx.compose.ui.zIndex
import androidx.compose.animation.*
import androidx.compose.animation.core.*

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.foundation.lazy.grid.itemsIndexed
import androidx.compose.foundation.Canvas
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.layout.ContentScale

private val CeylanColor = Color(0xFF0087BD)

fun Context.findActivity(): Activity? {
    var currentContext = this
    while (currentContext is ContextWrapper) {
        if (currentContext is Activity) return currentContext
        currentContext = currentContext.baseContext
    }
    return null
}

@Composable
fun IptvAppScreen(viewModel: IptvViewModel) {
    val context = LocalContext.current
    val activity = remember(context) { context.findActivity() }
    val currentScreen by viewModel.currentScreen.collectAsState()
    val selectedPlaylist by viewModel.selectedPlaylist.collectAsState()
    val selectedChannel by viewModel.selectedChannel.collectAsState()
    val isPlaying by viewModel.isPlaying.collectAsState()
    val isPipMode by viewModel.isPipMode.collectAsState()
    val playbackUrl by viewModel.playbackUrl.collectAsState()
    val playbackHeaders by viewModel.playbackHeaders.collectAsState()
    val isFullScreen by viewModel.isFullScreen.collectAsState()
    val isLiveCategorySelected by viewModel.isLiveCategorySelected.collectAsState()
    val isMovieCategorySelected by viewModel.isMovieCategorySelected.collectAsState()
    val seriesStep by viewModel.seriesStep.collectAsState()
    val recordingError by viewModel.recordingError.collectAsState()
    val resumeDialogData by viewModel.resumeDialogData.collectAsState()

    if (resumeDialogData != null) {
        ResumePlaybackDialog(
            data = resumeDialogData!!,
            onDismiss = { viewModel.dismissResumeDialog() }
        )
    }

    LaunchedEffect(recordingError) {
        val err = recordingError
        if (err != null) {
            Toast.makeText(context, err, Toast.LENGTH_LONG).show()
            viewModel.clearRecordingError()
        }
    }

    // Handle back button on remote (progressive navigation and exit)
    BackHandler(enabled = true) {
        if (isFullScreen) {
            val isLive = selectedChannel?.type == "Live" || selectedChannel?.type == "TV"
            val isSeries = selectedChannel?.type == "Series"
            viewModel.setFullScreen(false)
            if (!isLive) {
                viewModel.stopPlayback()
            }
            if (isSeries) {
                viewModel.setScreen("Series")
                viewModel.setSeriesStep("EpisodeScreen")
            }
        } else if (currentScreen == "Live" && isLiveCategorySelected) {
            viewModel.setLiveCategorySelected(false)
        } else if (currentScreen == "Movies" && isMovieCategorySelected) {
            viewModel.setMovieCategorySelected(false)
        } else if (currentScreen == "Series" && seriesStep != "CategoryScreen") {
            val prevStep = when (seriesStep) {
                "EpisodeScreen" -> "SeriesListScreen"
                "SeriesListScreen" -> "CategoryScreen"
                else -> "CategoryScreen"
            }
            viewModel.setSeriesStep(prevStep)
        } else if (currentScreen != "TvHome") {
            if (isPlaying) {
                viewModel.stopPlayback()
            }
            viewModel.setScreen("TvHome")
        } else {
            activity?.finish()
        }
    }

    if (isPipMode && playbackUrl != null) {
        // Minimal Pip View
        SimpleVideoPlayer(streamUrl = playbackUrl!!, headers = playbackHeaders, viewModel = viewModel)
    } else if (selectedChannel != null && isPlaying && isFullScreen) {
        // Full Screen Video Player
        FullScreenVideoPlayer(
            channel = selectedChannel!!,
            viewModel = viewModel,
            onClose = {
                val isLive = selectedChannel?.type == "Live" || selectedChannel?.type == "TV"
                val isSeries = selectedChannel?.type == "Series"
                viewModel.setFullScreen(false)
                if (!isLive) {
                    viewModel.stopPlayback()
                }
                if (isSeries) {
                    viewModel.setScreen("Series")
                    viewModel.setSeriesStep("EpisodeScreen")
                }
            }
        )
    } else {
        // Main App Layout
        val auroraGradient = Brush.linearGradient(
            colors = listOf(
                Color(0xFF09061C), // Deep midnight violet space
                Color(0xFF0F0B2F), // Deep navy violet
                Color(0xFF130E39), // Dark royal indigo
                Color(0xFF09061C)  // Deep midnight violet space
            )
        )
        var showSidebarMenu by remember { mutableStateOf(false) }

        Box(
            modifier = Modifier
                .fillMaxSize()
                .onKeyEvent { keyEvent ->
                    if (keyEvent.type == KeyEventType.KeyDown) {
                        val nativeCode = keyEvent.nativeKeyEvent.keyCode
                        if (isPlaying && !isFullScreen) {
                            when (nativeCode) {
                                166, 92 -> { // KEYCODE_CHANNEL_UP, KEYCODE_PAGE_UP
                                    viewModel.selectPreviousChannel()
                                    return@onKeyEvent true
                                }
                                167, 93 -> { // KEYCODE_CHANNEL_DOWN, KEYCODE_PAGE_DOWN
                                    viewModel.selectNextChannel()
                                    return@onKeyEvent true
                                }
                            }
                        }
                    }
                    false
                }
                .focusable()
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(auroraGradient)
            ) {
                // Content Area
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(start = 72.dp, top = 16.dp, end = 16.dp, bottom = 16.dp)
                ) {
                    when (currentScreen) {
                        "TvHome" -> TvHomeScreen(viewModel = viewModel)
                        "Playlists" -> PlaylistsSection(viewModel = viewModel)
                        "Live" -> TvLiveSection(viewModel = viewModel)
                        "Movies" -> TvMoviesSection(viewModel = viewModel)
                        "Series" -> TvSeriesSection(viewModel = viewModel)
                        "Multiview" -> MultiviewSection(viewModel = viewModel)
                        "History" -> HistorySection(viewModel = viewModel)
                        "Recordings" -> RecordingsSection(viewModel = viewModel)
                        "Settings" -> SettingsSection(viewModel = viewModel)
                        else -> TvHomeScreen(viewModel = viewModel)
                    }
                }

                // Always visible Left Sidebar
                Box(
                    modifier = Modifier
                        .fillMaxHeight()
                        .width(72.dp)
                        .background(Color(0xFF070417))
                        .border(
                            width = 1.dp,
                            color = Color(0xFF1C1540),
                            shape = RoundedCornerShape(topEnd = 16.dp, bottomEnd = 16.dp)
                        )
                        .align(Alignment.CenterStart)
                        .zIndex(10f)
                ) {
                    SidebarMenu(
                        currentScreen = currentScreen,
                        hasPlaylist = selectedPlaylist != null,
                        onScreenSelected = { screen ->
                            viewModel.setScreen(screen)
                        }
                    )
                }
            }

            // Small integrated player floating at the bottom right!
            // Only show it for Live TV channels when on Live TV or TvHome screens
            val isLiveChannel = selectedChannel?.type == "Live" || selectedChannel?.type == "TV"
            if (selectedChannel != null && isPlaying && !isFullScreen && isLiveChannel && currentScreen != "Live" && currentScreen != "Multiview" && currentScreen != "Recordings") {
                SmallIntegratedPlayer(
                    channel = selectedChannel!!,
                    playbackUrl = playbackUrl ?: "",
                    headers = playbackHeaders,
                    onFullScreen = { viewModel.setFullScreen(true) },
                    onClose = { viewModel.stopPlayback() },
                    viewModel = viewModel
                )
            }
        }
    }
}

@Composable
fun BoxScope.SmallIntegratedPlayer(
    channel: ChannelItem,
    playbackUrl: String,
    headers: Map<String, String>,
    onFullScreen: () -> Unit,
    onClose: () -> Unit,
    viewModel: IptvViewModel
) {
    Box(
        modifier = Modifier
            .align(Alignment.BottomEnd)
            .padding(24.dp)
            .width(320.dp)
            .height(180.dp)
            .background(Color.Black, shape = RoundedCornerShape(16.dp))
            .border(2.dp, Color(0xFF00E5FF).copy(alpha = 0.8f), shape = RoundedCornerShape(16.dp))
            .tvFocusable(
                focusedColor = Color(0xFF00E5FF),
                borderRadius = 16.dp,
                onClick = onFullScreen
            )
    ) {
        // Play the video stream using SimpleVideoPlayer
        SimpleVideoPlayer(
            streamUrl = playbackUrl,
            headers = headers,
            isMuted = false,
            viewModel = viewModel
        )

        // Overlay with Controls
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        colors = listOf(
                            Color.Black.copy(alpha = 0.5f),
                            Color.Transparent,
                            Color.Black.copy(alpha = 0.7f)
                        )
                    )
                )
        ) {
            // Top row with Title and Close Button
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = channel.name.uppercase(),
                    color = Color.White,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f).padding(end = 8.dp)
                )

                // Close Button to stop playback
                IconButton(
                    onClick = onClose,
                    modifier = Modifier
                        .size(24.dp)
                        .background(Color.Black.copy(alpha = 0.5f), shape = CircleShape)
                ) {
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = "Stop Playback",
                        tint = Color.White,
                        modifier = Modifier.size(12.dp)
                    )
                }
            }
        }
    }
}

@Composable
fun SidebarMenu(
    currentScreen: String,
    hasPlaylist: Boolean,
    onScreenSelected: (String) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxHeight()
            .width(72.dp)
            .verticalScroll(rememberScrollState())
            .padding(vertical = 12.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        SidebarItem(
            title = "Accueil TV",
            icon = Icons.Default.Home,
            isSelected = currentScreen == "TvHome",
            onClick = { onScreenSelected("TvHome") },
            testTag = "nav_tv_home"
        )
        SidebarItem(
            title = "Playlists",
            icon = Icons.Default.List,
            isSelected = currentScreen == "Playlists",
            onClick = { onScreenSelected("Playlists") },
            testTag = "nav_playlists"
        )
        if (hasPlaylist) {
            SidebarItem(
                title = "Multi-Écrans",
                icon = Icons.Default.Menu,
                isSelected = currentScreen == "Multiview",
                onClick = { onScreenSelected("Multiview") },
                testTag = "nav_multiview"
            )
            SidebarItem(
                title = "Direct REC",
                icon = Icons.Default.AccountBox,
                isSelected = currentScreen == "Recordings",
                onClick = { onScreenSelected("Recordings") },
                testTag = "nav_recordings"
            )
        }
        SidebarItem(
            title = "Réglages",
            icon = Icons.Default.Settings,
            isSelected = currentScreen == "Settings",
            onClick = { onScreenSelected("Settings") },
            testTag = "nav_settings"
        )
    }
}

@Composable
fun SidebarItem(
    title: String,
    icon: ImageVector,
    isSelected: Boolean,
    onClick: () -> Unit,
    testTag: String
) {
    val tint = if (isSelected) Color(0xFF00E5FF) else Color(0xFF8A85A6)
    val background = if (isSelected) Color(0xFF00E5FF).copy(alpha = 0.14f) else Color.Transparent

    Box(
        modifier = Modifier
            .size(68.dp)
            .clip(RoundedCornerShape(14.dp))
            .background(background)
            .border(
                width = if (isSelected) 2.dp else 0.dp,
                color = if (isSelected) Color(0xFF00E5FF) else Color.Transparent,
                shape = RoundedCornerShape(14.dp)
            )
            .tvFocusable(
                focusedColor = CeylanColor,
                borderRadius = 14.dp,
                onClick = onClick
            )
            .testTag(testTag),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Box {
                Icon(
                    imageVector = icon,
                    contentDescription = title,
                    tint = tint,
                    modifier = Modifier.size(26.dp)
                )
                if (title == "Direct REC") {
                    Box(
                        modifier = Modifier
                            .size(8.dp)
                            .align(Alignment.TopEnd)
                            .background(Color(0xFFEF4444), shape = CircleShape)
                    )
                }
            }
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = title,
                color = tint,
                fontSize = 10.5.sp,
                fontWeight = if (isSelected) FontWeight.Black else FontWeight.Bold,
                textAlign = TextAlign.Center,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
fun StepBubble(stepNumber: Int, title: String, active: Boolean, isCurrent: Boolean, modifier: Modifier = Modifier) {
    val bgColor = if (isCurrent) Color(0xFF10B981) else if (active) Color(0xFF1F2937) else Color(0xFF111827)
    val textColor = if (isCurrent) Color.White else if (active) Color(0xFFE5E7EB) else Color(0xFF6B7280)
    val borderColor = if (isCurrent) Color(0xFF10B981) else if (active) Color(0xFF10B981).copy(alpha = 0.5f) else Color(0xFF374151)
    
    Box(
        modifier = modifier
            .background(bgColor, shape = RoundedCornerShape(8.dp))
            .border(BorderStroke(1.dp, borderColor), shape = RoundedCornerShape(8.dp))
            .padding(8.dp),
        contentAlignment = Alignment.Center
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Box(
                modifier = Modifier
                    .size(18.dp)
                    .background(if (isCurrent) Color.White else if (active) Color(0xFF10B981) else Color(0xFF4B5563), shape = CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = stepNumber.toString(),
                    color = if (isCurrent) Color(0xFF10B981) else Color.White,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold
                )
            }
            Text(
                text = title,
                color = textColor,
                fontSize = 12.sp,
                fontWeight = if (isCurrent) FontWeight.Bold else FontWeight.Normal,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun PlaylistsSection(viewModel: IptvViewModel) {
    val playlists by viewModel.playlists.collectAsState()
    val selectedPlaylist by viewModel.selectedPlaylist.collectAsState()
    val importState by viewModel.importState.collectAsState()
    val playlistSummaries by viewModel.playlistSummaries.collectAsState()
    val webServerIp by viewModel.webServerIp.collectAsState()
    val webServerStatus by viewModel.webServerStatus.collectAsState()
    
    var showPanel by remember { mutableStateOf(false) }
    var editingPlaylist by remember { mutableStateOf<PlaylistItem?>(null) }
    var selectedPlaylistToDelete by remember { mutableStateOf<PlaylistItem?>(null) }
    var sortOption by remember { mutableStateOf(PlaylistSortOption.ALPHABETICAL) }

    val clipboardManager = LocalClipboardManager.current
    val context = LocalContext.current

    val extractDomainFromPlaylist = { playlist: PlaylistItem ->
        if (playlist.url.isBlank()) playlist.name
        else {
            try {
                val uri = android.net.Uri.parse(playlist.url)
                val host = uri.host ?: playlist.url.substringAfter("://").substringBefore("/").substringBefore(":")
                val clean = host.replace("www.", "").trim()
                if (clean.isNotEmpty()) clean else playlist.name
            } catch (e: Exception) {
                playlist.name
            }
        }
    }

    val sortedPlaylists = remember(playlists, playlistSummaries, sortOption) {
        when (sortOption) {
            PlaylistSortOption.ALPHABETICAL -> {
                playlists.sortedBy { extractDomainFromPlaylist(it).lowercase() }
            }
            PlaylistSortOption.LAST_SYNC -> {
                playlists.sortedByDescending { pl ->
                    context.getSharedPreferences("playlist_cache", android.content.Context.MODE_PRIVATE)
                        .getLong("last_updated_${pl.id}", 0L)
                }
            }
            PlaylistSortOption.CHANNEL_COUNT -> {
                playlists.sortedByDescending { pl ->
                    val sum = playlistSummaries[pl.id] ?: Triple(0, 0, 0)
                    sum.first + sum.second + sum.third
                }
            }
            PlaylistSortOption.STATUS -> {
                playlists.sortedWith(
                    compareByDescending<PlaylistItem> { pl ->
                        val sum = playlistSummaries[pl.id] ?: Triple(0, 0, 0)
                        sum.first + sum.second + sum.third > 0
                    }.thenByDescending { pl -> pl.isActive }
                     .thenBy { extractDomainFromPlaylist(it).lowercase() }
                )
            }
        }
    }
    val getClipboardText = {
        try {
            clipboardManager.getText()?.text ?: ""
        } catch (e: Exception) {
            Log.e("IptvAppScreen", "Clipboard access error: ${e.message}", e)
            ""
        }
    }

    // Form inputs state
    var selectedTab by remember { mutableStateOf(0) } // 0: M3U, 1: Xtream, 2: Stalker, 3: Bulk, 4: Number
    var name by remember { mutableStateOf("") }
    var url by remember { mutableStateOf("") }
    var username by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var macAddress by remember { mutableStateOf("00:1A:79:") }
    var ipAddress by remember { mutableStateOf("") }
    var hideDns by remember { mutableStateOf(false) }
    var bulkText by remember { mutableStateOf("") }
    var clearExistingBeforeBulkImport by remember { mutableStateOf(false) }
    var currentStep by remember { mutableStateOf(1) }
    var playlistNumber by remember { mutableStateOf("1") }
    var loadLive by remember { mutableStateOf(true) }
    var loadMovies by remember { mutableStateOf(true) }
    var loadSeries by remember { mutableStateOf(true) }
    var showTesterPlusieursMacScreen by remember { mutableStateOf(false) }

    val handlePasteStalkerUrl = {
        val rawText = getClipboardText().trim()
        val extracted = extractPortalUrl(rawText)
        if (extracted != null) {
            url = extracted
            Toast.makeText(context, "URL extraite : $extracted", Toast.LENGTH_SHORT).show()
        } else {
            Toast.makeText(context, "Aucune URL valide trouvée dans le presse-papiers", Toast.LENGTH_SHORT).show()
        }
    }

    val handlePasteMacAddress = {
        val rawText = getClipboardText().trim()
        val extracted = extractMacAddress(rawText)
        if (extracted != null) {
            macAddress = extracted
            Toast.makeText(context, "MAC extraite : $extracted", Toast.LENGTH_SHORT).show()
        } else {
            Toast.makeText(context, "Aucune adresse MAC valide trouvée dans le presse-papiers", Toast.LENGTH_SHORT).show()
        }
    }

    val handlePasteCustomIp = {
        val rawText = getClipboardText().trim()
        val extracted = extractIpAddress(rawText)
        if (extracted != null) {
            ipAddress = extracted
            Toast.makeText(context, "IP extraite : $extracted", Toast.LENGTH_SHORT).show()
        } else {
            Toast.makeText(context, "Aucune adresse IP valide trouvée", Toast.LENGTH_SHORT).show()
        }
    }

    var showSmartImportDialog by remember { mutableStateOf(false) }
    var smartParagraphText by remember { mutableStateOf("") }

    val handleSmartParagraphImport = { paragraphText: String ->
        val cleanText = paragraphText.trim()
        if (cleanText.isNotEmpty()) {
            val macRegex = Regex("(?i)\\b(?:[0-9A-F]{2}[:-]){5}[0-9A-F]{2}\\b")
            val foundMacs = macRegex.findAll(cleanText).map { it.value.uppercase() }.distinct().toList()

            val urlRegex = Regex("(?i)https?://[^\\s\"',;<>]+")
            val foundUrls = urlRegex.findAll(cleanText).map { it.value }.toList()

            val usernameRegex = Regex("(?i)(?:username|user|u)\\s*[:=]\\s*([^\\s;,]+)")
            val passwordRegex = Regex("(?i)(?:password|pass|p)\\s*[:=]\\s*([^\\s;,]+)")
            val userMatch = usernameRegex.find(cleanText)?.groupValues?.get(1)
            val passMatch = passwordRegex.find(cleanText)?.groupValues?.get(1)

            val foundUrl = foundUrls.firstOrNull() ?: ""

            if (foundMacs.isNotEmpty() || foundUrl.contains("/c/") || foundUrl.contains("stalker") || foundUrl.contains("portal")) {
                selectedTab = 2 // Stalker
                if (foundUrl.isNotEmpty()) url = foundUrl
                if (foundMacs.isNotEmpty()) macAddress = foundMacs.joinToString("\n")
                if (name.isBlank()) {
                    val existingNames = playlists.map { it.name }
                    name = extractStalkerPlaylistNameFromUrl(foundUrl, existingNames)
                }
                currentStep = 2
                Toast.makeText(context, "Saisie Intelligente: Nom '$name' et données Stalker extraits !", Toast.LENGTH_LONG).show()
            } else if (userMatch != null && passMatch != null) {
                selectedTab = 1 // Xtream
                if (foundUrl.isNotEmpty()) url = foundUrl
                username = userMatch
                password = passMatch
                if (name.isBlank()) name = "Xtream IPTV"
                currentStep = 2
                Toast.makeText(context, "Saisie Intelligente: Identifiants Xtream extraits!", Toast.LENGTH_LONG).show()
            } else if (foundUrl.isNotEmpty()) {
                selectedTab = 0 // M3U
                url = foundUrl
                if (name.isBlank()) name = "Playlist M3U"
                currentStep = 2
                Toast.makeText(context, "Saisie Intelligente: URL M3U extraite!", Toast.LENGTH_LONG).show()
            } else {
                Toast.makeText(context, "Aucune donnée pertinente trouvée dans le texte fourni.", Toast.LENGTH_SHORT).show()
            }
        }
    }

    val startEditing = { playlist: PlaylistItem ->
        editingPlaylist = playlist
        name = playlist.name
        url = playlist.url
        username = playlist.username ?: ""
        password = playlist.password ?: ""
        macAddress = playlist.macAddress ?: "00:1A:79:"
        ipAddress = playlist.customIp ?: playlist.ipAddress ?: ""
        val (lLive, lMovies, lSeries) = viewModel.getPlaylistLoadSettings(playlist.id)
        loadLive = lLive
        loadMovies = lMovies
        loadSeries = lSeries
        selectedTab = when (playlist.type) {
            "M3U" -> 0
            "Xtream" -> 1
            "Stalker" -> 2
            else -> 0
        }
        currentStep = 1
        showPanel = true
    }

    val clearForm = {
        name = ""
        url = ""
        username = ""
        password = ""
        macAddress = "00:1A:79:"
        ipAddress = ""
        bulkText = ""
        clearExistingBeforeBulkImport = false
        editingPlaylist = null
        currentStep = 1
        playlistNumber = "1"
        loadLive = true
        loadMovies = true
        loadSeries = true
    }

    val handleSaveOrImport = {
        val isStalker = selectedTab == 2 || (editingPlaylist != null && editingPlaylist!!.type == "Stalker")
        val isXtream = selectedTab == 1 || (editingPlaylist != null && editingPlaylist!!.type == "Xtream")
        val isM3u = selectedTab == 0 || (editingPlaylist != null && editingPlaylist!!.type == "M3U")

        if (isM3u || isXtream || isStalker) {
            val urlTrimmed = url.trim()
            if (isM3u && urlTrimmed == "Internal Demo") {
                // demo is fine
                if (editingPlaylist != null) {
                    val pl = editingPlaylist!!
                    viewModel.savePlaylistLoadSettings(pl.id, loadLive, loadMovies, loadSeries)
                    val updated = pl.copy(
                        name = name,
                        url = url,
                        username = if (pl.type == "Xtream") username else pl.username,
                        password = if (pl.type == "Xtream") password else pl.password,
                        macAddress = if (pl.type == "Stalker") macAddress else pl.macAddress,
                        ipAddress = if (pl.type == "Stalker") ipAddress else pl.ipAddress,
                        customIp = if (pl.type == "Stalker") ipAddress else pl.customIp
                    )
                    viewModel.updatePlaylist(updated)
                    showPanel = false
                    clearForm()
                } else {
                    viewModel.createDemoPlaylist()
                }
            } else if (!urlTrimmed.startsWith("http", ignoreCase = true)) {
                Toast.makeText(context, "L'URL doit commencer par http:// ou https://", Toast.LENGTH_SHORT).show()
            } else {
                var valid = true
                if (isStalker) {
                    val macList = macAddress.split(Regex("[,;\\s\\n\\r]+")).map { it.trim() }.filter { it.isNotEmpty() }
                    val macRegex = "^([0-9A-Fa-f]{2}[:-]){5}([0-9A-Fa-f]{2})$".toRegex()
                    val hasValidMac = macList.any { macRegex.matches(it) }
                    if (macList.isEmpty() || !hasValidMac) {
                        Toast.makeText(context, "Au moins une adresse MAC valide est requise (ex: 00:1A:79:XX:XX:XX)", Toast.LENGTH_SHORT).show()
                        valid = false
                    }
                    if (valid && ipAddress.trim().isNotEmpty()) {
                        val ipRegex = """^((25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$""".toRegex()
                        if (!ipRegex.matches(ipAddress.trim())) {
                            Toast.makeText(context, "Adresse IP personnalisée invalide (format IPv4 requis)", Toast.LENGTH_SHORT).show()
                            valid = false
                        }
                    }
                }

                if (valid) {
                    if (editingPlaylist != null) {
                        val pl = editingPlaylist!!
                        viewModel.savePlaylistLoadSettings(pl.id, loadLive, loadMovies, loadSeries)
                        val updated = pl.copy(
                            name = name,
                            url = url,
                            username = if (pl.type == "Xtream") username else pl.username,
                            password = if (pl.type == "Xtream") password else pl.password,
                            macAddress = if (pl.type == "Stalker") macAddress else pl.macAddress,
                            ipAddress = if (pl.type == "Stalker") ipAddress else pl.ipAddress,
                            customIp = if (pl.type == "Stalker") ipAddress else pl.customIp
                        )
                        viewModel.updatePlaylist(updated)
                        showPanel = false
                        clearForm()
                    } else {
                        if (selectedTab == 0) {
                            if (url == "Internal Demo" || url.isBlank()) {
                                viewModel.createDemoPlaylist()
                            } else {
                                viewModel.importM3uPlaylist(name, url)
                            }
                        } else if (selectedTab == 1) {
                            viewModel.importXtreamPlaylist(name, url, username, password, loadLive, loadMovies, loadSeries)
                        } else if (selectedTab == 2) {
                            val finalStalkerName = if (name.isBlank()) {
                                extractStalkerPlaylistNameFromUrl(url, playlists.map { it.name })
                            } else {
                                name.trim()
                            }
                            viewModel.importStalkerPortal(finalStalkerName, url, macAddress, hideDns, ipAddress, loadLive, loadMovies, loadSeries)
                        }
                    }
                }
            }
        } else if (selectedTab == 3) { // Bulk
            if (editingPlaylist != null) {
                // not possible in bulk edit
            } else {
                viewModel.importBulkPlaylists(parseBulkImportText(bulkText), clearExistingBeforeBulkImport)
            }
        }
    }

    Column(modifier = Modifier.fillMaxSize()) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "Playlists Manager",
                color = Color.White,
                fontSize = 24.sp,
                fontWeight = FontWeight.Bold
            )
            
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(
                    onClick = { 
                        if (showPanel) {
                            showPanel = false
                            clearForm()
                        } else {
                            clearForm()
                            showPanel = true
                        }
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (showPanel) Color(0xFFEF4444) else Color(0xFF10B981)
                    ),
                    modifier = Modifier.tvFocusable(onClick = {
                        if (showPanel) {
                            showPanel = false
                            clearForm()
                        } else {
                            clearForm()
                            showPanel = true
                        }
                    })
                ) {
                    Icon(
                        imageVector = if (showPanel) Icons.Default.Close else Icons.Default.Add, 
                        contentDescription = "Toggle Panel", 
                        tint = Color.White
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(if (showPanel) "Fermer le panneau" else "Ajouter Playlist", color = Color.White)
                }
            }
        }

        // Import / Refresh Progress Banner
        if (importState != ImportState.Idle) {
            Card(
                colors = CardDefaults.cardColors(
                    containerColor = when (importState) {
                        is ImportState.Loading -> Color(0xFF1E293B)
                        is ImportState.Error -> Color(0xFF7F1D1D)
                        is ImportState.Success -> Color(0xFF064E3B)
                        else -> Color(0xFF171C26)
                    }
                ),
                border = BorderStroke(
                    1.dp,
                    when (importState) {
                        is ImportState.Loading -> Color(0xFF3B82F6)
                        is ImportState.Error -> Color(0xFFEF4444)
                        is ImportState.Success -> Color(0xFF10B981)
                        else -> Color(0xFF10B981)
                    }
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp)
            ) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.weight(1f)
                    ) {
                        if (importState is ImportState.Loading) {
                            CircularProgressIndicator(
                                color = Color(0xFF10B981),
                                modifier = Modifier.size(20.dp),
                                strokeWidth = 2.dp
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(
                                text = (importState as ImportState.Loading).message,
                                color = Color.White,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                        } else if (importState is ImportState.Error) {
                            Icon(
                                imageVector = Icons.Default.Warning,
                                contentDescription = "Erreur",
                                tint = Color(0xFFEF4444),
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(
                                text = (importState as ImportState.Error).message,
                                color = Color.White,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                        } else if (importState is ImportState.Success) {
                            Icon(
                                imageVector = Icons.Default.Check,
                                contentDescription = "Succès",
                                tint = Color(0xFF10B981),
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(
                                text = (importState as ImportState.Success).message,
                                color = Color.White,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }
                    
                    IconButton(
                        onClick = { viewModel.clearImportState() },
                        modifier = Modifier.size(24.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Fermer",
                            tint = Color.White
                        )
                    }
                }
            }
        }

        // Expandable Panel
        AnimatedVisibility(visible = showPanel) {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF171C26)),
                border = BorderStroke(1.dp, Color(0xFF10B981)),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 12.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .verticalScroll(rememberScrollState())
                        .padding(16.dp)
                ) {
                    // Dynamic Progressive Steps Indicator
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        StepBubble(stepNumber = 1, title = "Source", active = currentStep >= 1, isCurrent = currentStep == 1, modifier = Modifier.weight(1f))
                        StepBubble(stepNumber = 2, title = "Saisie", active = currentStep >= 2, isCurrent = currentStep == 2, modifier = Modifier.weight(1f))
                        StepBubble(stepNumber = 3, title = "Connexion", active = currentStep >= 3, isCurrent = currentStep == 3, modifier = Modifier.weight(1f))
                    }

                    if (currentStep == 1) {
                        Text(
                            text = if (editingPlaylist != null) "Modifier la Playlist : Étape 1/3" else "Ajouter une nouvelle Playlist : Étape 1/3",
                            color = Color.White,
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                        
                        // Embedded Web Server Info for Remote Adding on TV
                        if (webServerIp != null) {
                            Card(
                                colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B)),
                                border = BorderStroke(1.dp, Color(0xFF10B981)),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(bottom = 12.dp)
                            ) {
                                Row(
                                    modifier = Modifier.padding(12.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Info,
                                        contentDescription = "Télécommande Web",
                                        tint = Color(0xFF10B981),
                                        modifier = Modifier.size(24.dp)
                                    )
                                    Spacer(modifier = Modifier.width(10.dp))
                                    Column {
                                        Text(
                                            text = "Importation à distance (Évite la saisie sur TV) :",
                                            color = Color.White,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 13.sp
                                        )
                                        Text(
                                            text = "Ouvrez cette adresse sur votre téléphone ou PC (même Wi-Fi) :",
                                            color = Color.LightGray,
                                            fontSize = 11.sp
                                        )
                                        Text(
                                            text = "http://$webServerIp:8080",
                                            color = Color(0xFF00E5FF),
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 15.sp,
                                            modifier = Modifier.padding(top = 2.dp)
                                        )
                                    }
                                }
                            }
                        }

                        if (editingPlaylist == null) {
                            Text("Type de Playlist (Sélectionnez une option) :", color = Color.Gray, fontSize = 12.sp)
                            Spacer(modifier = Modifier.height(4.dp))
                            TabRow(
                                selectedTabIndex = selectedTab,
                                containerColor = Color(0xFF171C26),
                                contentColor = Color(0xFF10B981)
                            ) {
                                Tab(selected = selectedTab == 0, onClick = { selectedTab = 0 }) {
                                    Text("Lien M3U", modifier = Modifier.padding(8.dp), color = Color.White, fontSize = 11.sp)
                                }
                                Tab(selected = selectedTab == 1, onClick = { selectedTab = 1 }) {
                                    Text("Xtream Codes", modifier = Modifier.padding(8.dp), color = Color.White, fontSize = 11.sp)
                                }
                                Tab(selected = selectedTab == 2, onClick = { selectedTab = 2 }) {
                                    Text("Stalker Portal", modifier = Modifier.padding(8.dp), color = Color.White, fontSize = 11.sp)
                                }
                                Tab(selected = selectedTab == 3, onClick = { selectedTab = 3 }) {
                                    Text("Import de Masse", modifier = Modifier.padding(8.dp), color = Color.White, fontSize = 11.sp)
                                }
                            }
                            Spacer(modifier = Modifier.height(12.dp))
                        }



                        if (selectedTab != 3) {
                            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                Button(
                                    onClick = { 
                                        val clipText = getClipboardText().trim()
                                        if (clipText.isNotEmpty()) {
                                            smartParagraphText = clipText
                                        }
                                        showSmartImportDialog = true 
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF6366F1)),
                                    modifier = Modifier.fillMaxWidth().tvFocusable(onClick = { 
                                        val clipText = getClipboardText().trim()
                                        if (clipText.isNotEmpty()) {
                                            smartParagraphText = clipText
                                        }
                                        showSmartImportDialog = true 
                                    })
                                ) {
                                    Icon(Icons.Default.Star, contentDescription = "Saisie Intelligente", tint = CeylanColor, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text("🧠 Saisie Intelligente (Extraction Auto depuis Paragraphe)", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color.White)
                                }

                                OutlinedTextField(
                                    value = name,
                                    onValueChange = { name = it },
                                    label = { Text("Nom de la playlist (ex: Ma Télévision)", color = Color(0xFF9CA3AF)) },
                                    modifier = Modifier.fillMaxWidth(),
                                    colors = OutlinedTextFieldDefaults.colors(focusedTextColor = Color.White, unfocusedTextColor = Color.White)
                                )
                            }
                        } else {
                            Text("L'import de masse génère automatiquement les noms des playlists.", color = Color.Gray, fontSize = 12.sp)
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.End
                        ) {
                            Button(
                                onClick = { 
                                    showPanel = false
                                    clearForm()
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF374151)),
                                modifier = Modifier.padding(end = 8.dp).tvFocusable(onClick = { 
                                    showPanel = false
                                    clearForm()
                                })
                            ) {
                                Text("Annuler")
                            }

                            Button(
                                onClick = { 
                                    currentStep = 2 
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF10B981)),
                                modifier = Modifier.tvFocusable(onClick = { 
                                    currentStep = 2 
                                })
                            ) {
                                Text("Étape Suivante : Saisie ➔")
                            }
                        }
                    }

                    if (currentStep == 2) {
                        Text(
                            text = "Saisie des Coordonnées : Étape 2/3",
                            color = Color.White,
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(10.dp))

                        if (selectedTab == 0) {
                            // M3U URL field
                            Column(modifier = Modifier.fillMaxWidth()) {
                                OutlinedTextField(
                                    value = url,
                                    onValueChange = { 
                                        url = it
                                    },
                                    label = { Text("Lien M3U (URL du fichier ou lien direct)", color = Color(0xFF9CA3AF)) },
                                    modifier = Modifier.fillMaxWidth(),
                                    colors = OutlinedTextFieldDefaults.colors(focusedTextColor = Color.White, unfocusedTextColor = Color.White)
                                )
                                Spacer(modifier = Modifier.height(8.dp))

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    Button(
                                        onClick = { 
                                            val clipboard = clipboardManager.getText()?.text ?: ""
                                            val ext = extractPortalUrl(clipboard)
                                            if (ext != null) {
                                                url = ext
                                                Toast.makeText(context, "URL M3U extraite : $ext", Toast.LENGTH_SHORT).show()
                                            } else {
                                                url = clipboard
                                            }
                                        },
                                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF10B981)),
                                        modifier = Modifier.weight(1f).tvFocusable(onClick = { 
                                            val clipboard = clipboardManager.getText()?.text ?: ""
                                            val ext = extractPortalUrl(clipboard)
                                            if (ext != null) {
                                                url = ext
                                                Toast.makeText(context, "URL M3U extraite : $ext", Toast.LENGTH_SHORT).show()
                                            } else {
                                                url = clipboard
                                            }
                                        })
                                    ) {
                                        Icon(Icons.Default.Add, contentDescription = "Coller", modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text("📋 Coller le lien", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color.White)
                                    }

                                    Button(
                                        onClick = { clipboardManager.setText(AnnotatedString(url)) },
                                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E2430)),
                                        border = BorderStroke(1.dp, Color(0xFF374151)),
                                        modifier = Modifier.weight(1f).tvFocusable(onClick = { clipboardManager.setText(AnnotatedString(url)) })
                                    ) {
                                        Icon(Icons.Default.Share, contentDescription = "Copier", tint = Color(0xFF00E5FF), modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text("💾 Copier", fontSize = 12.sp, color = Color.White)
                                    }

                                    Button(
                                        onClick = { url = "" },
                                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFEF4444).copy(alpha = 0.2f)),
                                        border = BorderStroke(1.dp, Color(0xFFEF4444)),
                                        modifier = Modifier.weight(1f).tvFocusable(onClick = { url = "" })
                                    ) {
                                        Icon(Icons.Default.Clear, contentDescription = "Effacer", tint = Color(0xFFEF4444), modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text("❌ Effacer", fontSize = 12.sp, color = Color.White)
                                    }
                                }
                            }
                        }

                        if (selectedTab == 1) {
                            // Xtream API fields
                            Column(modifier = Modifier.fillMaxWidth()) {
                                OutlinedTextField(
                                    value = url,
                                    onValueChange = { 
                                        url = it
                                    },
                                    label = { Text("URL API de Base (ex: http://serveuriptv.com:80)", color = Color(0xFF9CA3AF)) },
                                    modifier = Modifier.fillMaxWidth(),
                                    colors = OutlinedTextFieldDefaults.colors(focusedTextColor = Color.White, unfocusedTextColor = Color.White)
                                )
                                Spacer(modifier = Modifier.height(6.dp))

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Button(
                                        onClick = { 
                                            val clipboard = clipboardManager.getText()?.text ?: ""
                                            val ext = extractPortalUrl(clipboard)
                                            if (ext != null) {
                                                url = ext
                                                Toast.makeText(context, "URL Xtream extraite : $ext", Toast.LENGTH_SHORT).show()
                                            } else {
                                                url = clipboard
                                            }
                                        },
                                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF10B981)),
                                        modifier = Modifier.weight(1f).tvFocusable(onClick = { 
                                            val clipboard = clipboardManager.getText()?.text ?: ""
                                            val ext = extractPortalUrl(clipboard)
                                            if (ext != null) {
                                                url = ext
                                                Toast.makeText(context, "URL Xtream extraite : $ext", Toast.LENGTH_SHORT).show()
                                            } else {
                                                url = clipboard
                                            }
                                        })
                                    ) {
                                        Text("📋 Coller URL", fontSize = 11.sp, color = Color.White)
                                    }
                                    Button(
                                        onClick = { url = "" },
                                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF374151)),
                                        modifier = Modifier.weight(1f).tvFocusable(onClick = { url = "" })
                                    ) {
                                        Text("Effacer URL", fontSize = 11.sp, color = Color.White)
                                    }
                                }

                                Spacer(modifier = Modifier.height(10.dp))

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        OutlinedTextField(
                                            value = username,
                                            onValueChange = { username = it },
                                            label = { Text("Nom d'utilisateur", color = Color(0xFF9CA3AF)) },
                                            modifier = Modifier.fillMaxWidth(),
                                            colors = OutlinedTextFieldDefaults.colors(focusedTextColor = Color.White, unfocusedTextColor = Color.White)
                                        )
                                        Spacer(modifier = Modifier.height(4.dp))
                                        Button(
                                            onClick = { username = clipboardManager.getText()?.text ?: "" },
                                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E2430)),
                                            modifier = Modifier.fillMaxWidth().tvFocusable(onClick = { username = clipboardManager.getText()?.text ?: "" })
                                        ) {
                                            Text("📋 Coller User", fontSize = 11.sp)
                                        }
                                    }

                                    Column(modifier = Modifier.weight(1f)) {
                                        OutlinedTextField(
                                            value = password,
                                            onValueChange = { password = it },
                                            label = { Text("Mot de passe", color = Color(0xFF9CA3AF)) },
                                            modifier = Modifier.fillMaxWidth(),
                                            colors = OutlinedTextFieldDefaults.colors(focusedTextColor = Color.White, unfocusedTextColor = Color.White)
                                        )
                                        Spacer(modifier = Modifier.height(4.dp))
                                        Button(
                                            onClick = { password = clipboardManager.getText()?.text ?: "" },
                                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E2430)),
                                            modifier = Modifier.fillMaxWidth().tvFocusable(onClick = { password = clipboardManager.getText()?.text ?: "" })
                                        ) {
                                            Text("📋 Coller Pass", fontSize = 11.sp)
                                        }
                                    }
                                }
                            }
                        }

                        if (selectedTab == 2) {
                            // Stalker Portal URL & MAC
                            Column(modifier = Modifier.fillMaxWidth()) {
                                OutlinedTextField(
                                    value = url,
                                    onValueChange = { 
                                        url = it
                                    },
                                    label = { Text("URL du Portail Stalker (ex: http://stalkerportal.live/c/)", color = Color(0xFF9CA3AF)) },
                                    modifier = Modifier.fillMaxWidth(),
                                    colors = OutlinedTextFieldDefaults.colors(focusedTextColor = Color.White, unfocusedTextColor = Color.White)
                                )
                                Spacer(modifier = Modifier.height(6.dp))

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Button(
                                        onClick = { handlePasteStalkerUrl() },
                                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF10B981)),
                                        modifier = Modifier.weight(1f).tvFocusable(onClick = { handlePasteStalkerUrl() })
                                    ) {
                                        Text("📋 Coller Portail URL", fontSize = 11.sp, color = Color.White)
                                    }
                                    Button(
                                        onClick = { url = "" },
                                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF374151)),
                                        modifier = Modifier.weight(1f).tvFocusable(onClick = { url = "" })
                                    ) {
                                        Text("Effacer", fontSize = 11.sp, color = Color.White)
                                    }
                                }

                                Spacer(modifier = Modifier.height(10.dp))

                                OutlinedTextField(
                                    value = macAddress,
                                    onValueChange = { 
                                        macAddress = it
                                    },
                                    label = { Text("Adresse(s) MAC (une par ligne ou séparées par virgules)", color = Color(0xFF9CA3AF)) },
                                    minLines = 2,
                                    maxLines = 5,
                                    modifier = Modifier.fillMaxWidth(),
                                    colors = OutlinedTextFieldDefaults.colors(focusedTextColor = Color.White, unfocusedTextColor = Color.White)
                                )
                                Spacer(modifier = Modifier.height(6.dp))

                                Button(
                                    onClick = { handlePasteMacAddress() },
                                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF10B981)),
                                    modifier = Modifier.fillMaxWidth().tvFocusable(onClick = { handlePasteMacAddress() })
                                ) {
                                    Icon(Icons.Default.Add, contentDescription = "Coller MAC", modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("📋 Coller adresse(s) MAC (Support de masse)", fontSize = 12.sp, color = Color.White)
                                }

                                Spacer(modifier = Modifier.height(8.dp))

                                Button(
                                    onClick = { 
                                        showTesterPlusieursMacScreen = true 
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF8B5CF6)),
                                    modifier = Modifier.fillMaxWidth().tvFocusable(onClick = { showTesterPlusieursMacScreen = true })
                                ) {
                                    Icon(Icons.Default.PlayArrow, contentDescription = "Tester plusieurs MAC", modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("🧪 Tester plusieurs MAC", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color.White)
                                }

                                Spacer(modifier = Modifier.height(10.dp))

                                OutlinedTextField(
                                    value = ipAddress,
                                    onValueChange = { 
                                        ipAddress = it
                                    },
                                    label = { Text("Adresse IP personnalisée (Optionnel - ex: 192.168.1.50)", color = Color(0xFF9CA3AF)) },
                                    modifier = Modifier.fillMaxWidth(),
                                    colors = OutlinedTextFieldDefaults.colors(focusedTextColor = Color.White, unfocusedTextColor = Color.White)
                                )
                                Spacer(modifier = Modifier.height(6.dp))

                                Button(
                                    onClick = { handlePasteCustomIp() },
                                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF10B981)),
                                    modifier = Modifier.fillMaxWidth().tvFocusable(onClick = { handlePasteCustomIp() })
                                ) {
                                    Icon(Icons.Default.Add, contentDescription = "Coller IP", modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("📋 Coller l'adresse IP depuis le presse-papiers", fontSize = 12.sp, color = Color.White)
                                }
                            }
                        }

                        if (selectedTab == 1 || selectedTab == 2) {
                            Spacer(modifier = Modifier.height(16.dp))
                            Card(
                                colors = CardDefaults.cardColors(containerColor = Color(0xFF1E2430)),
                                border = BorderStroke(1.dp, Color(0xFF374151)),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(modifier = Modifier.padding(12.dp)) {
                                    Text(
                                        text = "Contenu à charger",
                                        color = Color(0xFF00E5FF),
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 14.sp
                                    )
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        text = "Décochez les types de contenu inutiles pour accélérer considérablement le téléchargement.",
                                        color = Color.Gray,
                                        fontSize = 11.sp
                                    )
                                    Spacer(modifier = Modifier.height(12.dp))

                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.spacedBy(16.dp)
                                    ) {
                                        // Live TV Checkbox
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            modifier = Modifier
                                                .weight(1f)
                                                .tvFocusable(onClick = { loadLive = !loadLive })
                                                .padding(vertical = 4.dp)
                                        ) {
                                            Checkbox(
                                                checked = loadLive,
                                                onCheckedChange = { loadLive = it },
                                                colors = CheckboxDefaults.colors(checkedColor = Color(0xFF10B981))
                                            )
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Column {
                                                Text("Chaînes Live", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                                                Text("TV en direct", color = Color.Gray, fontSize = 10.sp)
                                            }
                                        }

                                        // Movies Checkbox
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            modifier = Modifier
                                                .weight(1f)
                                                .tvFocusable(onClick = { loadMovies = !loadMovies })
                                                .padding(vertical = 4.dp)
                                        ) {
                                            Checkbox(
                                                checked = loadMovies,
                                                onCheckedChange = { loadMovies = it },
                                                colors = CheckboxDefaults.colors(checkedColor = Color(0xFF10B981))
                                            )
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Column {
                                                Text("Films (VOD)", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                                                Text("Cinéma", color = Color.Gray, fontSize = 10.sp)
                                            }
                                        }

                                        // Series Checkbox
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            modifier = Modifier
                                                .weight(1f)
                                                .tvFocusable(onClick = { loadSeries = !loadSeries })
                                                .padding(vertical = 4.dp)
                                        ) {
                                            Checkbox(
                                                checked = loadSeries,
                                                onCheckedChange = { loadSeries = it },
                                                colors = CheckboxDefaults.colors(checkedColor = Color(0xFF10B981))
                                            )
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Column {
                                                Text("Séries", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                                                Text("Feuilletons", color = Color.Gray, fontSize = 10.sp)
                                            }
                                        }
                                    }
                                    
                                    // Safety check
                                    if (!loadLive && !loadMovies && !loadSeries) {
                                        Spacer(modifier = Modifier.height(8.dp))
                                        Text(
                                            text = "⚠️ Vous devez sélectionner au moins un type de contenu.",
                                            color = Color(0xFFEF4444),
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }
                            }
                        }

                        if (selectedTab == 3) {
                            // Bulk Text area
                            Column(modifier = Modifier.fillMaxWidth()) {
                                Text("Format : Nom de la playlist,Lien ou MAC,stalker/m3u (une playlist par ligne)", color = Color(0xFF9CA3AF), fontSize = 11.sp)
                                Spacer(modifier = Modifier.height(4.dp))
                                OutlinedTextField(
                                    value = bulkText,
                                    onValueChange = { bulkText = it },
                                    placeholder = { Text("Ex: Ma Playlist,http://example.com/live.m3u", color = Color(0xFF4B5563)) },
                                    modifier = Modifier.fillMaxWidth(),
                                    colors = OutlinedTextFieldDefaults.colors(focusedTextColor = Color.White, unfocusedTextColor = Color.White)
                                )
                                Spacer(modifier = Modifier.height(6.dp))

                                Button(
                                    onClick = { bulkText = clipboardManager.getText()?.text ?: "" },
                                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF10B981)),
                                    modifier = Modifier.fillMaxWidth().tvFocusable(onClick = { bulkText = clipboardManager.getText()?.text ?: "" })
                                ) {
                                    Icon(Icons.Default.Add, contentDescription = "Coller Bulk", modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("📋 Coller tout le texte de masse", fontSize = 12.sp, color = Color.White)
                                }

                                Spacer(modifier = Modifier.height(12.dp))
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .tvFocusable(onClick = { clearExistingBeforeBulkImport = !clearExistingBeforeBulkImport })
                                        .padding(8.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text("Remplacer uniquement les anciennes playlists M3U", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                                        Text("Conserve TOUS vos portails Stalker et comptes Xtream existants", color = Color(0xFF10B981), fontSize = 11.sp)
                                    }
                                    Switch(
                                        checked = clearExistingBeforeBulkImport,
                                        onCheckedChange = { clearExistingBeforeBulkImport = it },
                                        colors = SwitchDefaults.colors(checkedThumbColor = Color(0xFF10B981))
                                    )
                                }
                            }
                        }



                        Spacer(modifier = Modifier.height(16.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Button(
                                onClick = { currentStep = 1 },
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF374151)),
                                modifier = Modifier.tvFocusable(onClick = { currentStep = 1 })
                            ) {
                                Text("⬅ Étape Précédente")
                            }

                            Button(
                                onClick = { currentStep = 3 },
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF10B981)),
                                modifier = Modifier.tvFocusable(onClick = { currentStep = 3 })
                            ) {
                                Text("Suivant : Connexion ➔")
                            }
                        }
                    }

                    if (currentStep == 3) {
                        Text(
                            text = "Aperçu & Connexion : Étape 3/3",
                            color = Color.White,
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(10.dp))

                        Card(
                            colors = CardDefaults.cardColors(containerColor = Color(0xFF1E2430)),
                            border = BorderStroke(1.dp, Color(0xFF374151)),
                            modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp)
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Text("Récapitulatif des paramètres", color = Color(0xFF10B981), fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                Spacer(modifier = Modifier.height(8.dp))
                                
                                val typeStr = when (selectedTab) {
                                    0 -> "Fichier / Lien M3U"
                                    1 -> "Xtream Codes API"
                                    2 -> "Portail Stalker"
                                    else -> "Importation de Masse (Bulk)"
                                }
                                Text("• Type : $typeStr", color = Color.White, fontSize = 13.sp)
                                val displayName = if (name.isNotBlank()) {
                                    name
                                } else if (selectedTab == 2 && url.isNotBlank()) {
                                    extractStalkerPlaylistNameFromUrl(url, playlists.map { it.name })
                                } else {
                                    "(Sans nom - Automatique)"
                                }
                                Text("• Nom : $displayName", color = Color.White, fontSize = 13.sp)
                                if (selectedTab != 3) {
                                    Text("• Adresse URL : ${url.ifBlank { "Non renseigné" }}", color = Color.White, fontSize = 13.sp)
                                }
                                if (selectedTab == 1) {
                                    Text("• Utilisateur : ${username.ifBlank { "Non renseigné" }}", color = Color.White, fontSize = 13.sp)
                                    Text("• Mot de passe : ${if (password.isNotEmpty()) "••••••••" else "Non renseigné"}", color = Color.White, fontSize = 13.sp)
                                }
                                if (selectedTab == 2) {
                                    Text("• Adresse MAC : $macAddress", color = Color.White, fontSize = 13.sp)
                                }
                                if (selectedTab == 1 || selectedTab == 2) {
                                    val types = mutableListOf<String>()
                                    if (loadLive) types.add("Chaînes Live")
                                    if (loadMovies) types.add("Films (VOD)")
                                    if (loadSeries) types.add("Séries")
                                    Text("• Contenu sélectionné : ${if (types.isEmpty()) "Aucun (Erreur)" else types.joinToString(", ")}", color = Color.White, fontSize = 13.sp)
                                }
                                if (selectedTab == 3) {
                                    Text("• Lignes à importer : ${bulkText.lines().filter { it.isNotBlank() }.size}", color = Color.White, fontSize = 13.sp)
                                }
                            }
                        }

                        // Import Progress State (Error or Success messages only; main download progress bar is at the top)
                        if (importState is ImportState.Error) {
                            Text(
                                text = (importState as ImportState.Error).message,
                                color = Color(0xFFEF4444),
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(vertical = 8.dp)
                            )
                        } else if (importState is ImportState.Success) {
                            Text(
                                text = (importState as ImportState.Success).message,
                                color = Color(0xFF10B981),
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(vertical = 8.dp)
                            )
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Button(
                                onClick = { currentStep = 2 },
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF374151)),
                                modifier = Modifier.tvFocusable(onClick = { currentStep = 2 })
                            ) {
                                Text("⬅ Modifier")
                            }

                            Button(
                                onClick = { handleSaveOrImport() },
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF10B981)),
                                modifier = Modifier.tvFocusable(onClick = { handleSaveOrImport() })
                            ) {
                                Icon(Icons.Default.Check, contentDescription = "Valider", tint = Color.White, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = if (editingPlaylist != null) "Sauvegarder ⚡" else "Se Connecter & Importer ⚡",
                                    color = Color.White,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }
            }
        }

        if (showTesterPlusieursMacScreen) {
            TesterPlusieursMacDialog(
                initialPortalUrl = url,
                onDismiss = { showTesterPlusieursMacScreen = false },
                viewModel = viewModel
            )
        }

        if (showSmartImportDialog) {
            AlertDialog(
                onDismissRequest = { showSmartImportDialog = false },
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Icon(Icons.Default.Star, contentDescription = "Saisie Intelligente", tint = Color(0xFF6366F1))
                        Text("🧠 Saisie Intelligente de Données", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                    }
                },
                text = {
                    Column(modifier = Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text(
                            "Collez un texte brut ou un paragraphe contenant les informations de votre abonnement (URL du portail Stalker, adresses MAC, identifiants Xtream, liens M3U, etc.). L'application extraira automatiquement les données nécessaires !",
                            color = Color.LightGray,
                            fontSize = 12.sp
                        )
                        OutlinedTextField(
                            value = smartParagraphText,
                            onValueChange = { smartParagraphText = it },
                            placeholder = { Text("Collez votre paragraphe de texte ici...", color = Color.Gray) },
                            minLines = 5,
                            maxLines = 8,
                            modifier = Modifier.fillMaxWidth(),
                            colors = OutlinedTextFieldDefaults.colors(focusedTextColor = Color.White, unfocusedTextColor = Color.White)
                        )
                        Button(
                            onClick = {
                                val clip = getClipboardText().trim()
                                if (clip.isNotEmpty()) {
                                    smartParagraphText = clip
                                    Toast.makeText(context, "Texte du presse-papiers collé !", Toast.LENGTH_SHORT).show()
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E293B)),
                            border = BorderStroke(1.dp, Color(0xFF374151)),
                            modifier = Modifier.fillMaxWidth().tvFocusable(onClick = {
                                val clip = getClipboardText().trim()
                                if (clip.isNotEmpty()) {
                                    smartParagraphText = clip
                                    Toast.makeText(context, "Texte du presse-papiers collé !", Toast.LENGTH_SHORT).show()
                                }
                            })
                        ) {
                            Text("📋 Coller depuis le presse-papiers", fontSize = 12.sp, color = Color.White)
                        }
                    }
                },
                confirmButton = {
                    Button(
                        onClick = {
                            if (smartParagraphText.isNotBlank()) {
                                handleSmartParagraphImport(smartParagraphText)
                                showSmartImportDialog = false
                            } else {
                                Toast.makeText(context, "Veuillez coller un texte à analyser.", Toast.LENGTH_SHORT).show()
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF6366F1)),
                        modifier = Modifier.tvFocusable(onClick = {
                            if (smartParagraphText.isNotBlank()) {
                                handleSmartParagraphImport(smartParagraphText)
                                showSmartImportDialog = false
                            } else {
                                Toast.makeText(context, "Veuillez coller un texte à analyser.", Toast.LENGTH_SHORT).show()
                            }
                        })
                    ) {
                        Text("⚡ Extraire & Remplir", fontWeight = FontWeight.Bold, color = Color.White)
                    }
                },
                dismissButton = {
                    Button(
                        onClick = { showSmartImportDialog = false },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF374151)),
                        modifier = Modifier.tvFocusable(onClick = { showSmartImportDialog = false })
                    ) {
                        Text("Annuler", color = Color.White)
                    }
                },
                containerColor = Color(0xFF0F172A)
            )
        }

        Spacer(modifier = Modifier.height(16.dp))

        if (playlists.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        imageVector = Icons.Default.Add,
                        contentDescription = "Empty Playlists",
                        tint = Color(0xFF9CA3AF),
                        modifier = Modifier.size(64.dp)
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    Text(
                        text = "Aucune playlist ajoutée.\nImportez des liens M3U, des serveurs Xtream ou des portails Stalker pour commencer.",
                        color = Color(0xFF9CA3AF),
                        fontSize = 16.sp,
                        textAlign = TextAlign.Center
                    )
                }
            }
        } else {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.List,
                        contentDescription = "Trier",
                        tint = Color(0xFF10B981),
                        modifier = Modifier.size(18.dp)
                    )
                    Text(
                        text = "Trier les portails :",
                        color = Color(0xFF9CA3AF),
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Medium
                    )
                }

                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    PlaylistSortOption.values().forEach { option ->
                        val isSelected = sortOption == option
                        Button(
                            onClick = { sortOption = option },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (isSelected) Color(0xFF10B981) else Color(0xFF1E2430)
                            ),
                            border = BorderStroke(1.dp, if (isSelected) Color(0xFF10B981) else Color(0xFF374151)),
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                            modifier = Modifier.tvFocusable(onClick = { sortOption = option })
                        ) {
                            Text(
                                text = option.title,
                                fontSize = 12.sp,
                                color = if (isSelected) Color.White else Color(0xFF9CA3AF),
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                            )
                        }
                    }
                }
            }

            LazyVerticalGrid(
                columns = GridCells.Adaptive(minSize = 250.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp),
                horizontalArrangement = Arrangement.spacedBy(16.dp),
                modifier = Modifier.weight(1f)
            ) {
                items(sortedPlaylists, key = { it.id }) { playlist ->
                    val isCurrent = selectedPlaylist?.id == playlist.id
                    val summary = playlistSummaries[playlist.id] ?: Triple(0, 0, 0)
                    Card(
                        colors = CardDefaults.cardColors(
                            containerColor = if (isCurrent) Color(0xFF171C26) else Color(0xFF1E2430)
                        ),
                        border = if (isCurrent) BorderStroke(2.dp, Color(0xFF10B981)) else null,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(145.dp)
                            .tvFocusable(
                                focusedColor = Color(0xFF10B981),
                                onClick = { viewModel.selectPlaylist(playlist) }
                            )
                            .combinedClickable(
                                onClick = { viewModel.selectPlaylist(playlist) },
                                onLongClick = { startEditing(playlist) }
                            )
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(12.dp),
                            verticalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = playlist.name,
                                    color = Color.White,
                                    fontSize = 16.sp,
                                    fontWeight = FontWeight.Bold,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                    modifier = Modifier.weight(1f)
                                )
                                Box(
                                    modifier = Modifier
                                        .background(
                                            color = when (playlist.type) {
                                                "M3U" -> Color(0xFF3B82F6)
                                                "Xtream" -> Color(0xFF8B5CF6)
                                                else -> Color(0xFFEC4899)
                                            },
                                            shape = RoundedCornerShape(4.dp)
                                        )
                                        .padding(horizontal = 6.dp, vertical = 2.dp)
                                ) {
                                    Text(
                                        text = playlist.type,
                                        color = Color.White,
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                            
                            // Playlist channel counts summary row
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "📺 Live: ${summary.first}  •  🎬 Movies: ${summary.second}  •  🍿 Series: ${summary.third}",
                                    color = Color(0xFF10B981),
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }

                            // Dynamic last updated timestamp display
                            val context = androidx.compose.ui.platform.LocalContext.current
                            val lastUpdated = remember(playlist.id) {
                                context.getSharedPreferences("playlist_cache", android.content.Context.MODE_PRIVATE)
                                    .getLong("last_updated_${playlist.id}", 0L)
                            }
                            if (lastUpdated > 0L) {
                                val sdf = remember { java.text.SimpleDateFormat("dd/MM/yyyy HH:mm", java.util.Locale.getDefault()) }
                                val dateStr = remember(lastUpdated) { sdf.format(java.util.Date(lastUpdated)) }
                                Text(
                                    text = "Mis à jour : $dateStr",
                                    color = Color(0xFF9CA3AF),
                                    fontSize = 10.sp,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                            
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = if (playlist.url.isNotEmpty()) playlist.url else "Base locale",
                                    color = Color(0xFF9CA3AF),
                                    fontSize = 11.sp,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                    modifier = Modifier.weight(0.7f)
                                )
                                
                                Row(
                                    horizontalArrangement = Arrangement.spacedBy(4.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Switch(
                                        checked = playlist.isActive,
                                        onCheckedChange = { viewModel.togglePlaylistActive(playlist) },
                                        colors = SwitchDefaults.colors(
                                            checkedThumbColor = Color(0xFF10B981),
                                            checkedTrackColor = Color(0xFF10B981).copy(alpha = 0.4f),
                                            uncheckedThumbColor = Color.Gray,
                                            uncheckedTrackColor = Color.DarkGray
                                        )
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))

                                    // Refresh Playlist Button
                                    IconButton(
                                        onClick = { viewModel.updateAndReimportPlaylist(playlist) },
                                        modifier = Modifier.size(24.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Refresh,
                                            contentDescription = "Actualiser la playlist",
                                            tint = Color(0xFF10B981)
                                        )
                                    }

                                    // Edit Playlist Button
                                    IconButton(
                                        onClick = { startEditing(playlist) },
                                        modifier = Modifier.size(24.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Edit,
                                            contentDescription = "Edit Playlist",
                                            tint = Color(0xFF06B6D4)
                                        )
                                    }

                                    // Delete Playlist Button
                                    IconButton(
                                        onClick = { selectedPlaylistToDelete = playlist },
                                        modifier = Modifier.size(24.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Delete,
                                            contentDescription = "Delete Playlist",
                                            tint = Color(0xFFEF4444)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // Delete Playlist Confirmation Dialog
    if (selectedPlaylistToDelete != null) {
        AlertDialog(
            onDismissRequest = { selectedPlaylistToDelete = null },
            title = { Text("Supprimer la Playlist ?", color = Color.White) },
            text = { Text("Voulez-vous vraiment supprimer '${selectedPlaylistToDelete!!.name}' ainsi que toutes ses chaînes ?", color = Color(0xFF9CA3AF)) },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.deletePlaylist(selectedPlaylistToDelete!!.id)
                        selectedPlaylistToDelete = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFEF4444))
                ) {
                    Text("Supprimer", color = Color.White)
                }
            },
            dismissButton = {
                TextButton(onClick = { selectedPlaylistToDelete = null }) {
                    Text("Annuler", color = Color.White)
                }
            },
            containerColor = Color(0xFF1E2430)
        )
    }
}

enum class PlaylistSortOption(val title: String) {
    ALPHABETICAL("Alphabétique"),
    LAST_SYNC("Dernière synchronisation"),
    CHANNEL_COUNT("Nombre de chaînes"),
    STATUS("État")
}

fun parseBulkImportText(text: String): List<BulkImportItem> {
    val items = mutableListOf<BulkImportItem>()
    val lines = text.split("\n")
    for (line in lines) {
        val trimmed = line.trim()
        if (trimmed.isEmpty()) continue
        
        val parts = trimmed.split(Regex("[,|;]")).map { it.trim() }
        
        var name = ""
        var url = ""
        var mac = ""
        var type = "m3u"
        
        for (part in parts) {
            if (part.startsWith("http://") || part.startsWith("https://")) {
                url = part
            } else if (part.matches(Regex("(?i)([0-9a-f]{2}[:-]){5}[0-9a-f]{2}"))) {
                mac = part
                type = "stalker"
            } else if (part.isNotEmpty()) {
                if (name.isEmpty()) {
                    name = part
                } else if (mac.isEmpty() && part.split(":").size > 2) {
                    mac = part
                    type = "stalker"
                }
            }
        }
        
        if (url.isNotEmpty()) {
            if (name.isEmpty()) {
                name = url.substringAfter("://").substringBefore("/").replace("www.", "")
                if (name.isEmpty()) name = "Playlist Bulk"
            }
            items.add(BulkImportItem(name = name, url = url, macAddress = mac, type = type))
        }
    }
    return items
}

@Composable
fun AddPlaylistDialog(
    importState: ImportState,
    onDismiss: () -> Unit,
    onImportM3u: (String, String) -> Unit,
    onImportXtream: (String, String, String, String) -> Unit,
    onImportStalker: (String, String, String, Boolean) -> Unit,
    onImportBulk: (List<BulkImportItem>) -> Unit
) {
    var selectedTab by remember { mutableStateOf(0) }
    var name by remember { mutableStateOf("") }
    var url by remember { mutableStateOf("") }
    var username by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var macAddress by remember { mutableStateOf("00:1A:79:") }
    var hideDns by remember { mutableStateOf(false) }
    var bulkText by remember { mutableStateOf("") }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier
                .fillMaxWidth(0.9f)
                .wrapContentHeight()
                .padding(16.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF171C26)),
            shape = RoundedCornerShape(16.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(24.dp)
            ) {
                Text(
                    text = "Import IPTV Playlist",
                    color = Color.White,
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold
                )
                
                Spacer(modifier = Modifier.height(16.dp))

                TabRow(
                    selectedTabIndex = selectedTab,
                    containerColor = Color.Transparent,
                    contentColor = Color(0xFF10B981)
                ) {
                    Tab(selected = selectedTab == 0, onClick = { selectedTab = 0 }) {
                        Text("M3U Link", modifier = Modifier.padding(8.dp), color = Color.White, fontSize = 12.sp)
                    }
                    Tab(selected = selectedTab == 1, onClick = { selectedTab = 1 }) {
                        Text("Xtream Codes", modifier = Modifier.padding(8.dp), color = Color.White, fontSize = 12.sp)
                    }
                    Tab(selected = selectedTab == 2, onClick = { selectedTab = 2 }) {
                        Text("Stalker Portal", modifier = Modifier.padding(8.dp), color = Color.White, fontSize = 12.sp)
                    }
                    Tab(selected = selectedTab == 3, onClick = { selectedTab = 3 }) {
                        Text("En Masse (Bulk)", modifier = Modifier.padding(8.dp), color = Color.White, fontSize = 12.sp)
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                if (importState is ImportState.Loading) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(180.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            CircularProgressIndicator(color = Color(0xFF10B981))
                            Spacer(modifier = Modifier.height(16.dp))
                            Text(text = importState.message, color = Color.White, fontSize = 14.sp)
                        }
                    }
                } else if (importState is ImportState.Success) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(180.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(Icons.Default.CheckCircle, contentDescription = "Success", tint = Color(0xFF10B981), modifier = Modifier.size(48.dp))
                            Spacer(modifier = Modifier.height(16.dp))
                            Text(text = importState.message, color = Color.White, fontSize = 14.sp)
                            Spacer(modifier = Modifier.height(16.dp))
                            Button(onClick = onDismiss, colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF10B981))) {
                                Text("Close")
                            }
                        }
                    }
                } else {
                    if (selectedTab != 3) {
                        OutlinedTextField(
                            value = name,
                            onValueChange = { name = it },
                            label = { Text("Playlist Name", color = Color.White) },
                            modifier = Modifier.fillMaxWidth(),
                            colors = OutlinedTextFieldDefaults.colors(focusedTextColor = Color.White, unfocusedTextColor = Color.White)
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                    }

                    when (selectedTab) {
                        0 -> {
                            OutlinedTextField(
                                value = url,
                                onValueChange = { url = it },
                                label = { Text("M3U Playlist URL", color = Color.White) },
                                modifier = Modifier.fillMaxWidth(),
                                colors = OutlinedTextFieldDefaults.colors(focusedTextColor = Color.White, unfocusedTextColor = Color.White)
                            )
                        }
                        1 -> {
                            OutlinedTextField(
                                value = url,
                                onValueChange = { url = it },
                                label = { Text("Server URL (e.g. http://host:port)", color = Color.White) },
                                modifier = Modifier.fillMaxWidth(),
                                colors = OutlinedTextFieldDefaults.colors(focusedTextColor = Color.White, unfocusedTextColor = Color.White)
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                OutlinedTextField(
                                    value = username,
                                    onValueChange = { username = it },
                                    label = { Text("Username", color = Color.White) },
                                    modifier = Modifier.weight(1f),
                                    colors = OutlinedTextFieldDefaults.colors(focusedTextColor = Color.White, unfocusedTextColor = Color.White)
                                )
                                OutlinedTextField(
                                    value = password,
                                    onValueChange = { password = it },
                                    label = { Text("Password", color = Color.White) },
                                    modifier = Modifier.weight(1f),
                                    colors = OutlinedTextFieldDefaults.colors(focusedTextColor = Color.White, unfocusedTextColor = Color.White)
                                )
                            }
                        }
                        2 -> {
                            OutlinedTextField(
                                value = url,
                                onValueChange = { url = it },
                                label = { Text("Stalker Portal URL", color = Color.White) },
                                modifier = Modifier.fillMaxWidth(),
                                colors = OutlinedTextFieldDefaults.colors(focusedTextColor = Color.White, unfocusedTextColor = Color.White)
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            OutlinedTextField(
                                value = macAddress,
                                onValueChange = { macAddress = it },
                                label = { Text("MAC Address (00:1A:79:XX:XX:XX)", color = Color.White) },
                                modifier = Modifier.fillMaxWidth(),
                                colors = OutlinedTextFieldDefaults.colors(focusedTextColor = Color.White, unfocusedTextColor = Color.White)
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Checkbox(
                                    checked = hideDns,
                                    onCheckedChange = { hideDns = it },
                                    colors = CheckboxDefaults.colors(checkedColor = Color(0xFF10B981))
                                )
                                Text("Hide DNS / Portal URL in navigation", color = Color.White, fontSize = 14.sp)
                            }
                        }
                        3 -> {
                            Text(
                                text = "Entrez vos playlists ligne par ligne au format :\nNom, URL, [MAC Adresse optionnelle]",
                                color = Color(0xFF9CA3AF),
                                fontSize = 11.sp,
                                modifier = Modifier.padding(bottom = 8.dp)
                            )
                            OutlinedTextField(
                                value = bulkText,
                                onValueChange = { bulkText = it },
                                placeholder = { Text("Exemple :\nRakuten fr, https://www.apsattv.com/rakutentv-fr.m3u\nMon Portail, http://stalker.tv:80/c/, 00:1A:79:12:34:56", color = Color(0xFF4B5563)) },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(160.dp),
                                colors = OutlinedTextFieldDefaults.colors(focusedTextColor = Color.White, unfocusedTextColor = Color.White),
                                maxLines = 10
                            )
                        }
                    }

                    if (importState is ImportState.Error) {
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(text = "Error: ${importState.message}", color = Color(0xFFEF4444), fontSize = 13.sp)
                    }

                    Spacer(modifier = Modifier.height(24.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.End
                    ) {
                        TextButton(onClick = onDismiss) {
                            Text("Cancel", color = Color.White)
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Button(
                            onClick = {
                                if (selectedTab == 3) {
                                    val parsed = parseBulkImportText(bulkText)
                                    if (parsed.isNotEmpty()) {
                                        onImportBulk(parsed)
                                    }
                                } else {
                                    if (name.trim().isEmpty()) return@Button
                                    when (selectedTab) {
                                        0 -> onImportM3u(name, url)
                                        1 -> onImportXtream(name, url, username, password)
                                        2 -> onImportStalker(name, url, macAddress, hideDns)
                                    }
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF10B981))
                        ) {
                            Text("Import")
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun LiveChannelsSection(viewModel: IptvViewModel, filterType: String = "Live") {
    val selectedPlaylist by viewModel.selectedPlaylist.collectAsState()
    val allChannels by viewModel.channels.collectAsState()
    val selectedCategory by viewModel.selectedCategory.collectAsState()
    val selectedSubcategory by viewModel.selectedSubcategory.collectAsState()
    val searchQuery by viewModel.searchQuery.collectAsState()
    val selectedChannel by viewModel.selectedChannel.collectAsState()

    var lastGridClickTime by remember { mutableStateOf(0L) }
    var lastGridClickChannelUrl by remember { mutableStateOf("") }
    var showCatchupDialogForChannel by remember { mutableStateOf<ChannelItem?>(null) }

    // Dynamically filter categories based on filterType and parsed groupName
    val categories = remember(allChannels) {
        val filtered = allChannels.filter { it.type == filterType }
        val cats = filtered.map { viewModel.getCategoryAndSubcategory(it.groupName).first }.distinct().sorted()
        listOf("Tous") + cats
    }

    // Dynamically filter subcategories based on selected category
    val subcategories = remember(allChannels, selectedCategory) {
        val filtered = allChannels.filter { it.type == filterType }
        val inCat = if (selectedCategory == "Tous") {
            filtered
        } else {
            filtered.filter { viewModel.getCategoryAndSubcategory(it.groupName).first == selectedCategory }
        }
        val subcats = inCat.map { viewModel.getCategoryAndSubcategory(it.groupName).second }.distinct().sorted()
        if (subcats.isEmpty() || (subcats.size == 1 && subcats[0] == "Général")) {
            emptyList()
        } else {
            listOf("Tous") + subcats
        }
    }

    // Dynamically filter channels based on type, category, subcategory, and search query
    val channels = remember(allChannels, selectedCategory, selectedSubcategory, searchQuery) {
        allChannels.filter { it.type == filterType }
            .filter { selectedCategory == "Tous" || viewModel.getCategoryAndSubcategory(it.groupName).first == selectedCategory }
            .filter { selectedSubcategory == "Tous" || viewModel.getCategoryAndSubcategory(it.groupName).second == selectedSubcategory }
            .filter { searchQuery.isEmpty() || it.name.lowercase().contains(searchQuery.lowercase().trim()) }
    }

    LaunchedEffect(channels, selectedCategory) {
        if (channels.isNotEmpty()) {
            val current = selectedChannel
            if (current == null || !channels.any { it.streamUrl == current.streamUrl }) {
                viewModel.selectChannelPreview(channels.first())
            }
        }
    }

    // Format helper
    fun getFormatLabel(streamUrl: String): String {
        val url = streamUrl.lowercase()
        return when {
            url.contains(".m3u8") || url.contains("hls") -> "HLS"
            url.contains(".mpd") || url.contains("dash") -> "DASH"
            url.contains(".mp4") -> "MP4"
            url.contains(".mkv") -> "MKV"
            url.contains(".ts") || url.contains("mpeg") || url.contains("/live/") -> "MPEG-TS"
            else -> "MPEG"
        }
    }

    if (selectedPlaylist == null) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("Veuillez sélectionner ou ajouter une playlist d'abord.", color = Color(0xFF9CA3AF), fontSize = 16.sp)
        }
        return
    }

    Row(modifier = Modifier.fillMaxSize()) {
        // Left column: Channels browse & Category selector
        Column(
            modifier = Modifier
                .weight(if (selectedChannel != null) 0.72f else 1f)
                .fillMaxHeight()
        ) {
            // Search & Refresh Input Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { viewModel.setSearchQuery(it) },
                    label = { Text("Rechercher des chaînes", color = Color.White) },
                    modifier = Modifier.weight(1f),
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = "Rechercher", tint = Color.White) },
                    colors = OutlinedTextFieldDefaults.colors(focusedTextColor = Color.White, unfocusedTextColor = Color.White)
                )
                
                Button(
                    onClick = { 
                        selectedPlaylist?.let { playlist ->
                            viewModel.updateAndReimportPlaylist(playlist)
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E2430)),
                    border = BorderStroke(1.dp, Color(0xFF374151)),
                    modifier = Modifier
                        .height(56.dp)
                        .tvFocusable(
                            onClick = {
                                selectedPlaylist?.let { playlist ->
                                    viewModel.updateAndReimportPlaylist(playlist)
                                }
                            }
                        )
                ) {
                    Icon(
                        imageVector = Icons.Default.Refresh,
                        contentDescription = "Actualiser",
                        tint = Color(0xFF10B981)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Actualiser", color = Color.White, fontSize = 12.sp)
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Categories horizontal scroller
            Text(
                text = "Catégories",
                color = Color(0xFF10B981),
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 0.5.sp,
                modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
            )
            val catListState = rememberLazyListState()
            val selectedCatIdx = remember(categories, selectedCategory) {
                categories.indexOf(selectedCategory).coerceAtLeast(0)
            }
            LaunchedEffect(selectedCatIdx, selectedCategory) {
                if (categories.isNotEmpty() && selectedCatIdx in categories.indices) {
                    catListState.animateScrollToItem(selectedCatIdx)
                }
            }
            LazyRow(
                state = catListState,
                modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(categories, key = { it }) { cat ->
                    val isSelected = selectedCategory == cat
                    Card(
                        colors = CardDefaults.cardColors(
                            containerColor = if (isSelected) CeylanColor else Color(0xFF1E2430)
                        ),
                        border = BorderStroke(
                            width = if (isSelected) 2.dp else 1.dp,
                            color = if (isSelected) CeylanColor else Color(0xFF374151)
                        ),
                        shape = RoundedCornerShape(20.dp),
                        modifier = Modifier
                            .tvFocusable(
                                focusedColor = CeylanColor,
                                borderRadius = 20.dp,
                                onClick = { viewModel.selectCategory(cat) }
                            )
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp)
                        ) {
                            if (isSelected) {
                                Box(
                                    modifier = Modifier
                                        .size(6.dp)
                                        .background(Color.White, shape = CircleShape)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                            }
                            Text(
                                text = cat,
                                color = Color.White,
                                fontSize = 12.sp,
                                fontWeight = if (isSelected) FontWeight.ExtraBold else FontWeight.SemiBold
                            )
                        }
                    }
                }
            }

            // Subcategories horizontal scroller
            if (subcategories.isNotEmpty()) {
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "Sous-Catégories",
                    color = Color(0xFF9CA3AF),
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 0.5.sp,
                    modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                )
                val subcatListState = rememberLazyListState()
                val selectedSubcatIdx = remember(subcategories, selectedSubcategory) {
                    subcategories.indexOf(selectedSubcategory).coerceAtLeast(0)
                }
                LaunchedEffect(selectedSubcatIdx, selectedSubcategory) {
                    if (subcategories.isNotEmpty() && selectedSubcatIdx in subcategories.indices) {
                        subcatListState.animateScrollToItem(selectedSubcatIdx)
                    }
                }
                LazyRow(
                    state = subcatListState,
                    modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    items(subcategories, key = { it }) { subcat ->
                        val isSelected = selectedSubcategory == subcat
                        Card(
                            colors = CardDefaults.cardColors(
                                containerColor = if (isSelected) Color(0xFF10B981) else Color(0xFF1E2430)
                            ),
                            border = BorderStroke(
                                width = if (isSelected) 2.dp else 1.dp,
                                color = if (isSelected) Color(0xFF10B981) else Color(0xFF374151)
                            ),
                            shape = RoundedCornerShape(16.dp),
                            modifier = Modifier
                                .tvFocusable(
                                    focusedColor = Color(0xFF10B981),
                                    borderRadius = 16.dp,
                                    onClick = { viewModel.selectSubcategory(subcat) }
                                )
                        ) {
                            Text(
                                text = subcat,
                                color = Color.White,
                                fontSize = 11.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            if (channels.isEmpty()) {
                Box(modifier = Modifier.fillMaxWidth().weight(1f), contentAlignment = Alignment.Center) {
                    Text("Aucune chaîne trouvée dans cette catégorie.", color = Color(0xFF9CA3AF), fontSize = 16.sp)
                }
            } else {
                LazyVerticalGrid(
                    columns = GridCells.Adaptive(minSize = 130.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    itemsIndexed(channels, key = { index, channel -> if (channel.id != 0L) "ch_${channel.id}" else "ch_url_${channel.streamUrl}_$index" }) { index, channel ->
                        val isThisSelected = selectedChannel?.streamUrl == channel.streamUrl
                        Card(
                            colors = CardDefaults.cardColors(
                                containerColor = if (isThisSelected) Color(0xFF1E2430) else Color(0xFF171C26)
                            ),
                            border = if (isThisSelected) BorderStroke(2.dp, CeylanColor) else null,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(115.dp)
                                .tvFocusable(
                                    focusedColor = CeylanColor,
                                    onFocus = { viewModel.selectChannelPreview(channel) },
                                    onClick = {
                                        val now = System.currentTimeMillis()
                                        val isDoubleTap = (now - lastGridClickTime < 500) && (lastGridClickChannelUrl == channel.streamUrl)
                                        lastGridClickTime = now
                                        lastGridClickChannelUrl = channel.streamUrl
                                        
                                        if (isDoubleTap) {
                                            viewModel.selectChannel(channel)
                                            viewModel.setFullScreen(true)
                                        } else {
                                            if (isThisSelected) {
                                                viewModel.setFullScreen(true)
                                            } else {
                                                viewModel.selectChannel(channel)
                                            }
                                        }
                                    }
                                )
                        ) {
                            Box(modifier = Modifier.fillMaxSize()) {
                                // Channel index number badge on top-left of the card
                                Box(
                                    modifier = Modifier
                                        .align(Alignment.TopStart)
                                        .background(
                                            color = Color(0xFF10B981).copy(alpha = 0.85f),
                                            shape = RoundedCornerShape(bottomEnd = 6.dp)
                                        )
                                        .padding(horizontal = 6.dp, vertical = 2.dp)
                                ) {
                                    Text(
                                        text = "${index + 1}",
                                        color = Color.White,
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }

                                // Stream format badge (MPEG / HLS) on top-right of the card
                                Box(
                                    modifier = Modifier
                                        .align(Alignment.TopEnd)
                                        .background(
                                            color = Color(0xFF2563EB).copy(alpha = 0.9f),
                                            shape = RoundedCornerShape(bottomStart = 6.dp)
                                        )
                                        .padding(horizontal = 5.dp, vertical = 2.dp)
                                ) {
                                    Text(
                                        text = getFormatLabel(channel.streamUrl),
                                        color = Color.White,
                                        fontSize = 9.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }

                                Column(
                                    modifier = Modifier
                                        .fillMaxSize()
                                        .padding(horizontal = 8.dp, vertical = 12.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                    verticalArrangement = Arrangement.Center
                                ) {
                                    if (channel.logoUrl.isNotEmpty()) {
                                        AsyncImage(
                                            model = channel.logoUrl,
                                            contentDescription = channel.name,
                                            modifier = Modifier
                                                .size(40.dp)
                                                .clip(RoundedCornerShape(6.dp))
                                        )
                                    } else {
                                        Icon(
                                            imageVector = Icons.Default.PlayArrow,
                                            contentDescription = "No Logo",
                                            tint = Color(0xFF10B981),
                                            modifier = Modifier.size(30.dp)
                                        )
                                    }
                                    Spacer(modifier = Modifier.height(6.dp))
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.Center,
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        if (channel.hasCatchup) {
                                            IconButton(
                                                onClick = { showCatchupDialogForChannel = channel },
                                                modifier = Modifier.size(20.dp)
                                            ) {
                                                Icon(
                                                    imageVector = Icons.Default.History,
                                                    contentDescription = "Catch-up Replay disponible",
                                                    tint = CeylanColor,
                                                    modifier = Modifier.size(12.dp)
                                                )
                                            }
                                            Spacer(modifier = Modifier.width(4.dp))
                                        }
                                        Text(
                                            text = channel.name,
                                            color = Color.White,
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold,
                                            textAlign = TextAlign.Center,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis,
                                            modifier = Modifier.weight(1f)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        if (selectedChannel != null) {
            Spacer(modifier = Modifier.width(16.dp))
            Column(
                modifier = Modifier
                    .weight(0.28f)
                    .fillMaxHeight()
            ) {
                PreviewChannelPanel(channel = selectedChannel!!, viewModel = viewModel)
            }
        }
        
        if (showCatchupDialogForChannel != null) {
            CatchupProgramsDialog(
                channel = showCatchupDialogForChannel!!,
                viewModel = viewModel,
                onDismiss = { showCatchupDialogForChannel = null }
            )
        }
    }
}

@Composable
fun PreviewChannelPanel(
    channel: ChannelItem,
    viewModel: IptvViewModel
) {
    val isRecording by viewModel.isRecording.collectAsState()
    val recordingChannel by viewModel.recordingChannel.collectAsState()
    val recordingDuration by viewModel.recordingDurationSeconds.collectAsState()

    val selectedChannel by viewModel.selectedChannel.collectAsState()
    val isPlaying by viewModel.isPlaying.collectAsState()
    val playbackUrl by viewModel.playbackUrl.collectAsState()
    val playbackHeaders by viewModel.playbackHeaders.collectAsState()
    val playbackLoading by viewModel.playbackLoading.collectAsState()

    val isCurrentRecordingThis = isRecording && recordingChannel?.streamUrl == channel.streamUrl

    val previewInfiniteTransition = androidx.compose.animation.core.rememberInfiniteTransition(label = "preview_rec_blink")
    val previewRecBlinkAlpha by previewInfiniteTransition.animateFloat(
        initialValue = 1f,
        targetValue = 0.2f,
        animationSpec = androidx.compose.animation.core.infiniteRepeatable(
            animation = androidx.compose.animation.core.tween(500, easing = androidx.compose.animation.core.LinearEasing),
            repeatMode = androidx.compose.animation.core.RepeatMode.Reverse
        ),
        label = "alpha"
    )

    Card(
        colors = CardDefaults.cardColors(containerColor = Color(0xFF171C26)),
        border = BorderStroke(1.dp, Color(0xFF1E2430)),
        modifier = Modifier
            .fillMaxWidth()
            .padding(8.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(
                text = "ÉCRAN RÉDUIT (APERÇU DIRECT)",
                color = Color(0xFF10B981),
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.sp
            )
            Spacer(modifier = Modifier.height(8.dp))

            // 16:9 Video container
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .aspectRatio(1.77f)
                    .clip(RoundedCornerShape(8.dp))
                    .background(Color.Black),
                contentAlignment = Alignment.Center
            ) {
                if (playbackLoading) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(24.dp),
                        color = Color(0xFF10B981),
                        strokeWidth = 2.dp
                    )
                } else if (!playbackUrl.isNullOrEmpty()) {
                    SimpleVideoPlayer(streamUrl = playbackUrl!!, headers = playbackHeaders, viewModel = viewModel)
                } else {
                    Text(
                        text = "Aucun flux disponible",
                        color = Color.Gray,
                        fontSize = 12.sp
                    )
                }
                
                if (isCurrentRecordingThis) {
                    Row(
                        modifier = Modifier
                            .align(Alignment.TopStart)
                            .background(Color.Black.copy(alpha = 0.7f), shape = RoundedCornerShape(bottomEnd = 8.dp))
                            .padding(horizontal = 8.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(8.dp)
                                .background(Color.Red, shape = CircleShape)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "REC ${recordingDuration}s",
                            color = Color.White,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            Row(verticalAlignment = Alignment.CenterVertically) {
                if (channel.logoUrl.isNotEmpty()) {
                    AsyncImage(
                        model = channel.logoUrl,
                        contentDescription = channel.name,
                        modifier = Modifier
                            .size(44.dp)
                            .clip(RoundedCornerShape(8.dp))
                    )
                } else {
                    Icon(
                        imageVector = Icons.Default.PlayArrow,
                        contentDescription = "No Logo",
                        tint = Color(0xFF10B981),
                        modifier = Modifier.size(32.dp)
                    )
                }
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Text(
                        text = channel.name,
                        color = Color.White,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = "Catégorie: ${channel.groupName}",
                        color = Color.Gray,
                        fontSize = 12.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Playback controls in reduced screen
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Button(
                    onClick = { 
                        if (selectedChannel?.streamUrl == channel.streamUrl && isPlaying) {
                            viewModel.setFullScreen(true)
                        } else {
                            viewModel.selectChannel(channel, keepFullScreen = true)
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF10B981)),
                    modifier = Modifier
                        .fillMaxWidth()
                        .tvFocusable(onClick = { 
                            if (selectedChannel?.streamUrl == channel.streamUrl && isPlaying) {
                                viewModel.setFullScreen(true)
                            } else {
                                viewModel.selectChannel(channel, keepFullScreen = true)
                            }
                        })
                ) {
                    Icon(Icons.Default.PlayArrow, contentDescription = "Plein Écran", tint = Color.White)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Regarder en Plein Écran", color = Color.White, fontWeight = FontWeight.Bold)
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Button(
                        onClick = {
                            if (isCurrentRecordingThis) {
                                viewModel.stopRecording()
                            } else {
                                viewModel.startRecording(channel)
                            }
                        },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (isCurrentRecordingThis) Color(0xFFEF4444) else Color(0xFF374151)
                        ),
                        modifier = Modifier
                            .weight(1f)
                            .tvFocusable(onClick = {
                                if (isCurrentRecordingThis) {
                                    viewModel.stopRecording()
                                } else {
                                    viewModel.startRecording(channel)
                                }
                            })
                    ) {
                        if (isCurrentRecordingThis) {
                            Box(modifier = Modifier.size(12.dp).alpha(previewRecBlinkAlpha).background(Color.White, shape = RoundedCornerShape(2.dp)))
                        } else {
                            Box(modifier = Modifier.size(12.dp).background(Color.Red, shape = CircleShape))
                        }
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = if (isCurrentRecordingThis) "Stop" else "Enregistrer",
                            color = Color.White,
                            fontSize = 11.sp
                        )
                    }

                    Button(
                        onClick = { viewModel.toggleFavorite(channel) },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E2430)),
                        modifier = Modifier
                            .weight(1.2f)
                            .tvFocusable(onClick = { viewModel.toggleFavorite(channel) })
                    ) {
                        Text("Favoris", color = Color.White, fontSize = 11.sp)
                    }
                }

                var showSubtitleSettingsDialog by remember { mutableStateOf(false) }

                Button(
                    onClick = { showSubtitleSettingsDialog = true },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E293B)),
                    border = BorderStroke(1.dp, Color(0xFF00E5FF).copy(alpha = 0.5f)),
                    modifier = Modifier
                        .fillMaxWidth()
                        .tvFocusable(onClick = { showSubtitleSettingsDialog = true })
                ) {
                    Icon(
                        imageVector = Icons.Default.Subtitles,
                        contentDescription = "Sous-titres TV",
                        tint = Color(0xFF00E5FF),
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "💬 Sous-titres & Vocal TV",
                        color = Color.White,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                if (showSubtitleSettingsDialog) {
                    LiveTvSubtitleSettingsDialog(
                        viewModel = viewModel,
                        onDismiss = { showSubtitleSettingsDialog = false }
                    )
                }
            }
        }
    }
}

@Composable
fun MultiviewPlayerWrapper(
    channel: ChannelItem,
    viewModel: IptvViewModel,
    isMuted: Boolean
) {
    val context = LocalContext.current
    var resolvedUrl by remember(channel.id, channel.streamUrl) { mutableStateOf<String?>(null) }
    var headers by remember(channel.id, channel.streamUrl) { mutableStateOf<Map<String, String>>(emptyMap()) }
    var isLoading by remember(channel.id, channel.streamUrl) { mutableStateOf(true) }
    var errorMsg by remember(channel.id, channel.streamUrl) { mutableStateOf<String?>(null) }

    val exoPlayer = remember(channel.id, channel.streamUrl) {
        val loadControl = androidx.media3.exoplayer.DefaultLoadControl.Builder()
            .setBufferDurationsMs(8000, 30000, 500, 1000)
            .setPrioritizeTimeOverSizeThresholds(true)
            .build()

        val renderersFactory = androidx.media3.exoplayer.DefaultRenderersFactory(context).apply {
            setExtensionRendererMode(androidx.media3.exoplayer.DefaultRenderersFactory.EXTENSION_RENDERER_MODE_PREFER)
            setEnableDecoderFallback(true)
        }

        val audioAttributes = androidx.media3.common.AudioAttributes.Builder()
            .setUsage(androidx.media3.common.C.USAGE_MEDIA)
            .setContentType(androidx.media3.common.C.AUDIO_CONTENT_TYPE_MOVIE)
            .build()
            
        androidx.media3.exoplayer.ExoPlayer.Builder(context)
            .setRenderersFactory(renderersFactory)
            .setAudioAttributes(audioAttributes, false) // Disable automatic audio focus handling so both streams play simultaneously
            .setLoadControl(loadControl)
            .setWakeMode(androidx.media3.common.C.WAKE_MODE_NETWORK)
            .build().apply {
                repeatMode = androidx.media3.common.Player.REPEAT_MODE_OFF
                volume = if (isMuted) 0f else 1f
            }
    }

    DisposableEffect(exoPlayer) {
        onDispose {
            try {
                exoPlayer.stop()
                exoPlayer.clearMediaItems()
                exoPlayer.release()
            } catch (e: Exception) {
                // Ignore cleanup errors
            }
        }
    }

    LaunchedEffect(isMuted) {
        try {
            exoPlayer.volume = if (isMuted) 0f else 1f
        } catch (e: Exception) {
            // Ignore volume setting errors
        }
    }

    LaunchedEffect(channel.id, channel.streamUrl) {
        isLoading = true
        errorMsg = null
        try {
            val playbackInfo = viewModel.resolveChannelPlayback(channel)
            resolvedUrl = playbackInfo.url
            headers = playbackInfo.headers
            if (resolvedUrl != null) {
                val httpDataSourceFactory = androidx.media3.datasource.DefaultHttpDataSource.Factory().apply {
                    setUserAgent("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36")
                    setConnectTimeoutMs(15000)
                    setReadTimeoutMs(15000)
                    setAllowCrossProtocolRedirects(true)
                    headers.forEach { (k, v) ->
                        setDefaultRequestProperties(mapOf(k to v))
                    }
                }
                val dataSourceFactory = androidx.media3.datasource.DefaultDataSource.Factory(context, httpDataSourceFactory)
                val mediaSourceFactory = androidx.media3.exoplayer.source.DefaultMediaSourceFactory(dataSourceFactory)
                val mediaItem = androidx.media3.common.MediaItem.fromUri(resolvedUrl!!)
                val mediaSource = mediaSourceFactory.createMediaSource(mediaItem)
                
                exoPlayer.setMediaSource(mediaSource)
                exoPlayer.prepare()
                exoPlayer.volume = if (isMuted) 0f else 1f
                exoPlayer.playWhenReady = true
            } else {
                errorMsg = "Lien du flux indisponible"
            }
        } catch (e: Exception) {
            errorMsg = e.message ?: "Erreur de lecture"
        } finally {
            isLoading = false
        }
    }

    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        if (isLoading) {
            androidx.compose.material3.CircularProgressIndicator(
                color = Color(0xFF10B981),
                modifier = Modifier.size(28.dp)
            )
        } else if (errorMsg != null) {
            Text(text = errorMsg ?: "Erreur", color = Color.Red, fontSize = 11.sp, textAlign = TextAlign.Center)
        } else if (resolvedUrl != null) {
            AndroidView(
                factory = { ctx ->
                    androidx.media3.ui.PlayerView(ctx).apply {
                        player = exoPlayer
                        useController = false
                        resizeMode = androidx.media3.ui.AspectRatioFrameLayout.RESIZE_MODE_FIT
                    }
                },
                update = { playerView ->
                    playerView.player = exoPlayer
                },
                modifier = Modifier.fillMaxSize()
            )
        }
    }
}

@Composable
fun MultiviewSection(viewModel: IptvViewModel) {
    val allChannels by viewModel.channels.collectAsState()
    val currentlyPlayingChannel by viewModel.selectedChannel.collectAsState()
    val selectedPlaylist by viewModel.selectedPlaylist.collectAsState()
    val playlists by viewModel.playlists.collectAsState()

    // Pause single background player while in multi-screen mode
    DisposableEffect(Unit) {
        viewModel.pausePlayback()
        onDispose { }
    }

    // Determine current playlist info
    val currentPlaylist = selectedPlaylist ?: playlists.firstOrNull()
    val currentPlaylistName = currentPlaylist?.name ?: "Playlist Actuelle"

    // Filter playlist channels for live / current playlist
    val playlistChannels = remember(allChannels, selectedPlaylist) {
        val filtered = if (selectedPlaylist != null) {
            allChannels.filter { it.playlistId == selectedPlaylist?.id }
        } else {
            allChannels
        }
        val liveOnly = filtered.filter { it.type == "Live" || it.type == "TV" }
        if (liveOnly.isNotEmpty()) liveOnly else filtered
    }

    var selectedCategory by remember { mutableStateOf("Tous") }
    val categories = remember(playlistChannels) {
        val groups = playlistChannels.map { it.groupName.ifBlank { "Général" } }.distinct().sorted()
        if (groups.contains("Tous")) groups else listOf("Tous") + groups
    }

    var searchQuery by remember { mutableStateOf("") }
    val displayedChannels = remember(playlistChannels, searchQuery, selectedCategory) {
        var list = playlistChannels
        if (selectedCategory != "Tous") {
            list = list.filter { (it.groupName.ifBlank { "Général" }) == selectedCategory }
        }
        if (searchQuery.isNotBlank()) {
            list = list.filter { it.name.contains(searchQuery, ignoreCase = true) || it.groupName.contains(searchQuery, ignoreCase = true) }
        }
        list
    }

    var selectedGridCell by remember { mutableStateOf<Int?>(0) }
    val assignedStreams = remember { mutableStateMapOf<Int, ChannelItem>() }
    var activeAudioCellId by remember { mutableStateOf<Int?>(0) }

    // Pre-fill Screen 1 with currently watched channel if assignedStreams is empty
    LaunchedEffect(currentlyPlayingChannel) {
        if (assignedStreams.isEmpty() && currentlyPlayingChannel != null) {
            assignedStreams[0] = currentlyPlayingChannel!!
            activeAudioCellId = 0
            selectedGridCell = 1 // Auto-target Screen 2 for next selection
        }
    }

    Column(modifier = Modifier.fillMaxSize()) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text("Mode Multi-Écrans (Double Écran 📺📺)", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                Text(
                    text = "Sélectionnez un écran puis une chaîne. L'écran actif joue avec le son, l'autre continue en mode muet.",
                    color = Color.Gray,
                    fontSize = 12.sp
                )
            }
            
            Surface(
                color = Color(0xFF10B981).copy(alpha = 0.15f),
                shape = RoundedCornerShape(20.dp),
                border = BorderStroke(1.dp, Color(0xFF10B981).copy(alpha = 0.4f))
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("🔊 Audio : ", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                    Text(
                        text = if (activeAudioCellId == 0) "Écran 1 (Gauche)" else if (activeAudioCellId == 1) "Écran 2 (Droite)" else "Aucun",
                        color = Color(0xFF10B981),
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Auto-Fill & Quick Matrix Action Bar
        Row(
            modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Button(
                onClick = {
                    val first2 = displayedChannels.take(2)
                    first2.forEachIndexed { index, ch ->
                        assignedStreams[index] = ch
                    }
                    if (first2.isNotEmpty()) {
                        activeAudioCellId = 0
                        selectedGridCell = 0
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF00E5FF)),
                modifier = Modifier.tvFocusable(
                    focusedColor = Color(0xFF00E5FF),
                    borderRadius = 8.dp,
                    onClick = {
                        val first2 = displayedChannels.take(2)
                        first2.forEachIndexed { index, ch ->
                            assignedStreams[index] = ch
                        }
                        if (first2.isNotEmpty()) {
                            activeAudioCellId = 0
                            selectedGridCell = 0
                        }
                    }
                )
            ) {
                Icon(Icons.Default.PlayArrow, contentDescription = "Remplir 2", tint = Color.White, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("Remplir les 2 Écrans Auto ⚡", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp)
            }

            Button(
                onClick = {
                    assignedStreams.clear()
                    activeAudioCellId = null
                    selectedGridCell = 0
                },
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFEF4444)),
                modifier = Modifier.tvFocusable(
                    focusedColor = Color(0xFFEF4444),
                    borderRadius = 8.dp,
                    onClick = {
                        assignedStreams.clear()
                        activeAudioCellId = null
                        selectedGridCell = 0
                    }
                )
            ) {
                Icon(Icons.Default.Clear, contentDescription = "Tout Vider", tint = Color.White, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("Tout Vider ❌", color = Color.White, fontSize = 12.sp)
            }
        }

        Row(modifier = Modifier.fillMaxSize()) {
            // Left: Matrix Grid (2 Screens side-by-side)
            Row(
                modifier = Modifier
                    .weight(0.65f)
                    .fillMaxHeight(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                for (cellId in 0..1) {
                    val assigned = assignedStreams[cellId]
                    val isFocusedCell = selectedGridCell == cellId
                    val isAudioActive = activeAudioCellId == cellId

                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxHeight()
                            .background(Color(0xFF171C26), shape = RoundedCornerShape(12.dp))
                            .border(
                                width = if (isFocusedCell) 3.dp else if (isAudioActive) 2.dp else 1.dp,
                                color = if (isFocusedCell) Color(0xFF10B981) else if (isAudioActive) Color(0xFF00E5FF) else Color(0xFF1E2430),
                                shape = RoundedCornerShape(12.dp)
                            )
                            .clickable {
                                selectedGridCell = cellId
                                activeAudioCellId = cellId
                            }
                            .tvFocusable(
                                focusedColor = Color(0xFF10B981),
                                borderRadius = 12.dp,
                                onFocus = {
                                    selectedGridCell = cellId
                                },
                                onClick = { 
                                    selectedGridCell = cellId
                                    activeAudioCellId = cellId
                                }
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        if (assigned != null) {
                            MultiviewPlayerWrapper(channel = assigned, viewModel = viewModel, isMuted = !isAudioActive)
                            
                            // Top Left: Screen Title & Channel Name
                            Box(
                                modifier = Modifier
                                    .align(Alignment.TopStart)
                                    .background(Color.Black.copy(alpha = 0.75f), shape = RoundedCornerShape(bottomEnd = 8.dp))
                                    .padding(horizontal = 8.dp, vertical = 4.dp)
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        text = if (cellId == 0) "ÉCRAN 1: " else "ÉCRAN 2: ",
                                        color = if (isFocusedCell) Color(0xFF10B981) else Color(0xFF00E5FF),
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Text(assigned.name, color = Color.White, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                }
                            }

                            // Top Right: Remove button
                            IconButton(
                                onClick = { 
                                    assignedStreams.remove(cellId)
                                    if (activeAudioCellId == cellId) {
                                        activeAudioCellId = assignedStreams.keys.firstOrNull()
                                    }
                                },
                                modifier = Modifier.align(Alignment.TopEnd)
                            ) {
                                Icon(Icons.Default.Close, contentDescription = "Enlever", tint = Color.Red)
                            }

                            // Bottom Right: Audio Status Badge & Clickable Audio Switch
                            Box(
                                modifier = Modifier
                                    .align(Alignment.BottomEnd)
                                    .padding(8.dp)
                                    .background(
                                        if (isAudioActive) Color(0xFF10B981).copy(alpha = 0.9f) else Color.Black.copy(alpha = 0.75f),
                                        shape = RoundedCornerShape(6.dp)
                                    )
                                    .clickable {
                                        activeAudioCellId = cellId
                                        selectedGridCell = cellId
                                    }
                                    .padding(horizontal = 8.dp, vertical = 4.dp)
                                    .tvFocusable(
                                        focusedColor = Color(0xFF10B981),
                                        borderRadius = 6.dp,
                                        onClick = {
                                            activeAudioCellId = cellId
                                            selectedGridCell = cellId
                                        }
                                    )
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        text = if (isAudioActive) "🔊" else "🔇",
                                        fontSize = 12.sp
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        text = if (isAudioActive) "SON ACTIF" else "MUET (CLIQUER)",
                                        color = Color.White,
                                        fontSize = 9.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        } else {
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.Center,
                                modifier = Modifier.padding(16.dp)
                            ) {
                                Icon(
                                    Icons.Default.Add,
                                    contentDescription = "Ajouter un flux",
                                    tint = if (isFocusedCell) Color(0xFF10B981) else Color.Gray,
                                    modifier = Modifier.size(36.dp)
                                )
                                Spacer(modifier = Modifier.height(8.dp))
                                Text(
                                    text = if (cellId == 0) "Premier Écran (Écran 1)" else "Second Écran (Écran 2)",
                                    color = Color.White,
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = if (isFocusedCell) "Sélectionnez une chaîne dans la playlist à droite" else "Cliquez pour cibler cet écran",
                                    color = if (isFocusedCell) Color(0xFF10B981) else Color.Gray,
                                    fontSize = 11.sp,
                                    textAlign = TextAlign.Center
                                )
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.width(14.dp))

            // Right: Channel Selector List from Current Playlist (Barre Latérale)
            Column(
                modifier = Modifier
                    .weight(0.35f)
                    .fillMaxHeight()
                    .background(Color(0xFF171C26), shape = RoundedCornerShape(12.dp))
                    .padding(12.dp)
            ) {
                // Header with Playlist name and item count
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = currentPlaylistName,
                            color = Color.White,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            text = "${displayedChannels.size} chaînes disponibles",
                            color = Color(0xFF10B981),
                            fontSize = 11.sp
                        )
                    }

                    if (currentPlaylist != null) {
                        Surface(
                            color = Color(0xFF10B981).copy(alpha = 0.2f),
                            shape = RoundedCornerShape(4.dp)
                        ) {
                            Text(
                                text = currentPlaylist.type,
                                color = Color(0xFF10B981),
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Target Screen Indicator button
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color(0xFF131722), RoundedCornerShape(8.dp))
                        .padding(horizontal = 10.dp, vertical = 6.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Écran Cible :",
                        color = Color.Gray,
                        fontSize = 11.sp
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Surface(
                            color = if (selectedGridCell == 0) Color(0xFF10B981) else Color(0xFF1E2430),
                            shape = RoundedCornerShape(6.dp),
                            modifier = Modifier.clickable { selectedGridCell = 0 }
                        ) {
                            Text(
                                text = "Écran 1",
                                color = Color.White,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }
                        Surface(
                            color = if (selectedGridCell == 1) Color(0xFF00E5FF) else Color(0xFF1E2430),
                            shape = RoundedCornerShape(6.dp),
                            modifier = Modifier.clickable { selectedGridCell = 1 }
                        ) {
                            Text(
                                text = "Écran 2",
                                color = Color.White,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Category chips
                if (categories.size > 1) {
                    LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 8.dp)
                    ) {
                        items(categories, key = { it }) { cat ->
                            val isSelected = selectedCategory == cat
                            Surface(
                                color = if (isSelected) Color(0xFF10B981) else Color(0xFF1E2430),
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier
                                    .clickable { selectedCategory = cat }
                                    .tvFocusable(
                                        focusedColor = Color(0xFF10B981),
                                        borderRadius = 12.dp,
                                        onClick = { selectedCategory = cat }
                                    )
                            ) {
                                Text(
                                    text = cat,
                                    color = if (isSelected) Color.White else Color.LightGray,
                                    fontSize = 10.sp,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                )
                            }
                        }
                    }
                }

                // Search Box
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    placeholder = { Text("Rechercher une chaîne...", color = Color.Gray, fontSize = 11.sp) },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = Color(0xFF10B981),
                        unfocusedBorderColor = Color(0xFF1E2430),
                        focusedContainerColor = Color(0xFF131722),
                        unfocusedContainerColor = Color(0xFF131722),
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 8.dp)
                )

                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(6.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    items(displayedChannels, key = { if (it.id != 0L) "ms_ch_${it.id}" else "ms_ch_url_${it.streamUrl}" }) { channel ->
                        val isOnScreen1 = assignedStreams[0]?.streamUrl == channel.streamUrl
                        val isOnScreen2 = assignedStreams[1]?.streamUrl == channel.streamUrl

                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(
                                    if (isOnScreen1 || isOnScreen2) Color(0xFF10B981).copy(alpha = 0.2f) else Color(0xFF1E2430),
                                    shape = RoundedCornerShape(8.dp)
                                )
                                .border(
                                    width = 1.dp,
                                    color = if (isOnScreen1 || isOnScreen2) Color(0xFF10B981) else Color.Transparent,
                                    shape = RoundedCornerShape(8.dp)
                                )
                                .clickable {
                                    val cell = selectedGridCell ?: 0
                                    assignedStreams[cell] = channel
                                    // Make the selected screen have sound, other screen plays muted
                                    activeAudioCellId = cell
                                    
                                    // Auto-advance target screen from Screen 1 to Screen 2 if Screen 2 is not filled
                                    if (cell == 0 && assignedStreams[1] == null) {
                                        selectedGridCell = 1
                                    }
                                }
                                .tvFocusable(
                                    focusedColor = Color(0xFF10B981),
                                    borderRadius = 8.dp,
                                    onClick = {
                                        val cell = selectedGridCell ?: 0
                                        assignedStreams[cell] = channel
                                        // Make the selected screen have sound, other screen plays muted
                                        activeAudioCellId = cell
                                        
                                        // Auto-advance target screen from Screen 1 to Screen 2 if Screen 2 is not filled
                                        if (cell == 0 && assignedStreams[1] == null) {
                                            selectedGridCell = 1
                                        }
                                    }
                                )
                                .padding(10.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = channel.name,
                                        color = Color.White,
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Medium,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    if (channel.groupName.isNotEmpty()) {
                                        Text(
                                            text = channel.groupName,
                                            color = Color.Gray,
                                            fontSize = 10.sp,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                    }
                                }

                                if (isOnScreen1) {
                                    Text("Écran 1 📺", color = Color(0xFF10B981), fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                } else if (isOnScreen2) {
                                    Text("Écran 2 📺", color = Color(0xFF00E5FF), fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                } else {
                                    Text(
                                        text = if (selectedGridCell == 0) "→ Écran 1" else "→ Écran 2",
                                        color = Color.Gray,
                                        fontSize = 10.sp
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun HistorySection(viewModel: IptvViewModel) {
    val history by viewModel.history.collectAsState()

    Column(modifier = Modifier.fillMaxSize()) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("Recently Played History", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold)
            
            if (history.isNotEmpty()) {
                Button(
                    onClick = { viewModel.clearHistory() },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFEF4444)),
                    modifier = Modifier.tvFocusable(onClick = { viewModel.clearHistory() })
                ) {
                    Text("Clear History", color = Color.White)
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        if (history.isEmpty()) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("Aucun historique de lecture disponible.", color = Color.Gray, fontSize = 16.sp)
            }
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                itemsIndexed(history, key = { index, item -> "hist_${item.id}_${item.streamUrl}_$index" }) { index, item ->
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(Color(0xFF171C26), shape = RoundedCornerShape(8.dp))
                            .tvFocusable(
                                focusedColor = Color(0xFF10B981),
                                onClick = { viewModel.playChannelDirectly(item.channelName, item.streamUrl) }
                            )
                            .padding(16.dp)
                    ) {
                        Row(
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.weight(1f)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .background(Color(0x2200E5FF), shape = RoundedCornerShape(4.dp))
                                        .padding(horizontal = 8.dp, vertical = 2.dp)
                                ) {
                                    Text(
                                        text = String.format("%02d", index + 1),
                                        color = Color(0xFF00E5FF),
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                                Spacer(modifier = Modifier.width(12.dp))
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(item.channelName.uppercase(), color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(item.streamUrl, color = Color.Gray, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                }
                            }
                            Icon(Icons.Default.PlayArrow, contentDescription = "Play", tint = Color(0xFF10B981))
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun SettingsSection(viewModel: IptvViewModel) {
    val webServerIp by viewModel.webServerIp.collectAsState()
    val savedPlaylistsForSharing by viewModel.playlists.collectAsState()
    var showPlaylistDetailsDialog by remember { mutableStateOf(false) }
    val useExternalPlayer by viewModel.useExternalPlayer.collectAsState()
    val allowInternalStorageRecording by viewModel.allowInternalStorageRecording.collectAsState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp)
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        val context = androidx.compose.ui.platform.LocalContext.current
        Text("Réglages & Options de l'Application", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold)
        Spacer(modifier = Modifier.height(16.dp))

        // Card 1: Lecteur Externe
        Card(
            colors = CardDefaults.cardColors(containerColor = Color(0xFF171C26)),
            border = BorderStroke(1.dp, Color(0xFF00E5FF).copy(alpha = 0.3f)),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .tvFocusable(
                        focusedColor = Color(0xFF00E5FF),
                        borderRadius = 12.dp,
                        onClick = { viewModel.setUseExternalPlayer(!useExternalPlayer) }
                    )
                    .padding(16.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f).padding(end = 16.dp)) {
                    Text(
                        text = "Lecteur Externe",
                        color = Color.White,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Utiliser VLC ou MX Player pour la lecture",
                        color = Color.Gray,
                        fontSize = 14.sp
                    )
                }
                Switch(
                    checked = useExternalPlayer,
                    onCheckedChange = { viewModel.setUseExternalPlayer(it) },
                    colors = SwitchDefaults.colors(
                        checkedThumbColor = Color(0xFF00E5FF),
                        checkedTrackColor = Color(0xFF00E5FF).copy(alpha = 0.4f),
                        uncheckedThumbColor = Color.Gray,
                        uncheckedTrackColor = Color.Gray.copy(alpha = 0.4f)
                    )
                )
            }
        }

        // Card 2: Sous-titres & Traduction Temps Réel (ML Kit)
        val subtitlesEnabled by viewModel.subtitlesEnabled.collectAsState()
        val subtitleTranslationEnabled by viewModel.subtitleTranslationEnabled.collectAsState()
        val subtitleTargetLanguage by viewModel.subtitleTargetLanguage.collectAsState()
        val subtitleSizeState by viewModel.subtitleSizeState.collectAsState()
        val subtitleStyleMode by viewModel.subtitleStyleMode.collectAsState()
        val isDownloadingModel by com.example.data.TranslationManager.isDownloadingModel.collectAsState()
        val downloadMessage by com.example.data.TranslationManager.downloadProgressMessage.collectAsState()

        Card(
            colors = CardDefaults.cardColors(containerColor = Color(0xFF171C26)),
            border = BorderStroke(1.dp, Color(0xFF00E5FF).copy(alpha = 0.4f)),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f).padding(end = 16.dp)) {
                        Text(
                            text = "Sous-titres & Traduction en Direct (ML Kit)",
                            color = Color.White,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Extraction CEA-608 / WebVTT et traduction instantanée sur appareil via Google ML Kit",
                            color = Color.Gray,
                            fontSize = 14.sp
                        )
                    }
                    Switch(
                        checked = subtitlesEnabled,
                        onCheckedChange = { viewModel.setSubtitlesEnabled(it) },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = Color(0xFF00E5FF),
                            checkedTrackColor = Color(0xFF00E5FF).copy(alpha = 0.4f),
                            uncheckedThumbColor = Color.Gray,
                            uncheckedTrackColor = Color.Gray.copy(alpha = 0.4f)
                        )
                    )
                }

                if (subtitlesEnabled) {
                    Spacer(modifier = Modifier.height(16.dp))
                    HorizontalDivider(color = Color.White.copy(alpha = 0.1f))
                    Spacer(modifier = Modifier.height(16.dp))

                    // Live Translation Toggle
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .tvFocusable(
                                focusedColor = Color(0xFF10B981),
                                borderRadius = 8.dp,
                                onClick = {
                                    val current = viewModel.subtitleTranslationEnabled.value
                                    viewModel.setSubtitleTranslationEnabled(!current)
                                }
                            )
                            .padding(vertical = 6.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f).padding(end = 12.dp)) {
                            Text(
                                text = "Traduction Temps Réel (ML Kit On-Device)",
                                color = Color(0xFF10B981),
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "Traduit automatiquement les sous-titres et incrustations à la volée",
                                color = Color.Gray,
                                fontSize = 13.sp
                            )
                        }
                        Switch(
                            checked = subtitleTranslationEnabled,
                            onCheckedChange = { viewModel.setSubtitleTranslationEnabled(it) },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = Color(0xFF10B981),
                                checkedTrackColor = Color(0xFF10B981).copy(alpha = 0.4f)
                            )
                        )
                    }

                    // OCR System Recognition Toggle
                    val subtitleOcrEnabled by viewModel.subtitleOcrEnabled.collectAsState()
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .tvFocusable(
                                focusedColor = Color(0xFF00E5FF),
                                borderRadius = 8.dp,
                                onClick = {
                                    val current = viewModel.subtitleOcrEnabled.value
                                    viewModel.setSubtitleOcrEnabled(!current)
                                }
                            )
                            .padding(vertical = 6.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f).padding(end = 12.dp)) {
                            Text(
                                text = "Traduction & Reconnaissance Système OCR",
                                color = Color(0xFF00E5FF),
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "Extrait et traite les sous-titres DVB, bitmaps et incrustés via OCR haute performance",
                                color = Color.Gray,
                                fontSize = 13.sp
                            )
                        }
                        Switch(
                            checked = subtitleOcrEnabled,
                            onCheckedChange = { viewModel.setSubtitleOcrEnabled(it) },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = Color(0xFF00E5FF),
                                checkedTrackColor = Color(0xFF00E5FF).copy(alpha = 0.4f)
                            )
                        )
                    }

                    // Source language auto-detection indicator
                    val detectedSubtitleLanguage by viewModel.detectedSubtitleLanguage.collectAsState()
                    Spacer(modifier = Modifier.height(4.dp))
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(Color(0xFF1E293B), RoundedCornerShape(8.dp))
                            .padding(horizontal = 12.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Language, contentDescription = null, tint = Color(0xFF00E5FF), modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Langue source détectée :", color = Color.Gray, fontSize = 13.sp)
                        }
                        Text(
                            text = detectedSubtitleLanguage ?: "Détection auto (Audio / Sous-titres)",
                            color = Color(0xFF00E5FF),
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    if (isDownloadingModel) {
                        Spacer(modifier = Modifier.height(8.dp))
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(Color(0xFF00E5FF).copy(alpha = 0.15f), RoundedCornerShape(8.dp))
                                .padding(10.dp)
                        ) {
                            CircularProgressIndicator(modifier = Modifier.size(16.dp), color = Color(0xFF00E5FF), strokeWidth = 2.dp)
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(
                                text = downloadMessage ?: "Téléchargement du modèle de langue ML Kit...",
                                color = Color.White,
                                fontSize = 13.sp
                            )
                        }
                    }

                    // Target Language Selection
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = "LANGUE CIBLE DE TRADUCTION",
                        color = Color(0xFF00E5FF),
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        items(com.example.data.TranslationManager.availableLanguages, key = { it.code }) { langOption ->
                            val isSelected = subtitleTargetLanguage == langOption.code
                            Box(
                                modifier = Modifier
                                    .background(
                                        color = if (isSelected) Color(0xFF00E5FF) else Color(0xFF262C38),
                                        shape = RoundedCornerShape(8.dp)
                                    )
                                    .border(
                                        width = 1.dp,
                                        color = if (isSelected) Color(0xFF00E5FF) else Color.White.copy(alpha = 0.1f),
                                        shape = RoundedCornerShape(8.dp)
                                    )
                                    .tvFocusable(
                                        focusedColor = Color(0xFF00E5FF),
                                        borderRadius = 8.dp,
                                        onClick = { viewModel.setSubtitleTargetLanguage(langOption.code) }
                                    )
                                    .padding(horizontal = 14.dp, vertical = 8.dp)
                            ) {
                                Text(
                                    text = langOption.displayName,
                                    color = Color.White,
                                    fontSize = 13.sp,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
                                )
                            }
                        }
                    }

                    // Subtitle Size Selection
                    Spacer(modifier = Modifier.height(16.dp))
                    Text(
                        text = "TAILLE DU TEXTE DES SOUS-TITRES",
                        color = Color(0xFF00E5FF),
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        val sizes = listOf("Petit", "Moyen", "Grand", "Très Grand")
                        sizes.forEach { sz ->
                            val isSelected = subtitleSizeState == sz
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .background(
                                        color = if (isSelected) Color(0xFF10B981) else Color(0xFF262C38),
                                        shape = RoundedCornerShape(8.dp)
                                    )
                                    .border(
                                        width = 1.dp,
                                        color = if (isSelected) Color(0xFF10B981) else Color.White.copy(alpha = 0.1f),
                                        shape = RoundedCornerShape(8.dp)
                                    )
                                    .tvFocusable(
                                        focusedColor = Color(0xFF10B981),
                                        borderRadius = 8.dp,
                                        onClick = { viewModel.setSubtitleSizeState(sz) }
                                    )
                                    .padding(vertical = 10.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = sz,
                                    color = Color.White,
                                    fontSize = 13.sp,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
                                )
                            }
                        }
                    }

                    // Subtitle Style Selection
                    Spacer(modifier = Modifier.height(16.dp))
                    Text(
                        text = "STYLE D'AFFICHAGE & COULEURS",
                        color = Color(0xFF00E5FF),
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    val styles = listOf(
                        "Intelligent / Adaptatif",
                        "Texte jaune #FFE000, contour noir",
                        "Texte blanc #FFFFFF, contour noir",
                        "Texte vert #00FF66, contour noir",
                        "Texte cyan #00E5FF, contour noir",
                        "Bande noire, texte jaune #FFE000",
                        "Bande noire, texte blanc #FFFFFF",
                        "Bande blanche, texte noir #000000"
                    )
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        styles.forEach { style ->
                            val isSelected = subtitleStyleMode == style
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(
                                        color = if (isSelected) Color(0x3300E5FF) else Color(0xFF262C38),
                                        shape = RoundedCornerShape(8.dp)
                                    )
                                    .border(
                                        width = 1.dp,
                                        color = if (isSelected) Color(0xFF00E5FF) else Color.Transparent,
                                        shape = RoundedCornerShape(8.dp)
                                    )
                                    .tvFocusable(
                                        focusedColor = Color(0xFF00E5FF),
                                        borderRadius = 8.dp,
                                        onClick = { viewModel.setSubtitleStyleMode(style) }
                                    )
                                    .padding(horizontal = 12.dp, vertical = 8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                RadioButton(
                                    selected = isSelected,
                                    onClick = { viewModel.setSubtitleStyleMode(style) },
                                    colors = RadioButtonDefaults.colors(
                                        selectedColor = Color(0xFF00E5FF),
                                        unselectedColor = Color.Gray
                                    )
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = style,
                                    color = if (isSelected) Color(0xFF00E5FF) else Color.White,
                                    fontSize = 13.sp,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                                )
                            }
                        }
                    }
                }
            }
        }

        // Card 2.5: Sous-titres Vocaux Hors-ligne IA (Vosk)
        val voiceSubtitlesEnabled by viewModel.voiceSubtitlesEnabled.collectAsState()
        val voiceSubtitleLanguage by viewModel.voiceSubtitleLanguage.collectAsState()
        val isVoiceDownloading by viewModel.isVoiceModelDownloading.collectAsState()
        val voiceDownloadProgress by viewModel.voiceModelDownloadProgress.collectAsState()
        val voiceDownloadMessage by viewModel.voiceModelDownloadMessage.collectAsState()
        val voiceSubtitleSyncOffsetMs by viewModel.voiceSubtitleSyncOffsetMs.collectAsState()
        val voiceSubtitleAutoCalibration by viewModel.voiceSubtitleAutoCalibration.collectAsState()
        val autoCalibratedOffsetMs by viewModel.autoCalibratedOffsetMs.collectAsState()
        val voiceSubtitleClearDelaySeconds by viewModel.voiceSubtitleClearDelaySeconds.collectAsState()
        val voiceSubtitleAutoDuration by viewModel.voiceSubtitleAutoDuration.collectAsState()
        val voiceSubtitleStreamingMode by viewModel.voiceSubtitleStreamingMode.collectAsState()

        Card(
            colors = CardDefaults.cardColors(containerColor = Color(0xFF171C26)),
            border = BorderStroke(1.dp, Color(0xFF00E5FF).copy(alpha = 0.4f)),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f).padding(end = 16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Mic, contentDescription = null, tint = Color(0xFF00E5FF), modifier = Modifier.size(20.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Sous-titres Vocaux Synchronisés (Sherpa-ONNX)",
                                color = Color.White,
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Transcription vocale IA continue et synchronisée 100% hors-ligne pour flux TV et vidéos",
                            color = Color.Gray,
                            fontSize = 14.sp
                        )
                    }
                    Switch(
                        checked = voiceSubtitlesEnabled,
                        onCheckedChange = { viewModel.setVoiceSubtitlesEnabled(it) },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = Color(0xFF00E5FF),
                            checkedTrackColor = Color(0xFF00E5FF).copy(alpha = 0.4f)
                        )
                    )
                }

                if (voiceSubtitlesEnabled) {
                    Spacer(modifier = Modifier.height(16.dp))
                    HorizontalDivider(color = Color.White.copy(alpha = 0.1f))
                    Spacer(modifier = Modifier.height(12.dp))

                    Text(
                        text = "MODÈLE VOCAL SHERPA-ONNX",
                        color = Color(0xFF00E5FF),
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp
                    )
                    Spacer(modifier = Modifier.height(8.dp))

                    if (isVoiceDownloading) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(Color(0xFF00E5FF).copy(alpha = 0.12f), RoundedCornerShape(8.dp))
                                .padding(12.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = voiceDownloadMessage ?: "Téléchargement du modèle vocal Sherpa-ONNX...",
                                    color = Color(0xFF00E5FF),
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.SemiBold
                                )
                                Text(
                                    text = "${(voiceDownloadProgress * 100).toInt()}%",
                                    color = Color(0xFF00E5FF),
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            Spacer(modifier = Modifier.height(6.dp))
                            LinearProgressIndicator(
                                progress = { voiceDownloadProgress },
                                modifier = Modifier.fillMaxWidth().height(4.dp).clip(RoundedCornerShape(2.dp)),
                                color = Color(0xFF00E5FF),
                                trackColor = Color(0xFF1E293B)
                            )
                        }
                        Spacer(modifier = Modifier.height(10.dp))
                    }

                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        com.example.data.SherpaSubtitleManager.AVAILABLE_MODELS.forEach { model ->
                            val isSelected = voiceSubtitleLanguage == model.id
                            val isInstalled = com.example.data.SherpaSubtitleManager.isModelInstalled(context, model)
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(
                                        color = if (isSelected) Color(0x3300E5FF) else Color(0xFF262C38),
                                        shape = RoundedCornerShape(8.dp)
                                    )
                                    .border(
                                        width = 1.dp,
                                        color = if (isSelected) Color(0xFF00E5FF) else Color.Transparent,
                                        shape = RoundedCornerShape(8.dp)
                                    )
                                    .tvFocusable(
                                        focusedColor = Color(0xFF00E5FF),
                                        borderRadius = 8.dp,
                                        onClick = {
                                            viewModel.setVoiceSubtitleLanguage(model.id)
                                        }
                                    )
                                    .padding(horizontal = 12.dp, vertical = 8.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    RadioButton(
                                        selected = isSelected,
                                        onClick = {
                                            viewModel.setVoiceSubtitleLanguage(model.id)
                                        },
                                        colors = RadioButtonDefaults.colors(
                                            selectedColor = Color(0xFF00E5FF),
                                            unselectedColor = Color.Gray
                                        )
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = "${model.displayName} (${model.sizeDescription})",
                                        color = if (isSelected) Color(0xFF00E5FF) else Color.White,
                                        fontSize = 13.sp,
                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                                    )
                                }
                                Box(
                                    modifier = Modifier
                                        .background(
                                            when {
                                                isInstalled -> Color(0xFF10B981).copy(alpha = 0.2f)
                                                isVoiceDownloading && isSelected -> Color(0xFF00E5FF).copy(alpha = 0.2f)
                                                else -> Color(0xFFF59E0B).copy(alpha = 0.2f)
                                            },
                                            RoundedCornerShape(4.dp)
                                        )
                                        .padding(horizontal = 8.dp, vertical = 3.dp)
                                ) {
                                    Text(
                                        text = when {
                                            isInstalled -> "INSTALLÉ"
                                            isVoiceDownloading && isSelected -> "TÉLÉCHARGEMENT ${(voiceDownloadProgress * 100).toInt()}%"
                                            else -> "À TÉLÉCHARGER"
                                        },
                                        color = when {
                                            isInstalled -> Color(0xFF10B981)
                                            isVoiceDownloading && isSelected -> Color(0xFF00E5FF)
                                            else -> Color(0xFFF59E0B)
                                        },
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))
                    Text(
                        text = "SYNCHRONISATION ET FLEXIBILITÉ VOCALE",
                        color = Color(0xFF00E5FF),
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp
                    )
                    Spacer(modifier = Modifier.height(8.dp))

                    // Calibrage de synchronisation audio/sous-titres
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Calibrage Audio / Texte :",
                            color = Color.White,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Medium
                        )
                        Text(
                            text = if (voiceSubtitleAutoCalibration) "Auto intelligent (+${autoCalibratedOffsetMs} ms)" else if (voiceSubtitleSyncOffsetMs == 0) "0 ms (En phase direct)" else "${if (voiceSubtitleSyncOffsetMs > 0) "+" else ""}${voiceSubtitleSyncOffsetMs} ms",
                            color = if (voiceSubtitleAutoCalibration) Color(0xFF10B981) else Color(0xFFF59E0B),
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .background(
                                    if (voiceSubtitleAutoCalibration) Color(0xFF10B981).copy(alpha = 0.25f) else Color(0xFF262C38),
                                    RoundedCornerShape(8.dp)
                                )
                                .border(
                                    1.dp,
                                    if (voiceSubtitleAutoCalibration) Color(0xFF10B981) else Color(0x33FFFFFF),
                                    RoundedCornerShape(8.dp)
                                )
                                .clickable { viewModel.setVoiceSubtitleAutoCalibration(true) }
                                .padding(vertical = 8.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "✨ Automatique intelligent",
                                color = if (voiceSubtitleAutoCalibration) Color(0xFF10B981) else Color.White,
                                fontSize = 11.sp,
                                fontWeight = if (voiceSubtitleAutoCalibration) FontWeight.Bold else FontWeight.Normal
                            )
                        }
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .background(
                                    if (!voiceSubtitleAutoCalibration) Color(0xFF00E5FF).copy(alpha = 0.25f) else Color(0xFF262C38),
                                    RoundedCornerShape(8.dp)
                                )
                                .border(
                                    1.dp,
                                    if (!voiceSubtitleAutoCalibration) Color(0xFF00E5FF) else Color(0x33FFFFFF),
                                    RoundedCornerShape(8.dp)
                                )
                                .clickable { viewModel.setVoiceSubtitleAutoCalibration(false) }
                                .padding(vertical = 8.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "Manuel (+/-)",
                                color = if (!voiceSubtitleAutoCalibration) Color(0xFF00E5FF) else Color.White,
                                fontSize = 11.sp,
                                fontWeight = if (!voiceSubtitleAutoCalibration) FontWeight.Bold else FontWeight.Normal
                            )
                        }
                    }

                    if (!voiceSubtitleAutoCalibration) {
                        Spacer(modifier = Modifier.height(6.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            listOf(
                                "-500ms" to -500,
                                "-100ms" to -100,
                                "0ms (Reset)" to 0,
                                "+100ms" to 100,
                                "+500ms" to 500
                            ).forEach { (label, step) ->
                                Box(
                                    modifier = Modifier
                                        .weight(1f)
                                        .background(
                                            if (step == 0 && voiceSubtitleSyncOffsetMs == 0) Color(0xFF10B981).copy(alpha = 0.25f) else Color(0xFF262C38),
                                            RoundedCornerShape(6.dp)
                                        )
                                        .border(
                                            1.dp,
                                            if (step == 0 && voiceSubtitleSyncOffsetMs == 0) Color(0xFF10B981) else Color(0x33FFFFFF),
                                            RoundedCornerShape(6.dp)
                                        )
                                        .clickable {
                                            if (step == 0) viewModel.setVoiceSubtitleSyncOffsetMs(0)
                                            else viewModel.setVoiceSubtitleSyncOffsetMs(voiceSubtitleSyncOffsetMs + step)
                                        }
                                        .padding(vertical = 8.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = label,
                                        color = Color.White,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = "Mode de décodage vocal en continu :",
                        color = Color.Gray,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .background(
                                    if (voiceSubtitleStreamingMode) Color(0xFF00E5FF).copy(alpha = 0.25f) else Color(0xFF262C38),
                                    RoundedCornerShape(8.dp)
                                )
                                .border(
                                    1.dp,
                                    if (voiceSubtitleStreamingMode) Color(0xFF00E5FF) else Color(0x33FFFFFF),
                                    RoundedCornerShape(8.dp)
                                )
                                .clickable { viewModel.setVoiceSubtitleStreamingMode(true) }
                                .padding(vertical = 10.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "⚡ Mot à mot (Ultra-rapide)",
                                color = if (voiceSubtitleStreamingMode) Color(0xFF00E5FF) else Color.White,
                                fontSize = 11.sp,
                                fontWeight = if (voiceSubtitleStreamingMode) FontWeight.Bold else FontWeight.Normal
                            )
                        }
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .background(
                                    if (!voiceSubtitleStreamingMode) Color(0xFF00E5FF).copy(alpha = 0.25f) else Color(0xFF262C38),
                                    RoundedCornerShape(8.dp)
                                )
                                .border(
                                    1.dp,
                                    if (!voiceSubtitleStreamingMode) Color(0xFF00E5FF) else Color(0x33FFFFFF),
                                    RoundedCornerShape(8.dp)
                                )
                                .clickable { viewModel.setVoiceSubtitleStreamingMode(false) }
                                .padding(vertical = 10.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "📄 Phrases complètes",
                                color = if (!voiceSubtitleStreamingMode) Color(0xFF00E5FF) else Color.White,
                                fontSize = 11.sp,
                                fontWeight = if (!voiceSubtitleStreamingMode) FontWeight.Bold else FontWeight.Normal
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Durée d'affichage du texte :",
                            color = Color.Gray,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Medium
                        )
                        Text(
                            text = if (voiceSubtitleAutoDuration) "🧠 Intelligent (Adapté)" else "${voiceSubtitleClearDelaySeconds}s (Fixe)",
                            color = if (voiceSubtitleAutoDuration) Color(0xFF10B981) else Color(0xFF00E5FF),
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .background(
                                    if (voiceSubtitleAutoDuration) Color(0xFF10B981).copy(alpha = 0.25f) else Color(0xFF262C38),
                                    RoundedCornerShape(8.dp)
                                )
                                .border(
                                    1.dp,
                                    if (voiceSubtitleAutoDuration) Color(0xFF10B981) else Color(0x33FFFFFF),
                                    RoundedCornerShape(8.dp)
                                )
                                .clickable { viewModel.setVoiceSubtitleAutoDuration(true) }
                                .padding(vertical = 8.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "🧠 Auto selon longueur",
                                color = if (voiceSubtitleAutoDuration) Color(0xFF10B981) else Color.White,
                                fontSize = 11.sp,
                                fontWeight = if (voiceSubtitleAutoDuration) FontWeight.Bold else FontWeight.Normal
                            )
                        }
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .background(
                                    if (!voiceSubtitleAutoDuration) Color(0xFF00E5FF).copy(alpha = 0.25f) else Color(0xFF262C38),
                                    RoundedCornerShape(8.dp)
                                )
                                .border(
                                    1.dp,
                                    if (!voiceSubtitleAutoDuration) Color(0xFF00E5FF) else Color(0x33FFFFFF),
                                    RoundedCornerShape(8.dp)
                                )
                                .clickable { viewModel.setVoiceSubtitleAutoDuration(false) }
                                .padding(vertical = 8.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "Durée fixe",
                                color = if (!voiceSubtitleAutoDuration) Color(0xFF00E5FF) else Color.White,
                                fontSize = 11.sp,
                                fontWeight = if (!voiceSubtitleAutoDuration) FontWeight.Bold else FontWeight.Normal
                            )
                        }
                    }

                    if (!voiceSubtitleAutoDuration) {
                        Spacer(modifier = Modifier.height(6.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            listOf(3 to "3s (Vif)", 5 to "5s (Normal)", 7 to "7s (Confort)", 9 to "9s (Long)").forEach { (sec, title) ->
                                val isSel = voiceSubtitleClearDelaySeconds == sec
                                Box(
                                    modifier = Modifier
                                        .weight(1f)
                                        .background(
                                            if (isSel) Color(0xFF10B981).copy(alpha = 0.25f) else Color(0xFF262C38),
                                            RoundedCornerShape(8.dp)
                                        )
                                        .border(
                                            1.dp,
                                            if (isSel) Color(0xFF10B981) else Color(0x33FFFFFF),
                                            RoundedCornerShape(8.dp)
                                        )
                                        .clickable { viewModel.setVoiceSubtitleClearDelaySeconds(sec) }
                                        .padding(vertical = 8.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = title,
                                        color = if (isSel) Color(0xFF10B981) else Color.White,
                                        fontSize = 11.sp,
                                        fontWeight = if (isSel) FontWeight.Bold else FontWeight.Normal
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // Card 2.6: Audio & Configuration du Son
        val activeAudioFormat by viewModel.activeAudioFormat.collectAsState()
        val preferredAudioLanguage by viewModel.preferredAudioLanguage.collectAsState()

        Card(
            colors = CardDefaults.cardColors(containerColor = Color(0xFF171C26)),
            border = BorderStroke(1.dp, Color(0xFF10B981).copy(alpha = 0.4f)),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.VolumeUp, contentDescription = null, tint = Color(0xFF10B981), modifier = Modifier.size(20.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Audio & Configuration du Son",
                        color = Color.White,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "Gestion des pistes audio, format surround et détection sonore pour tous les médias",
                    color = Color.Gray,
                    fontSize = 14.sp
                )

                Spacer(modifier = Modifier.height(14.dp))
                Text(
                    text = "LANGUE AUDIO PRÉFÉRÉE (APPLIQUÉE AUTOMATIQUEMENT)",
                    color = Color(0xFF10B981),
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp
                )
                Spacer(modifier = Modifier.height(8.dp))

                val audioLangs = listOf(
                    "auto" to "Automatique (Par défaut)",
                    "fr" to "Français",
                    "en" to "Anglais / VO",
                    "es" to "Espagnol",
                    "ar" to "Arabe",
                    "de" to "Allemand",
                    "it" to "Italien",
                    "pt" to "Portugais",
                    "ru" to "Russe"
                )

                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    items(audioLangs, key = { it.first }) { (code, label) ->
                        val isSelected = preferredAudioLanguage == code
                        Box(
                            modifier = Modifier
                                .background(
                                    color = if (isSelected) Color(0xFF10B981) else Color(0xFF262C38),
                                    shape = RoundedCornerShape(8.dp)
                                )
                                .border(
                                    width = 1.dp,
                                    color = if (isSelected) Color(0xFF10B981) else Color.White.copy(alpha = 0.1f),
                                    shape = RoundedCornerShape(8.dp)
                                )
                                .tvFocusable(
                                    focusedColor = Color(0xFF10B981),
                                    borderRadius = 8.dp,
                                    onClick = { viewModel.setPreferredAudioLanguage(code) }
                                )
                                .padding(horizontal = 14.dp, vertical = 8.dp)
                        ) {
                            Text(
                                text = label,
                                color = Color.White,
                                fontSize = 13.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))
                Text(
                    text = "FORMAT DE SORTIE AUDIO & SON",
                    color = Color(0xFF10B981),
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp
                )
                Spacer(modifier = Modifier.height(8.dp))

                val formats = listOf("Stéréo (Défaut)", "Dolby Digital 5.1", "AC3 HEVC Audio", "Mono")
                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    formats.forEach { fmt ->
                        val isSelected = activeAudioFormat == fmt
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .background(
                                    color = if (isSelected) Color(0xFF10B981) else Color(0xFF262C38),
                                    shape = RoundedCornerShape(8.dp)
                                )
                                .border(
                                    width = 1.dp,
                                    color = if (isSelected) Color(0xFF10B981) else Color.White.copy(alpha = 0.1f),
                                    shape = RoundedCornerShape(8.dp)
                                )
                                .tvFocusable(
                                    focusedColor = Color(0xFF10B981),
                                    borderRadius = 8.dp,
                                    onClick = { viewModel.setActiveAudioFormat(fmt) }
                                )
                                .padding(vertical = 10.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = fmt,
                                color = Color.White,
                                fontSize = 12.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                textAlign = TextAlign.Center
                            )
                        }
                    }
                }
            }
        }

        // Card 2.7: Action Globale - Appliquer la configuration à tous les médias
        var globalAppliedMessage by remember { mutableStateOf(false) }

        Card(
            colors = CardDefaults.cardColors(containerColor = Color(0xFF0F172A)),
            border = BorderStroke(1.5.dp, Color(0xFF00E5FF)),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.DoneAll, contentDescription = null, tint = Color(0xFF00E5FF), modifier = Modifier.size(24.dp))
                    Spacer(modifier = Modifier.width(10.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Application Globale à Tous les Médias",
                            color = Color.White,
                            fontSize = 17.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = "Applique instantanément le style des sous-titres, la traduction, la détection de langue source, Sherpa-ONNX et le son à tous vos flux Live TV, Films et Séries de toutes vos playlists",
                            color = Color(0xFF94A3B8),
                            fontSize = 13.sp
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                Button(
                    onClick = {
                        viewModel.applyGlobalMediaConfiguration()
                        globalAppliedMessage = true
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF00E5FF)),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .tvFocusable(
                            focusedColor = Color(0xFF00E5FF),
                            borderRadius = 8.dp,
                            onClick = {
                                viewModel.applyGlobalMediaConfiguration()
                                globalAppliedMessage = true
                            }
                        )
                ) {
                    Icon(Icons.Default.Check, contentDescription = null, tint = Color(0xFF0F172A), modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Appliquer cette configuration à tous les médias et playlists",
                        color = Color(0xFF0F172A),
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                if (globalAppliedMessage) {
                    Spacer(modifier = Modifier.height(10.dp))
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(Color(0xFF10B981).copy(alpha = 0.2f), RoundedCornerShape(8.dp))
                            .padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.CheckCircle, contentDescription = null, tint = Color(0xFF10B981), modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Configuration appliquée avec succès à l'ensemble du Live TV, Films, Séries et Playlists !",
                            color = Color(0xFF10B981),
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }

        // Card 3: Stockage
        Card(
            colors = CardDefaults.cardColors(containerColor = Color(0xFF171C26)),
            border = BorderStroke(1.dp, Color(0xFF10B981).copy(alpha = 0.3f)),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .tvFocusable(
                        focusedColor = Color(0xFF10B981),
                        borderRadius = 12.dp,
                        onClick = { viewModel.setAllowInternalStorageRecording(!allowInternalStorageRecording) }
                    )
                    .padding(16.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f).padding(end = 16.dp)) {
                    Text(
                        text = "Stockage",
                        color = Color.White,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Autoriser l'enregistrement des flux vidéo sur le stockage interne",
                        color = Color.Gray,
                        fontSize = 14.sp
                    )
                }
                Switch(
                    checked = allowInternalStorageRecording,
                    onCheckedChange = { viewModel.setAllowInternalStorageRecording(it) },
                    colors = SwitchDefaults.colors(
                        checkedThumbColor = Color(0xFF10B981),
                        checkedTrackColor = Color(0xFF10B981).copy(alpha = 0.4f),
                        uncheckedThumbColor = Color.Gray,
                        uncheckedTrackColor = Color.Gray.copy(alpha = 0.4f)
                    )
                )
            }
        }

        // Carte : Partage des Données de Playlists
        PlaylistSharingCard(
            playlists = savedPlaylistsForSharing,
            onShowDetails = { showPlaylistDetailsDialog = true }
        )
        if (showPlaylistDetailsDialog) {
            PlaylistDetailsDialog(
                playlists = savedPlaylistsForSharing,
                onDismiss = { showPlaylistDetailsDialog = false }
            )
        }

        // Card 3: Remote Setup info
        if (webServerIp != null) {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF171C26)),
                border = BorderStroke(1.dp, Color(0xFF00E5FF).copy(alpha = 0.2f)),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Télécommande Web d'Importation", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                        Box(
                            modifier = Modifier
                                .background(Color(0xFF10B981), shape = RoundedCornerShape(4.dp))
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Text("SERVEUR ACTIF", color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Ajoutez ou modifiez vos playlists très facilement sans utiliser la télécommande de votre TV en ouvrant cette adresse depuis votre ordinateur ou smartphone connecté au même réseau Wi-Fi :",
                        color = Color.Gray,
                        fontSize = 14.sp
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = "http://$webServerIp:8080",
                        color = Color(0xFF00E5FF),
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        // Card: Debug Logs & System Console
        val isDebugConsoleVisible by com.example.debug.GlobalDebugSystem.isConsoleVisible.collectAsState()
        val isDebugLoggingEnabled by com.example.debug.GlobalDebugSystem.isDebugLoggingEnabled.collectAsState()
        val showDebugFab by com.example.debug.GlobalDebugSystem.showFloatingButton.collectAsState()
        val debugLogsList by com.example.debug.GlobalDebugSystem.logs.collectAsState()
        var showCrashReportViewerDialog by remember { mutableStateOf(false) }

        Card(
            colors = CardDefaults.cardColors(containerColor = Color(0xFF171C26)),
            border = BorderStroke(1.dp, Color(0xFF00FF66).copy(alpha = 0.4f)),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f).padding(end = 16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Icon(Icons.Default.BugReport, contentDescription = "Debug", tint = Color(0xFF00FF66), modifier = Modifier.size(20.dp))
                            Text(
                                text = "Console de Débogage & Logs Système",
                                color = Color.White,
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Affichage en direct des logs, appels API Stalker/Xtream, clics, états des sous-titres et événements système",
                            color = Color.Gray,
                            fontSize = 14.sp
                        )
                    }
                    Box(
                        modifier = Modifier
                            .background(
                                if (isDebugConsoleVisible) Color(0xFF00FF66).copy(alpha = 0.2f) else Color.White.copy(alpha = 0.08f),
                                shape = RoundedCornerShape(6.dp)
                            )
                            .border(
                                1.dp,
                                if (isDebugConsoleVisible) Color(0xFF00FF66) else Color.Gray.copy(alpha = 0.4f),
                                shape = RoundedCornerShape(6.dp)
                            )
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = "${debugLogsList.size} logs",
                            color = if (isDebugConsoleVisible) Color(0xFF00FF66) else Color.Gray,
                            fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))
                HorizontalDivider(color = Color.White.copy(alpha = 0.08f))
                Spacer(modifier = Modifier.height(14.dp))

                // Toggle 1: Console Visuelle Overlay
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .tvFocusable(
                            focusedColor = Color(0xFF00FF66),
                            borderRadius = 8.dp,
                            onClick = { com.example.debug.GlobalDebugSystem.setConsoleVisible(!isDebugConsoleVisible) }
                        )
                        .padding(vertical = 6.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f).padding(end = 12.dp)) {
                        Text(
                            text = "Afficher la console visuelle à l'écran",
                            color = Color.White,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Medium
                        )
                        Text(
                            text = "Affiche la fenêtre noire et verte des logs en superposition (40% bas d'écran)",
                            color = Color.Gray,
                            fontSize = 12.sp
                        )
                    }
                    Switch(
                        checked = isDebugConsoleVisible,
                        onCheckedChange = { com.example.debug.GlobalDebugSystem.setConsoleVisible(it) },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = Color(0xFF00FF66),
                            checkedTrackColor = Color(0xFF00FF66).copy(alpha = 0.4f),
                            uncheckedThumbColor = Color.Gray,
                            uncheckedTrackColor = Color.Gray.copy(alpha = 0.3f)
                        )
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Toggle 2: Bouton d'accès rapide flottant
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .tvFocusable(
                            focusedColor = Color(0xFF00FF66),
                            borderRadius = 8.dp,
                            onClick = { com.example.debug.GlobalDebugSystem.setShowFloatingButton(!showDebugFab) }
                        )
                        .padding(vertical = 6.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f).padding(end = 12.dp)) {
                        Text(
                            text = "Bouton flottant d'accès rapide (Icône Insecte)",
                            color = Color.White,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Medium
                        )
                        Text(
                            text = "Affiche un bouton discret en bas à droite pour ouvrir/fermer la console en un clic",
                            color = Color.Gray,
                            fontSize = 12.sp
                        )
                    }
                    Switch(
                        checked = showDebugFab,
                        onCheckedChange = { com.example.debug.GlobalDebugSystem.setShowFloatingButton(it) },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = Color(0xFF00FF66),
                            checkedTrackColor = Color(0xFF00FF66).copy(alpha = 0.4f),
                            uncheckedThumbColor = Color.Gray,
                            uncheckedTrackColor = Color.Gray.copy(alpha = 0.3f)
                        )
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Toggle 3: Capture des logs en mémoire
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .tvFocusable(
                            focusedColor = Color(0xFF00FF66),
                            borderRadius = 8.dp,
                            onClick = { com.example.debug.GlobalDebugSystem.setDebugLoggingEnabled(!isDebugLoggingEnabled) }
                        )
                        .padding(vertical = 6.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f).padding(end = 12.dp)) {
                        Text(
                            text = "Activer l'enregistrement des logs système",
                            color = Color.White,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Medium
                        )
                        Text(
                            text = "Intercepte les requêtes réseau, les appels de fonctions et les clics pour le débogage",
                            color = Color.Gray,
                            fontSize = 12.sp
                        )
                    }
                    Switch(
                        checked = isDebugLoggingEnabled,
                        onCheckedChange = { com.example.debug.GlobalDebugSystem.setDebugLoggingEnabled(it) },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = Color(0xFF00FF66),
                            checkedTrackColor = Color(0xFF00FF66).copy(alpha = 0.4f),
                            uncheckedThumbColor = Color.Gray,
                            uncheckedTrackColor = Color.Gray.copy(alpha = 0.3f)
                        )
                    )
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Quick Action Buttons
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Button(
                        onClick = { com.example.debug.GlobalDebugSystem.copyLogsToClipboard(context) },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF00FF66), contentColor = Color(0xFF0B101D)),
                        modifier = Modifier.tvFocusable(onClick = { com.example.debug.GlobalDebugSystem.copyLogsToClipboard(context) })
                    ) {
                        Icon(Icons.Default.ContentCopy, contentDescription = "Copy", modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Copier (COPY)", fontWeight = FontWeight.Bold)
                    }

                    Button(
                        onClick = { com.example.debug.GlobalDebugSystem.downloadLogsToFile(context) },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF10B981)),
                        modifier = Modifier.tvFocusable(onClick = { com.example.debug.GlobalDebugSystem.downloadLogsToFile(context) })
                    ) {
                        Icon(Icons.Default.Download, contentDescription = "Download", tint = Color.White, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("debug-log.txt", color = Color.White)
                    }

                    Button(
                        onClick = { com.example.debug.GlobalDebugSystem.clearLogs() },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF374151)),
                        modifier = Modifier.tvFocusable(onClick = { com.example.debug.GlobalDebugSystem.clearLogs() })
                    ) {
                        Icon(Icons.Default.Clear, contentDescription = "Clear", tint = Color.White, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Effacer", color = Color.White)
                    }
                }

                val hasLastCrashLog by com.example.debug.GlobalDebugSystem.hasLastCrashLog.collectAsState()
                Spacer(modifier = Modifier.height(10.dp))
                if (hasLastCrashLog) {
                    Text(
                        text = "🚨 Rapport de crash enregistré avant le dernier plantage :",
                        color = Color(0xFFFF6B6B),
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Button(
                            onClick = { com.example.debug.GlobalDebugSystem.copyLastCrashReportToClipboard(context) },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFF2A4B)),
                            modifier = Modifier.tvFocusable(onClick = { com.example.debug.GlobalDebugSystem.copyLastCrashReportToClipboard(context) })
                        ) {
                            Icon(Icons.Default.BugReport, contentDescription = "Crash", tint = Color.White, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Copier le Crash Log", color = Color.White, fontWeight = FontWeight.Bold)
                        }
                        Button(
                            onClick = { showCrashReportViewerDialog = true },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFDC2626)),
                            modifier = Modifier.tvFocusable(onClick = { showCrashReportViewerDialog = true })
                        ) {
                            Icon(Icons.Default.Visibility, contentDescription = "View crash log", tint = Color.White, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Voir le Rapport", color = Color.White, fontWeight = FontWeight.Bold)
                        }
                        Button(
                            onClick = { com.example.debug.GlobalDebugSystem.downloadLastCrashReport(context) },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF991B1B)),
                            modifier = Modifier.tvFocusable(onClick = { com.example.debug.GlobalDebugSystem.downloadLastCrashReport(context) })
                        ) {
                            Icon(Icons.Default.Download, contentDescription = "Download crash log", tint = Color.White, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("last_crash_debug_log.txt", color = Color.White)
                        }
                        Button(
                            onClick = { com.example.debug.GlobalDebugSystem.clearLastCrashReport(context) },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF4B5563)),
                            modifier = Modifier.tvFocusable(onClick = { com.example.debug.GlobalDebugSystem.clearLastCrashReport(context) })
                        ) {
                            Icon(Icons.Default.Delete, contentDescription = "Effacer crash log", tint = Color.White, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Effacer le Rapport", color = Color.White)
                        }
                    }
                } else {
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Button(
                            onClick = {
                                com.example.debug.GlobalDebugSystem.generateDiagnosticCrashReport(context)
                                showCrashReportViewerDialog = true
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF7F1D1D)),
                            modifier = Modifier.tvFocusable(onClick = {
                                com.example.debug.GlobalDebugSystem.generateDiagnosticCrashReport(context)
                                showCrashReportViewerDialog = true
                            })
                        ) {
                            Icon(Icons.Default.BugReport, contentDescription = "Générer Crash Log", tint = Color(0xFFFF6B6B), modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Générer Rapport de Crash (Test & Diagnostic)", color = Color.White, fontSize = 12.sp)
                        }
                    }
                }

                if (showCrashReportViewerDialog) {
                    val crashText = remember { com.example.debug.GlobalDebugSystem.getLastCrashReportText(context) ?: "Aucun rapport de crash enregistré sur le disque." }
                    AlertDialog(
                        onDismissRequest = { showCrashReportViewerDialog = false },
                        containerColor = Color(0xFF131822),
                        title = {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Icon(Icons.Default.BugReport, contentDescription = null, tint = Color(0xFFFF4D4D), modifier = Modifier.size(24.dp))
                                Text("Rapport de Crash Débug", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                            }
                        },
                        text = {
                            Column(modifier = Modifier.fillMaxWidth().heightIn(max = 420.dp)) {
                                Text(
                                    text = "last_crash_debug_log.txt (Journal enregistré avant le plantage) :",
                                    color = Color(0xFFFF8080),
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.SemiBold
                                )
                                Spacer(modifier = Modifier.height(8.dp))
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .weight(1f)
                                        .background(Color.Black.copy(alpha = 0.7f), RoundedCornerShape(8.dp))
                                        .border(1.dp, Color(0xFF374151), RoundedCornerShape(8.dp))
                                        .padding(12.dp)
                                ) {
                                    androidx.compose.foundation.lazy.LazyColumn(modifier = Modifier.fillMaxSize()) {
                                        item {
                                            Text(
                                                text = crashText,
                                                color = Color(0xFFE5E7EB),
                                                fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace,
                                                fontSize = 11.sp,
                                                lineHeight = 16.sp
                                            )
                                        }
                                    }
                                }
                            }
                        },
                        confirmButton = {
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Button(
                                    onClick = { com.example.debug.GlobalDebugSystem.copyLastCrashReportToClipboard(context) },
                                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFF2A4B))
                                ) {
                                    Icon(Icons.Default.ContentCopy, contentDescription = null, tint = Color.White, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Copier", color = Color.White)
                                }
                                Button(
                                    onClick = { com.example.debug.GlobalDebugSystem.downloadLastCrashReport(context) },
                                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF10B981))
                                ) {
                                    Icon(Icons.Default.Download, contentDescription = null, tint = Color.White, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Télécharger", color = Color.White)
                                }
                                Button(
                                    onClick = {
                                        com.example.debug.GlobalDebugSystem.clearLastCrashReport(context)
                                        showCrashReportViewerDialog = false
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF6B7280))
                                ) {
                                    Icon(Icons.Default.Delete, contentDescription = null, tint = Color.White, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Effacer", color = Color.White)
                                }
                            }
                        },
                        dismissButton = {
                            TextButton(onClick = { showCrashReportViewerDialog = false }) {
                                Text("Fermer", color = Color.Gray)
                            }
                        }
                    )
                }
            }
        }

        // Card 4: Database controls
        Card(
            colors = CardDefaults.cardColors(containerColor = Color(0xFF171C26)),
            border = BorderStroke(1.dp, Color(0xFF374151)),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text("Contrôles de la Base de Données", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(8.dp))
                Text("Effacez votre historique de lecture pour vider le cache local et libérer de l'espace de stockage.", color = Color.Gray, fontSize = 14.sp)
                Spacer(modifier = Modifier.height(12.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    Button(
                        onClick = { viewModel.clearHistory() },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF4B5563)),
                        modifier = Modifier.tvFocusable(onClick = { viewModel.clearHistory() })
                    ) {
                        Text("Effacer l'Historique de Lecture")
                    }
                    Button(
                        onClick = { viewModel.resetAllPlaylists() },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFDC2626)),
                        modifier = Modifier.tvFocusable(onClick = { viewModel.resetAllPlaylists() })
                    ) {
                        Icon(Icons.Default.Delete, contentDescription = "Reset", tint = Color.White, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Effacer & Réinitialiser Toutes les Playlists", color = Color.White)
                    }
                }
            }
        }
    }
}

/**
 * Nettoie le texte des sous-titres pour n'afficher STRICTEMENT que le texte
 * sans aucun préfixe, crochet, métadonnée ou indicateur système.
 */
fun cleanSubtitleOnlyText(raw: String): String {
    if (raw.isBlank()) return ""
    var t = raw.trim()
    // Supprimer tous les préfixes système, flèches, puces, et tags de statut (ex: [VOIX], [IA], [DIRECT VOCAL], [FR->EN], etc.)
    t = t.replace(Regex("^[▶►•-]?\\s*(\\[.*?\\]|\\(.*?\\))\\s*:?\\s*"), "")
    t = t.replace(Regex("^(DIRECT VOCAL IA|Direct Vocal|Traduction|Transcription|Sous-titre|Subtitle|Source|Cible|Sherpa|Vosk)\\s*[:•-]\\s*", RegexOption.IGNORE_CASE), "")
    t = t.replace(Regex("^[▶►•-]\\s*"), "")
    // Supprimer les annotations sonores et bruits de fond
    t = t.replace(Regex("\\[(Musique|Applaudissements|Rires|Silence|Bruit|Music|Applause|Laughter|Noise)\\]", RegexOption.IGNORE_CASE), "")
    t = t.replace(Regex("\\((Musique|Applaudissements|Rires|Silence|Bruit|Music|Applause|Laughter|Noise)\\)", RegexOption.IGNORE_CASE), "")
    return t.replace(Regex("\\s+"), " ").trim()
}

@Composable
fun SimpleVideoPlayer(
    streamUrl: String,
    headers: Map<String, String> = emptyMap(),
    isMuted: Boolean = false,
    viewModel: IptvViewModel
) {
    val context = LocalContext.current
    val playerPrefs = remember { context.getSharedPreferences("iptv_player_prefs", android.content.Context.MODE_PRIVATE) }
    var hasError by remember { mutableStateOf(false) }
    val sharedPlayer = remember(viewModel) { viewModel.getSharedPlayer() }

    val subtitlesEnabled by viewModel.subtitlesEnabled.collectAsState()
    val subtitleStyleMode by viewModel.subtitleStyleMode.collectAsState()
    val subtitleSizeState by viewModel.subtitleSizeState.collectAsState()
    val subtitleTranslationEnabled by viewModel.subtitleTranslationEnabled.collectAsState()
    val subtitleOcrEnabled by viewModel.subtitleOcrEnabled.collectAsState()
    val subtitleTargetLanguage by viewModel.subtitleTargetLanguage.collectAsState()
    val translatedSubtitleText by viewModel.translatedSubtitleText.collectAsState()
    val externalTranslatedSubtitle by viewModel.externalTranslatedSubtitle.collectAsState()
    val currentSubtitleText by viewModel.currentSubtitleText.collectAsState()
    val voiceSubtitlesEnabled by viewModel.voiceSubtitlesEnabled.collectAsState()
    val voiceSubtitleLanguage by viewModel.voiceSubtitleLanguage.collectAsState()
    val voiceSpeechDetected by viewModel.voiceSpeechDetected.collectAsState()
    val voiceSubtitleSyncOffsetMs by viewModel.voiceSubtitleSyncOffsetMs.collectAsState()
    val voiceSubtitleAutoCalibration by viewModel.voiceSubtitleAutoCalibration.collectAsState()
    val autoCalibratedOffsetMs by viewModel.autoCalibratedOffsetMs.collectAsState()
    val voiceSubtitleClearDelaySeconds by viewModel.voiceSubtitleClearDelaySeconds.collectAsState()
    val voiceSubtitleAutoDuration by viewModel.voiceSubtitleAutoDuration.collectAsState()
    val voiceSubtitleStreamingMode by viewModel.voiceSubtitleStreamingMode.collectAsState()

    var showControls by remember { mutableStateOf(false) }
    var showSubtitleMenu by remember { mutableStateOf(false) }

    var availableSubtitleTracks by remember { mutableStateOf<List<Pair<androidx.media3.common.Tracks.Group, Int>>>(emptyList()) }

    val captionStyle = remember(subtitleStyleMode) {
        when {
            subtitleStyleMode.contains("Bande blanche", ignoreCase = true) || subtitleStyleMode.contains("texte noir", ignoreCase = true) -> androidx.media3.ui.CaptionStyleCompat(
                android.graphics.Color.BLACK,
                android.graphics.Color.WHITE,
                android.graphics.Color.TRANSPARENT,
                androidx.media3.ui.CaptionStyleCompat.EDGE_TYPE_NONE,
                android.graphics.Color.WHITE,
                com.example.ui.SubtitleFonts.bold
            )
            subtitleStyleMode.contains("Bande noire, texte blanc", ignoreCase = true) -> androidx.media3.ui.CaptionStyleCompat(
                android.graphics.Color.WHITE,
                android.graphics.Color.BLACK,
                android.graphics.Color.TRANSPARENT,
                androidx.media3.ui.CaptionStyleCompat.EDGE_TYPE_NONE,
                android.graphics.Color.BLACK,
                com.example.ui.SubtitleFonts.bold
            )
            subtitleStyleMode.contains("Bande noire", ignoreCase = true) -> androidx.media3.ui.CaptionStyleCompat(
                android.graphics.Color.parseColor("#FFE000"),
                android.graphics.Color.BLACK,
                android.graphics.Color.TRANSPARENT,
                androidx.media3.ui.CaptionStyleCompat.EDGE_TYPE_NONE,
                android.graphics.Color.BLACK,
                com.example.ui.SubtitleFonts.bold
            )
            subtitleStyleMode.contains("texte blanc", ignoreCase = true) -> androidx.media3.ui.CaptionStyleCompat(
                android.graphics.Color.WHITE,
                android.graphics.Color.TRANSPARENT,
                android.graphics.Color.TRANSPARENT,
                androidx.media3.ui.CaptionStyleCompat.EDGE_TYPE_OUTLINE,
                android.graphics.Color.BLACK,
                com.example.ui.SubtitleFonts.bold
            )
            subtitleStyleMode.contains("Adaptatif", ignoreCase = true) -> androidx.media3.ui.CaptionStyleCompat(
                android.graphics.Color.WHITE,
                android.graphics.Color.TRANSPARENT,
                android.graphics.Color.TRANSPARENT,
                androidx.media3.ui.CaptionStyleCompat.EDGE_TYPE_OUTLINE,
                android.graphics.Color.BLACK,
                com.example.ui.SubtitleFonts.bold
            )
            subtitleStyleMode.contains("vert", ignoreCase = true) || subtitleStyleMode.contains("#00FF66", ignoreCase = true) -> androidx.media3.ui.CaptionStyleCompat(
                android.graphics.Color.parseColor("#00FF66"),
                android.graphics.Color.TRANSPARENT,
                android.graphics.Color.TRANSPARENT,
                androidx.media3.ui.CaptionStyleCompat.EDGE_TYPE_OUTLINE,
                android.graphics.Color.BLACK,
                com.example.ui.SubtitleFonts.bold
            )
            subtitleStyleMode.contains("cyan", ignoreCase = true) || subtitleStyleMode.contains("#00E5FF", ignoreCase = true) -> androidx.media3.ui.CaptionStyleCompat(
                android.graphics.Color.parseColor("#00E5FF"),
                android.graphics.Color.TRANSPARENT,
                android.graphics.Color.TRANSPARENT,
                androidx.media3.ui.CaptionStyleCompat.EDGE_TYPE_OUTLINE,
                android.graphics.Color.BLACK,
                com.example.ui.SubtitleFonts.bold
            )
            else -> androidx.media3.ui.CaptionStyleCompat(
                android.graphics.Color.parseColor("#FFE000"),
                android.graphics.Color.TRANSPARENT,
                android.graphics.Color.TRANSPARENT,
                androidx.media3.ui.CaptionStyleCompat.EDGE_TYPE_OUTLINE,
                android.graphics.Color.BLACK,
                com.example.ui.SubtitleFonts.bold
            )
        }
    }

    val subtitleSizeInSp = remember(subtitleSizeState) {
        when (subtitleSizeState) {
            "Petit" -> 16f
            "Moyen" -> 22f
            "Grand" -> 28f
            "Très Grand" -> 36f
            else -> 22f
        }
    }

    LaunchedEffect(streamUrl, headers, isMuted) {
        hasError = false
        try {
            viewModel.playOnSharedPlayer(streamUrl, headers, isMuted)
        } catch (e: Exception) {
            Log.e("SimplePlayer", "Exception in playOnSharedPlayer: ${e.message}", e)
            hasError = true
        }
    }

    LaunchedEffect(showControls) {
        if (showControls && !showSubtitleMenu) {
            delay(4000)
            showControls = false
        }
    }

    DisposableEffect(streamUrl, sharedPlayer) {
        val listener = object : androidx.media3.common.Player.Listener {
            override fun onPlayerError(error: androidx.media3.common.PlaybackException) {
                Log.e("SimplePlayer", "Playback error on shared player: ${error.message}", error)
                hasError = true
            }

            override fun onTracksChanged(tracks: androidx.media3.common.Tracks) {
                val subs = mutableListOf<Pair<androidx.media3.common.Tracks.Group, Int>>()
                for (group in tracks.groups) {
                    if (group.type == androidx.media3.common.C.TRACK_TYPE_TEXT) {
                        for (i in 0 until group.length) {
                            subs.add(Pair(group, i))
                        }
                    }
                }
                availableSubtitleTracks = subs

                if (subtitlesEnabled || subtitleTranslationEnabled) {
                    val hasSelectedSubTrack = subs.any { (group, idx) -> group.isTrackSelected(idx) }
                    if (!hasSelectedSubTrack && subs.isNotEmpty()) {
                        val (firstGroup, firstIdx) = subs.first()
                        sharedPlayer.trackSelectionParameters = sharedPlayer.trackSelectionParameters.buildUpon()
                            .setTrackTypeDisabled(androidx.media3.common.C.TRACK_TYPE_TEXT, false)
                            .clearOverridesOfType(androidx.media3.common.C.TRACK_TYPE_TEXT)
                            .setOverrideForType(androidx.media3.common.TrackSelectionOverride(firstGroup.mediaTrackGroup, firstIdx))
                            .build()
                    }
                } else {
                    sharedPlayer.trackSelectionParameters = sharedPlayer.trackSelectionParameters.buildUpon()
                        .setTrackTypeDisabled(androidx.media3.common.C.TRACK_TYPE_TEXT, true)
                        .clearOverridesOfType(androidx.media3.common.C.TRACK_TYPE_TEXT)
                        .build()
                }
            }
        }
        sharedPlayer.addListener(listener)

        val currentTracks = sharedPlayer.currentTracks
        val subs = mutableListOf<Pair<androidx.media3.common.Tracks.Group, Int>>()
        for (group in currentTracks.groups) {
            if (group.type == androidx.media3.common.C.TRACK_TYPE_TEXT) {
                for (i in 0 until group.length) {
                    subs.add(Pair(group, i))
                }
            }
        }
        availableSubtitleTracks = subs

        onDispose {
            sharedPlayer.removeListener(listener)
        }
    }

    LaunchedEffect(subtitlesEnabled, subtitleTranslationEnabled, sharedPlayer, availableSubtitleTracks) {
        sharedPlayer?.let { player ->
            val enableText = subtitlesEnabled || subtitleTranslationEnabled
            player.trackSelectionParameters = player.trackSelectionParameters.buildUpon()
                .setTrackTypeDisabled(androidx.media3.common.C.TRACK_TYPE_TEXT, !enableText)
                .apply {
                    if (!enableText) {
                        clearOverridesOfType(androidx.media3.common.C.TRACK_TYPE_TEXT)
                    } else if (availableSubtitleTracks.isNotEmpty()) {
                        val hasSelected = availableSubtitleTracks.any { (g, idx) -> g.isTrackSelected(idx) }
                        if (!hasSelected) {
                            val (firstGroup, firstIdx) = availableSubtitleTracks.first()
                            setOverrideForType(androidx.media3.common.TrackSelectionOverride(firstGroup.mediaTrackGroup, firstIdx))
                        }
                    }
                }
                .build()
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .clickable { showControls = !showControls }
    ) {
        if (hasError) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color(0xFF1E293B)),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.padding(8.dp)) {
                    Icon(
                        imageVector = Icons.Default.Warning,
                        contentDescription = "Error loading stream",
                        tint = Color(0xFFEF4444),
                        modifier = Modifier.size(24.dp)
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Flux Indisponible",
                        color = Color.White,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        textAlign = TextAlign.Center
                    )
                }
            }
        } else {
            AndroidView(
                factory = { ctx ->
                    PlayerView(ctx).apply {
                        useController = false
                        resizeMode = androidx.media3.ui.AspectRatioFrameLayout.RESIZE_MODE_FIT
                        layoutParams = FrameLayout.LayoutParams(
                            FrameLayout.LayoutParams.MATCH_PARENT,
                            FrameLayout.LayoutParams.MATCH_PARENT
                        )
                        subtitleView?.apply {
                            visibility = if (subtitlesEnabled && !subtitleTranslationEnabled) android.view.View.VISIBLE else android.view.View.GONE
                            setViewType(androidx.media3.ui.SubtitleView.VIEW_TYPE_CANVAS)
                            setStyle(captionStyle)
                            setFixedTextSize(android.util.TypedValue.COMPLEX_UNIT_SP, subtitleSizeInSp)
                        }
                    }
                },
                update = { playerView ->
                    if (playerView.player != sharedPlayer) {
                        playerView.player = sharedPlayer
                    }
                    playerView.resizeMode = androidx.media3.ui.AspectRatioFrameLayout.RESIZE_MODE_FIT
                    Log.d("SubtitleDebug", "COMPOSABLE=SimpleVideoPlayer | subtitlesEnabled=$subtitlesEnabled | translationEnabled=$subtitleTranslationEnabled | targetLang=$subtitleTargetLanguage | styleMode=$subtitleStyleMode")
                    playerView.subtitleView?.let { subView ->
                        if (subtitleTranslationEnabled || voiceSubtitlesEnabled) {
                            subView.setCues(emptyList())
                            subView.visibility = android.view.View.GONE
                        } else if (subtitlesEnabled) {
                            val hasCustomComposeSubs = !currentSubtitleText.isNullOrBlank()
                            if (hasCustomComposeSubs) {
                                subView.setCues(emptyList())
                                subView.visibility = android.view.View.GONE
                            } else {
                                subView.visibility = android.view.View.VISIBLE
                                subView.setStyle(captionStyle)
                                subView.setFixedTextSize(android.util.TypedValue.COMPLEX_UNIT_SP, subtitleSizeInSp)
                                subView.requestLayout()
                                subView.invalidate()
                            }
                        } else {
                            subView.setCues(emptyList())
                            subView.visibility = android.view.View.GONE
                        }
                    }
                },
                onRelease = { playerView ->
                    playerView.player = null
                },
                modifier = Modifier.fillMaxSize()
            )

            // Custom Subtitles Overlay (Compose) - Supports translation, CEA-608/WebVTT, OCR & Voice STT with full styling
            val effectiveTranslatedText = if (!translatedSubtitleText.isNullOrBlank()) translatedSubtitleText else externalTranslatedSubtitle
            val displaySubtitleText = if (subtitlesEnabled || subtitleTranslationEnabled || voiceSubtitlesEnabled) {
                if (subtitleTranslationEnabled) {
                    if (!effectiveTranslatedText.isNullOrBlank()) {
                        effectiveTranslatedText
                    } else {
                        currentSubtitleText
                    }
                } else if (!currentSubtitleText.isNullOrBlank()) {
                    currentSubtitleText
                } else {
                    null
                }
            } else {
                null
            }

            val pureSubtitleText = remember(displaySubtitleText) {
                if (displaySubtitleText.isNullOrBlank()) ""
                else cleanSubtitleOnlyText(displaySubtitleText)
            }

            com.example.ui.VoiceDiagnosticsOverlay(enabled = voiceSubtitlesEnabled)
if (pureSubtitleText.isNotBlank()) {
                val (translatedTextColor, translatedBgColor, translatedHasShadow) = remember(subtitleStyleMode) {
                    when {
                        subtitleStyleMode.contains("vert", ignoreCase = true) || subtitleStyleMode.contains("#00FF66", ignoreCase = true) -> Triple(
                            Color(0xFF00FF66),
                            Color.Black.copy(alpha = 0.65f),
                            true
                        )
                        subtitleStyleMode.contains("cyan", ignoreCase = true) || subtitleStyleMode.contains("#00E5FF", ignoreCase = true) -> Triple(
                            Color(0xFF00E5FF),
                            Color.Black.copy(alpha = 0.65f),
                            true
                        )
                        subtitleStyleMode.contains("Bande blanche", ignoreCase = true) || subtitleStyleMode.contains("texte noir", ignoreCase = true) -> Triple(
                            Color.Black,
                            Color.White.copy(alpha = 0.95f),
                            false
                        )
                        subtitleStyleMode.contains("Bande noire, texte blanc", ignoreCase = true) -> Triple(
                            Color.White,
                            Color.Black.copy(alpha = 0.85f),
                            false
                        )
                        subtitleStyleMode.contains("Bande noire, texte jaune", ignoreCase = true) -> Triple(
                            Color(0xFFFFE000),
                            Color.Black.copy(alpha = 0.85f),
                            false
                        )
                        subtitleStyleMode.contains("texte blanc", ignoreCase = true) -> Triple(
                            Color.White,
                            Color.Black.copy(alpha = 0.85f),
                            false
                        )
                        subtitleStyleMode.contains("Adaptatif", ignoreCase = true) -> Triple(
                            Color.White,
                            Color.Black.copy(alpha = 0.65f),
                            true
                        )
                        else -> Triple(
                            Color(0xFFFFE000),
                            Color.Black.copy(alpha = 0.65f),
                            true
                        )
                    }
                }

                val isArabicSubtitle = remember(pureSubtitleText) {
                    pureSubtitleText.any { it in '\u0600'..'\u06FF' || it in '\u0750'..'\u077F' || it in '\u08A0'..'\u08FF' || it in '\uFB50'..'\uFDFF' || it in '\uFE70'..'\uFEFF' }
                }

                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(bottom = 16.dp, start = 12.dp, end = 12.dp),
                    contentAlignment = Alignment.BottomCenter
                ) {
                    CompositionLocalProvider(
                        LocalLayoutDirection provides (if (isArabicSubtitle) LayoutDirection.Rtl else LayoutDirection.Ltr)
                    ) {
                        Text(
                            text = pureSubtitleText,
                            fontFamily = com.example.ui.SubtitleFontFamily,
                            color = translatedTextColor,
                            fontSize = subtitleSizeInSp.sp,
                            lineHeight = (subtitleSizeInSp * 1.35f).sp,
                            fontWeight = FontWeight.Bold,
                            textAlign = TextAlign.Center,
                            style = TextStyle(
                                shadow = if (translatedHasShadow) androidx.compose.ui.graphics.Shadow(
                                    color = Color.Black,
                                    offset = androidx.compose.ui.geometry.Offset(2f, 2f),
                                    blurRadius = 4f
                                ) else null
                            ),
                            modifier = Modifier
                                .background(
                                    translatedBgColor,
                                    shape = RoundedCornerShape(6.dp)
                                )
                                .padding(horizontal = 12.dp, vertical = 6.dp)
                        )
                    }
                }
            }

            // Subtitles Toggle / Settings Button Overlay
            Box(
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .padding(8.dp)
                    .zIndex(20f)
            ) {
                IconButton(
                    onClick = { showSubtitleMenu = !showSubtitleMenu },
                    modifier = Modifier
                        .size(36.dp)
                        .background(Color.Black.copy(alpha = 0.75f), shape = RoundedCornerShape(8.dp))
                        .border(1.dp, if (subtitlesEnabled || subtitleTranslationEnabled) Color(0xFF10B981) else Color(0x66FFFFFF), RoundedCornerShape(8.dp))
                        .tvFocusable(onClick = { showSubtitleMenu = !showSubtitleMenu })
                ) {
                    Icon(
                        imageVector = Icons.Default.Subtitles,
                        contentDescription = "Sous-titres & Traduction",
                        tint = if (subtitlesEnabled || subtitleTranslationEnabled) Color(0xFF10B981) else Color.White,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }

            // Subtitles & Translation Side Drawer / Menu
            AnimatedVisibility(
                visible = showSubtitleMenu,
                enter = slideInHorizontally(initialOffsetX = { it }) + fadeIn(),
                exit = slideOutHorizontally(targetOffsetX = { it }) + fadeOut(),
                modifier = Modifier
                    .align(Alignment.CenterEnd)
                    .fillMaxHeight()
                    .width(300.dp)
                    .background(Color(0xFF0F172A).copy(alpha = 0.95f))
                    .border(BorderStroke(1.dp, Color(0xFF1E293B)))
                    .padding(16.dp)
            ) {
                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Icon(Icons.Default.Subtitles, contentDescription = "Sous-titres", tint = Color(0xFF00E5FF))
                            Text(
                                text = "Sous-titres & Traduction",
                                color = Color.White,
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        IconButton(onClick = { showSubtitleMenu = false }) {
                            Icon(Icons.Default.Close, contentDescription = "Fermer", tint = Color.White)
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    LazyColumn(
                        verticalArrangement = Arrangement.spacedBy(14.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        // Subtitle Tracks Selection
                        item {
                            Column {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text("SOUS-TITRES", color = Color(0xFF00E5FF), fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)

                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(4.dp),
                                        modifier = Modifier
                                            .background(Color(0xFF1E293B), shape = RoundedCornerShape(12.dp))
                                            .tvFocusable(
                                                onClick = {
                                                    val current = viewModel.subtitlesEnabled.value
                                                    val newEnabled = !current
                                                    com.example.debug.GlobalDebugSystem.logFunctionCall("toggleSubtitles_LiveTV", "old" to current, "new" to newEnabled)
                                                    viewModel.setSubtitlesEnabled(newEnabled)
                                                }
                                            )
                                            .padding(horizontal = 8.dp, vertical = 4.dp)
                                    ) {
                                        Icon(
                                            imageVector = if (subtitlesEnabled) Icons.Default.CheckCircle else Icons.Default.Close,
                                            contentDescription = "Activer/Désactiver",
                                            tint = if (subtitlesEnabled) Color(0xFF10B981) else Color.Gray,
                                            modifier = Modifier.size(14.dp)
                                        )
                                        Text(
                                            text = if (subtitlesEnabled) "Actifs" else "Désactivés",
                                            color = Color.White,
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }
                                Spacer(modifier = Modifier.height(8.dp))

                                val detectedSubtitleLang by viewModel.detectedSubtitleLanguage.collectAsState()
                                if (availableSubtitleTracks.isEmpty()) {
                                    Card(
                                        colors = CardDefaults.cardColors(containerColor = Color(0x1F1E293B)),
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Column(modifier = Modifier.padding(12.dp)) {
                                            Text(
                                                text = if (!detectedSubtitleLang.isNullOrBlank()) "Sous-titres détectés en direct" else "Détection automatique des sous-titres...",
                                                color = if (!detectedSubtitleLang.isNullOrBlank()) Color(0xFF10B981) else Color.Gray,
                                                fontSize = 12.sp,
                                                fontWeight = FontWeight.Medium
                                            )
                                            if (!detectedSubtitleLang.isNullOrBlank()) {
                                                Spacer(modifier = Modifier.height(2.dp))
                                                Text(
                                                    text = "Langue source : $detectedSubtitleLang",
                                                    color = Color(0xFF00E5FF),
                                                    fontSize = 11.sp
                                                )
                                            }
                                        }
                                    }

                                    Spacer(modifier = Modifier.height(10.dp))

                                    // Offline Voice Subtitles option
                                    val isVoskDownloading by viewModel.isVoiceModelDownloading.collectAsState()
                                    val voskProgress by viewModel.voiceModelDownloadProgress.collectAsState()
                                    val voskMessage by viewModel.voiceModelDownloadMessage.collectAsState()

                                    Column(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .background(
                                                color = if (voiceSubtitlesEnabled) Color(0x3300E5FF) else Color(0x1AFFFFFF),
                                                shape = RoundedCornerShape(8.dp)
                                            )
                                            .border(
                                                width = 1.dp,
                                                color = if (voiceSubtitlesEnabled) Color(0xFF00E5FF) else Color(0x33FFFFFF),
                                                shape = RoundedCornerShape(8.dp)
                                            )
                                            .padding(12.dp)
                                    ) {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Column(
                                                modifier = Modifier.weight(1f).padding(end = 8.dp)
                                            ) {
                                                Text(
                                                    text = "Sous-titres vocaux (hors-ligne)",
                                                    color = Color.White,
                                                    fontSize = 12.sp,
                                                    fontWeight = FontWeight.Bold
                                                )
                                                Text(
                                                    text = "Génération IA Sherpa-ONNX locale",
                                                    color = Color.Gray,
                                                    fontSize = 10.sp
                                                )
                                            }
                                            Switch(
                                                checked = voiceSubtitlesEnabled,
                                                onCheckedChange = { checked ->
                                                    com.example.debug.GlobalDebugSystem.logFunctionCall("toggleVoiceSubtitles_LiveTV", "enabled" to checked)
                                                    viewModel.setVoiceSubtitlesEnabled(checked)
                                                },
                                                colors = SwitchDefaults.colors(
                                                    checkedThumbColor = Color(0xFF00E5FF),
                                                    checkedTrackColor = Color(0xFF00E5FF).copy(alpha = 0.4f)
                                                )
                                            )
                                        }

                                        if (isVoskDownloading) {
                                            Spacer(modifier = Modifier.height(8.dp))
                                            Column(modifier = Modifier.fillMaxWidth()) {
                                                Row(
                                                    modifier = Modifier.fillMaxWidth(),
                                                    horizontalArrangement = Arrangement.SpaceBetween
                                                ) {
                                                    Text(
                                                        text = voskMessage ?: "Téléchargement modèle vocal...",
                                                        color = Color(0xFF00E5FF),
                                                        fontSize = 10.sp
                                                    )
                                                    Text(
                                                        text = "${(voskProgress * 100).toInt()}%",
                                                        color = Color(0xFF00E5FF),
                                                        fontSize = 10.sp,
                                                        fontWeight = FontWeight.Bold
                                                    )
                                                }
                                                Spacer(modifier = Modifier.height(4.dp))
                                                LinearProgressIndicator(
                                                    progress = { voskProgress },
                                                    modifier = Modifier.fillMaxWidth().height(4.dp).clip(RoundedCornerShape(2.dp)),
                                                    color = Color(0xFF00E5FF),
                                                    trackColor = Color(0xFF1E293B)
                                                )
                                            }
                                        }

                                        if (voiceSubtitlesEnabled) {
                                            Spacer(modifier = Modifier.height(8.dp))
                                            Text(
                                                text = "Langue source :",
                                                color = Color(0xFF00E5FF),
                                                fontSize = 11.sp,
                                                fontWeight = FontWeight.Bold
                                            )
                                            Spacer(modifier = Modifier.height(4.dp))
                                            val sourceVoiceLangs = listOf(
                                                "auto" to "Auto",
                                                "ar" to "Arabe",
                                                "fr" to "Français",
                                                "en" to "Anglais"
                                            )
                                            Row(
                                                modifier = Modifier.fillMaxWidth(),
                                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                                            ) {
                                                sourceVoiceLangs.forEach { (code, name) ->
                                                    val isLangSel = voiceSubtitleLanguage == code
                                                    Box(
                                                        modifier = Modifier
                                                            .weight(1f)
                                                            .background(
                                                                if (isLangSel) Color(0xFF00E5FF).copy(alpha = 0.25f) else Color(0xFF1E293B),
                                                                RoundedCornerShape(6.dp)
                                                            )
                                                            .border(
                                                                1.dp,
                                                                if (isLangSel) Color(0xFF00E5FF) else Color(0x33FFFFFF),
                                                                RoundedCornerShape(6.dp)
                                                            )
                                                            .clickable { viewModel.setVoiceSubtitleLanguage(code) }
                                                            .padding(vertical = 6.dp),
                                                        contentAlignment = Alignment.Center
                                                    ) {
                                                        Text(
                                                            text = name,
                                                            color = if (isLangSel) Color(0xFF00E5FF) else Color.White,
                                                            fontSize = 11.sp,
                                                            fontWeight = if (isLangSel) FontWeight.Bold else FontWeight.Normal
                                                        )
                                                    }
                                                }
                                            }

                                            if (voiceSpeechDetected) {
                                                Spacer(modifier = Modifier.height(6.dp))
                                                Row(
                                                    verticalAlignment = Alignment.CenterVertically,
                                                    modifier = Modifier
                                                        .fillMaxWidth()
                                                        .background(Color(0x1A10B981), RoundedCornerShape(4.dp))
                                                        .padding(horizontal = 8.dp, vertical = 4.dp)
                                                ) {
                                                    Box(
                                                        modifier = Modifier
                                                            .size(8.dp)
                                                            .background(Color(0xFF10B981), CircleShape)
                                                    )
                                                    Spacer(modifier = Modifier.width(6.dp))
                                                    Text(
                                                        text = "Voix en direct détectée",
                                                        color = Color(0xFF10B981),
                                                        fontSize = 10.sp,
                                                        fontWeight = FontWeight.Medium
                                                    )
                                                }
                                            }

                                            Spacer(modifier = Modifier.height(8.dp))
                                            HorizontalDivider(color = Color(0x22FFFFFF))
                                            Spacer(modifier = Modifier.height(6.dp))

                                            // Synchronisation audio / texte en direct
                                            Row(
                                                modifier = Modifier.fillMaxWidth(),
                                                horizontalArrangement = Arrangement.SpaceBetween,
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                Text(
                                                    text = "Sync Audio / Texte :",
                                                    color = Color(0xFF00E5FF),
                                                    fontSize = 11.sp,
                                                    fontWeight = FontWeight.Bold
                                                )
                                                Text(
                                                    text = if (voiceSubtitleAutoCalibration) "Auto (+${autoCalibratedOffsetMs} ms)" else if (voiceSubtitleSyncOffsetMs == 0) "0 ms (En phase)" else "${if (voiceSubtitleSyncOffsetMs > 0) "+" else ""}${voiceSubtitleSyncOffsetMs} ms",
                                                    color = if (voiceSubtitleAutoCalibration) Color(0xFF10B981) else Color(0xFFF59E0B),
                                                    fontSize = 10.sp,
                                                    fontWeight = FontWeight.Bold
                                                )
                                            }
                                            Spacer(modifier = Modifier.height(4.dp))
                                            Row(
                                                modifier = Modifier.fillMaxWidth(),
                                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                                            ) {
                                                Box(
                                                    modifier = Modifier
                                                        .weight(1f)
                                                        .background(if (voiceSubtitleAutoCalibration) Color(0xFF10B981).copy(alpha = 0.25f) else Color(0xFF1E293B), RoundedCornerShape(4.dp))
                                                        .border(1.dp, if (voiceSubtitleAutoCalibration) Color(0xFF10B981) else Color(0x33FFFFFF), RoundedCornerShape(4.dp))
                                                        .clickable { viewModel.setVoiceSubtitleAutoCalibration(true) }
                                                        .padding(vertical = 5.dp),
                                                    contentAlignment = Alignment.Center
                                                ) {
                                                    Text("✨ Auto", color = if (voiceSubtitleAutoCalibration) Color(0xFF10B981) else Color.White, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                                                }
                                                Box(
                                                    modifier = Modifier
                                                        .weight(1f)
                                                        .background(if (!voiceSubtitleAutoCalibration) Color(0xFF00E5FF).copy(alpha = 0.25f) else Color(0xFF1E293B), RoundedCornerShape(4.dp))
                                                        .border(1.dp, if (!voiceSubtitleAutoCalibration) Color(0xFF00E5FF) else Color(0x33FFFFFF), RoundedCornerShape(4.dp))
                                                        .clickable { viewModel.setVoiceSubtitleAutoCalibration(false) }
                                                        .padding(vertical = 5.dp),
                                                    contentAlignment = Alignment.Center
                                                ) {
                                                    Text("Manuel", color = if (!voiceSubtitleAutoCalibration) Color(0xFF00E5FF) else Color.White, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                                                }
                                            }

                                            if (!voiceSubtitleAutoCalibration) {
                                                Spacer(modifier = Modifier.height(4.dp))
                                                Row(
                                                    modifier = Modifier.fillMaxWidth(),
                                                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                                                ) {
                                                    listOf(
                                                        "-500" to -500,
                                                        "-100" to -100,
                                                        "0 (Calé)" to 0,
                                                        "+100" to 100,
                                                        "+500" to 500
                                                    ).forEach { (label, step) ->
                                                        Box(
                                                            modifier = Modifier
                                                                .weight(1f)
                                                                .background(Color(0xFF1E293B), RoundedCornerShape(4.dp))
                                                                .border(
                                                                    1.dp,
                                                                    if (step == 0 && voiceSubtitleSyncOffsetMs == 0) Color(0xFF10B981) else Color(0x33FFFFFF),
                                                                    RoundedCornerShape(4.dp)
                                                                )
                                                                .clickable {
                                                                    if (step == 0) viewModel.setVoiceSubtitleSyncOffsetMs(0)
                                                                    else viewModel.setVoiceSubtitleSyncOffsetMs(voiceSubtitleSyncOffsetMs + step)
                                                                }
                                                                .padding(vertical = 5.dp),
                                                            contentAlignment = Alignment.Center
                                                        ) {
                                                            Text(
                                                                text = label,
                                                                color = Color.White,
                                                                fontSize = 9.sp,
                                                                fontWeight = FontWeight.SemiBold
                                                            )
                                                        }
                                                    }
                                                }
                                            }

                                            Spacer(modifier = Modifier.height(6.dp))
                                            Row(
                                                modifier = Modifier.fillMaxWidth(),
                                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                                            ) {
                                                Box(
                                                    modifier = Modifier
                                                        .weight(1f)
                                                        .background(
                                                            if (voiceSubtitleStreamingMode) Color(0xFF00E5FF).copy(alpha = 0.25f) else Color(0xFF1E293B),
                                                            RoundedCornerShape(4.dp)
                                                        )
                                                        .border(
                                                            1.dp,
                                                            if (voiceSubtitleStreamingMode) Color(0xFF00E5FF) else Color(0x33FFFFFF),
                                                            RoundedCornerShape(4.dp)
                                                        )
                                                        .clickable { viewModel.setVoiceSubtitleStreamingMode(true) }
                                                        .padding(vertical = 5.dp),
                                                    contentAlignment = Alignment.Center
                                                ) {
                                                    Text(
                                                        text = "⚡ Mot à mot",
                                                        color = if (voiceSubtitleStreamingMode) Color(0xFF00E5FF) else Color.White,
                                                        fontSize = 9.sp,
                                                        fontWeight = if (voiceSubtitleStreamingMode) FontWeight.Bold else FontWeight.Normal
                                                    )
                                                }

                                                Box(
                                                    modifier = Modifier
                                                        .weight(1f)
                                                        .background(
                                                            if (!voiceSubtitleStreamingMode) Color(0xFF00E5FF).copy(alpha = 0.25f) else Color(0xFF1E293B),
                                                            RoundedCornerShape(4.dp)
                                                        )
                                                        .border(
                                                            1.dp,
                                                            if (!voiceSubtitleStreamingMode) Color(0xFF00E5FF) else Color(0x33FFFFFF),
                                                            RoundedCornerShape(4.dp)
                                                        )
                                                        .clickable { viewModel.setVoiceSubtitleStreamingMode(false) }
                                                        .padding(vertical = 5.dp),
                                                    contentAlignment = Alignment.Center
                                                ) {
                                                    Text(
                                                        text = "📄 Phrase complète",
                                                        color = if (!voiceSubtitleStreamingMode) Color(0xFF00E5FF) else Color.White,
                                                        fontSize = 9.sp,
                                                        fontWeight = if (!voiceSubtitleStreamingMode) FontWeight.Bold else FontWeight.Normal
                                                    )
                                                }
                                            }

                                            Spacer(modifier = Modifier.height(6.dp))
                                            Row(
                                                modifier = Modifier.fillMaxWidth(),
                                                horizontalArrangement = Arrangement.SpaceBetween,
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                Text(
                                                    text = "Durée d'affichage :",
                                                    color = Color(0xFF00E5FF),
                                                    fontSize = 11.sp,
                                                    fontWeight = FontWeight.Bold
                                                )
                                                Text(
                                                    text = if (voiceSubtitleAutoDuration) "🧠 Auto (longueur)" else "${voiceSubtitleClearDelaySeconds}s",
                                                    color = if (voiceSubtitleAutoDuration) Color(0xFF10B981) else Color.White,
                                                    fontSize = 10.sp,
                                                    fontWeight = FontWeight.Bold
                                                )
                                            }
                                            Spacer(modifier = Modifier.height(4.dp))
                                            Row(
                                                modifier = Modifier.fillMaxWidth(),
                                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                                            ) {
                                                Box(
                                                    modifier = Modifier
                                                        .weight(1f)
                                                        .background(if (voiceSubtitleAutoDuration) Color(0xFF10B981).copy(alpha = 0.25f) else Color(0xFF1E293B), RoundedCornerShape(4.dp))
                                                        .border(1.dp, if (voiceSubtitleAutoDuration) Color(0xFF10B981) else Color(0x33FFFFFF), RoundedCornerShape(4.dp))
                                                        .clickable { viewModel.setVoiceSubtitleAutoDuration(true) }
                                                        .padding(vertical = 5.dp),
                                                    contentAlignment = Alignment.Center
                                                ) {
                                                    Text("🧠 Auto", color = if (voiceSubtitleAutoDuration) Color(0xFF10B981) else Color.White, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                                                }
                                                listOf(3 to "3s", 5 to "5s", 7 to "7s").forEach { (sec, label) ->
                                                    val isSel = !voiceSubtitleAutoDuration && voiceSubtitleClearDelaySeconds == sec
                                                    Box(
                                                        modifier = Modifier
                                                            .weight(1f)
                                                            .background(if (isSel) Color(0xFF00E5FF).copy(alpha = 0.25f) else Color(0xFF1E293B), RoundedCornerShape(4.dp))
                                                            .border(1.dp, if (isSel) Color(0xFF00E5FF) else Color(0x33FFFFFF), RoundedCornerShape(4.dp))
                                                            .clickable {
                                                                viewModel.setVoiceSubtitleAutoDuration(false)
                                                                viewModel.setVoiceSubtitleClearDelaySeconds(sec)
                                                            }
                                                            .padding(vertical = 5.dp),
                                                        contentAlignment = Alignment.Center
                                                    ) {
                                                        Text(label, color = if (isSel) Color(0xFF00E5FF) else Color.White, fontSize = 9.sp, fontWeight = if (isSel) FontWeight.Bold else FontWeight.Normal)
                                                    }
                                                }
                                            }
                                        }
                                    }
                                } else {
                                    availableSubtitleTracks.forEach { (group, trackIndex) ->
                                        val format = group.getTrackFormat(trackIndex)
                                        val isSelected = group.isTrackSelected(trackIndex) && subtitlesEnabled

                                        val displayName = when {
                                            !format.label.isNullOrBlank() -> format.label!!
                                            !format.language.isNullOrBlank() -> com.example.data.TranslationManager.getLanguageDisplayName(format.language)
                                            else -> "Sous-titre ${trackIndex + 1}"
                                        }

                                        Box(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .padding(vertical = 4.dp)
                                                .background(
                                                    if (isSelected) Color(0x3300E5FF) else Color.Transparent,
                                                    shape = RoundedCornerShape(8.dp)
                                                )
                                                .border(
                                                    width = if (isSelected) 1.5.dp else 1.dp,
                                                    color = if (isSelected) Color(0xFF00E5FF) else Color(0x33FFFFFF),
                                                    shape = RoundedCornerShape(8.dp)
                                                )
                                                .tvFocusable(
                                                    onClick = {
                                                        val current = viewModel.subtitlesEnabled.value
                                                        val isCurrentlySelected = isSelected
                                                        val newEnabled = if (isCurrentlySelected) !current else true
                                                        com.example.debug.GlobalDebugSystem.logFunctionCall("selectSubtitleTrack_LiveTV", "oldEnabled" to current, "newEnabled" to newEnabled, "trackIndex" to trackIndex)
                                                        viewModel.setSubtitlesEnabled(newEnabled)
                                                        if (newEnabled) {
                                                            viewModel.activeSubtitleLanguage = format.language
                                                            sharedPlayer.let { player ->
                                                                player.trackSelectionParameters = player.trackSelectionParameters.buildUpon()
                                                                    .setTrackTypeDisabled(androidx.media3.common.C.TRACK_TYPE_TEXT, false)
                                                                    .clearOverridesOfType(androidx.media3.common.C.TRACK_TYPE_TEXT)
                                                                    .setOverrideForType(androidx.media3.common.TrackSelectionOverride(group.mediaTrackGroup, trackIndex))
                                                                    .build()
                                                            }
                                                        } else {
                                                            sharedPlayer.let { player ->
                                                                player.trackSelectionParameters = player.trackSelectionParameters.buildUpon()
                                                                    .setTrackTypeDisabled(androidx.media3.common.C.TRACK_TYPE_TEXT, true)
                                                                    .clearOverridesOfType(androidx.media3.common.C.TRACK_TYPE_TEXT)
                                                                    .build()
                                                            }
                                                        }
                                                    }
                                                )
                                                .padding(horizontal = 12.dp, vertical = 10.dp)
                                        ) {
                                            Row(
                                                modifier = Modifier.fillMaxWidth(),
                                                horizontalArrangement = Arrangement.SpaceBetween,
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                Text(displayName, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Medium)
                                                if (isSelected) {
                                                    Icon(Icons.Default.Check, contentDescription = "Sélectionné", tint = Color(0xFF00E5FF), modifier = Modifier.size(16.dp))
                                                }
                                            }
                                        }
                                    }
                                    if (!detectedSubtitleLang.isNullOrBlank()) {
                                        Spacer(modifier = Modifier.height(4.dp))
                                        Text(
                                            text = "Langue source détectée : $detectedSubtitleLang",
                                            color = Color(0xFF10B981),
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Medium
                                        )
                                    }
                                }
                            }
                        }

                        // Subtitle Translation Section
                        item {
                            Column(modifier = Modifier.padding(top = 12.dp, bottom = 12.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = "TRADUIRE LES SOUS-TITRES EN :",
                                        color = Color(0xFF00E5FF),
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        letterSpacing = 1.sp
                                    )
                                    Box(
                                        modifier = Modifier
                                            .background(
                                                color = if (subtitleTranslationEnabled) Color(0xFF10B981) else Color(0x33FFFFFF),
                                                shape = RoundedCornerShape(12.dp)
                                            )
                                            .tvFocusable(
                                                onClick = {
                                                    val current = viewModel.subtitleTranslationEnabled.value
                                                    val newVal = !current
                                                    com.example.debug.GlobalDebugSystem.logFunctionCall("toggleTranslation_LiveTV", "old" to current, "new" to newVal)
                                                    if (newVal) {
                                                        viewModel.setSubtitlesEnabled(true)
                                                    }
                                                    viewModel.setSubtitleTranslationEnabled(newVal)
                                                }
                                            )
                                            .padding(horizontal = 10.dp, vertical = 4.dp)
                                    ) {
                                        Text(
                                            text = if (subtitleTranslationEnabled) "ACTIVE" else "DÉSACTIVÉE",
                                            color = Color.White,
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }

                                val isDownloadingModel by com.example.data.TranslationManager.isDownloadingModel.collectAsState()
                                val downloadMessage by com.example.data.TranslationManager.downloadProgressMessage.collectAsState()
                                if (isDownloadingModel || downloadMessage != null) {
                                    Spacer(modifier = Modifier.height(8.dp))
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .background(Color(0x3300E5FF), RoundedCornerShape(8.dp))
                                            .padding(10.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        CircularProgressIndicator(
                                            color = Color(0xFF00E5FF),
                                            modifier = Modifier.size(18.dp),
                                            strokeWidth = 2.dp
                                        )
                                        Spacer(modifier = Modifier.width(10.dp))
                                        Text(
                                            text = downloadMessage ?: "Téléchargement du modèle de traduction...",
                                            color = Color.White,
                                            fontSize = 12.sp,
                                            fontWeight = FontWeight.Medium
                                        )
                                    }
                                }

                                Spacer(modifier = Modifier.height(8.dp))

                                com.example.data.TranslationManager.availableLanguages.forEach { langOption ->
                                    val isSelected = subtitleTargetLanguage == langOption.code && subtitleTranslationEnabled
                                    Box(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(vertical = 4.dp)
                                            .background(
                                                if (isSelected) Color(0x3300E5FF) else Color.Transparent,
                                                shape = RoundedCornerShape(8.dp)
                                            )
                                            .border(
                                                width = if (isSelected) 1.5.dp else 1.dp,
                                                color = if (isSelected) Color(0xFF00E5FF) else Color(0x33FFFFFF),
                                                shape = RoundedCornerShape(8.dp)
                                            )
                                            .tvFocusable(
                                                onClick = {
                                                    val currentTrans = viewModel.subtitleTranslationEnabled.value
                                                    val currentLang = viewModel.subtitleTargetLanguage.value
                                                    val newVal = if (currentTrans && currentLang == langOption.code) false else true
                                                    com.example.debug.GlobalDebugSystem.logFunctionCall("selectTargetLanguage_LiveTV", "language" to langOption.code, "oldTranslation" to currentTrans, "newTranslation" to newVal)
                                                    viewModel.setSubtitleTargetLanguage(langOption.code)
                                                    viewModel.setSubtitleTranslationEnabled(newVal)
                                                    if (newVal) {
                                                        viewModel.setSubtitlesEnabled(true)
                                                    }
                                                }
                                            )
                                            .padding(horizontal = 12.dp, vertical = 10.dp)
                                    ) {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Text(
                                                text = langOption.displayName,
                                                color = Color.White,
                                                fontSize = 13.sp,
                                                fontWeight = FontWeight.Medium
                                            )
                                            if (isSelected) {
                                                Icon(
                                                    Icons.Default.Check,
                                                    contentDescription = "Sélectionné",
                                                    tint = Color(0xFF00E5FF),
                                                    modifier = Modifier.size(16.dp)
                                                )
                                            }
                                        }
                                    }
                                }

                                Spacer(modifier = Modifier.height(10.dp))

                                // OCR Subtitle Recognition
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .background(
                                            color = if (subtitleOcrEnabled) Color(0x3300E5FF) else Color(0x1AFFFFFF),
                                            shape = RoundedCornerShape(8.dp)
                                        )
                                        .border(
                                            width = 1.dp,
                                            color = if (subtitleOcrEnabled) Color(0xFF00E5FF) else Color(0x33FFFFFF),
                                            shape = RoundedCornerShape(8.dp)
                                        )
                                        .tvFocusable(
                                            onClick = {
                                                viewModel.setSubtitleOcrEnabled(!subtitleOcrEnabled)
                                            }
                                        )
                                        .padding(horizontal = 12.dp, vertical = 8.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1f).padding(end = 8.dp)) {
                                        Text("Reconnaissance OCR", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                        Text("Sous-titres DVB & Incrustés", color = Color.Gray, fontSize = 10.sp)
                                    }
                                    Switch(
                                        checked = subtitleOcrEnabled,
                                        onCheckedChange = { viewModel.setSubtitleOcrEnabled(it) },
                                        colors = SwitchDefaults.colors(
                                            checkedThumbColor = Color(0xFF00E5FF),
                                            checkedTrackColor = Color(0xFF00E5FF).copy(alpha = 0.4f)
                                        )
                                    )
                                }
                            }
                        }

                        // Subtitle Style options
                        item {
                            Column {
                                Text("STYLE DES SOUS-TITRES", color = Color(0xFF00E5FF), fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                                Spacer(modifier = Modifier.height(8.dp))

                                // Boîte d'aperçu dynamique instantanée
                                val (previewColor, previewBg, previewShadow) = remember(subtitleStyleMode) {
                                    when {
                                        subtitleStyleMode.contains("vert", ignoreCase = true) || subtitleStyleMode.contains("#00FF66", ignoreCase = true) -> Triple(Color(0xFF00FF66), Color.Black.copy(alpha = 0.65f), true)
                                        subtitleStyleMode.contains("cyan", ignoreCase = true) || subtitleStyleMode.contains("#00E5FF", ignoreCase = true) -> Triple(Color(0xFF00E5FF), Color.Black.copy(alpha = 0.65f), true)
                                        subtitleStyleMode.contains("Bande blanche", ignoreCase = true) || subtitleStyleMode.contains("texte noir", ignoreCase = true) -> Triple(Color.Black, Color.White.copy(alpha = 0.95f), false)
                                        subtitleStyleMode.contains("Bande noire, texte blanc", ignoreCase = true) -> Triple(Color.White, Color.Black.copy(alpha = 0.85f), false)
                                        subtitleStyleMode.contains("Bande noire, texte jaune", ignoreCase = true) -> Triple(Color(0xFFFFE000), Color.Black.copy(alpha = 0.85f), false)
                                        subtitleStyleMode.contains("texte blanc", ignoreCase = true) -> Triple(Color.White, Color.Black.copy(alpha = 0.85f), false)
                                        subtitleStyleMode.contains("Adaptatif", ignoreCase = true) -> Triple(Color.White, Color.Black.copy(alpha = 0.65f), true)
                                        else -> Triple(Color(0xFFFFE000), Color.Black.copy(alpha = 0.65f), true)
                                    }
                                }

                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .background(Color(0xFF0B111E), RoundedCornerShape(8.dp))
                                        .border(1.dp, Color(0xFF1E293B), RoundedCornerShape(8.dp))
                                        .padding(vertical = 14.dp, horizontal = 10.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                        Text(
                                            text = "Aperçu en direct :",
                                            color = Color.Gray,
                                            fontSize = 10.sp,
                                            fontWeight = FontWeight.Medium
                                        )
                                        Spacer(modifier = Modifier.height(6.dp))
                                        Text(
                                            text = "Exemple de sous-titre IPTV",
                                            color = previewColor,
                                            fontSize = subtitleSizeInSp.sp,
                                            fontWeight = FontWeight.Bold,
                                            textAlign = TextAlign.Center,
                                            style = TextStyle(
                                                shadow = if (previewShadow) androidx.compose.ui.graphics.Shadow(
                                                    color = Color.Black,
                                                    offset = androidx.compose.ui.geometry.Offset(2f, 2f),
                                                    blurRadius = 4f
                                                ) else null
                                            ),
                                            modifier = Modifier
                                                .background(previewBg, RoundedCornerShape(6.dp))
                                                .padding(horizontal = 12.dp, vertical = 6.dp)
                                        )
                                    }
                                }

                                Spacer(modifier = Modifier.height(10.dp))
                                val styles = listOf(
                                    "Intelligent / Adaptatif" to "Adaptatif (Contour réactif, Gras)",
                                    "Bande noire, texte blanc" to "Bande noire, texte blanc (Gras)",
                                    "Bande blanche, texte noir" to "Bande blanche, texte noir (Gras)",
                                    "Texte jaune #FFE000, contour noir" to "Texte jaune #FFE000, contour noir (Gras)",
                                    "Bande noire, texte jaune #FFE000" to "Bande noire, texte jaune #FFE000 (Gras)",
                                    "Texte vert #00FF66, contour noir" to "Texte vert #00FF66, contour noir (Gras)",
                                    "Texte cyan #00E5FF, contour noir" to "Texte cyan #00E5FF, contour noir (Gras)"
                                )
                                styles.forEach { (mode, label) ->
                                    val isSelected = subtitleStyleMode == mode
                                    Box(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(vertical = 4.dp)
                                            .background(
                                                if (isSelected) Color(0x3300E5FF) else Color.Transparent,
                                                shape = RoundedCornerShape(8.dp)
                                            )
                                            .border(
                                                width = if (isSelected) 1.5.dp else 1.dp,
                                                color = if (isSelected) Color(0xFF00E5FF) else Color(0x33FFFFFF),
                                                shape = RoundedCornerShape(8.dp)
                                            )
                                            .tvFocusable(
                                                onClick = {
                                                    viewModel.setSubtitleStyleMode(mode)
                                                }
                                            )
                                            .padding(horizontal = 12.dp, vertical = 10.dp)
                                    ) {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Text(label, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Medium)
                                            if (isSelected) {
                                                Icon(Icons.Default.Check, contentDescription = "Sélectionné", tint = Color(0xFF00E5FF), modifier = Modifier.size(16.dp))
                                            }
                                        }
                                    }
                                }
                            }
                        }

                        // Subtitle Size options
                        item {
                            Column {
                                Text("TAILLE DES SOUS-TITRES", color = Color(0xFF00E5FF), fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                                Spacer(modifier = Modifier.height(8.dp))
                                val sizes = listOf("Petit", "Moyen", "Grand", "Très Grand")
                                sizes.forEach { sz ->
                                    val isSelected = subtitleSizeState == sz
                                    Box(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(vertical = 4.dp)
                                            .background(
                                                if (isSelected) Color(0x3300E5FF) else Color.Transparent,
                                                shape = RoundedCornerShape(8.dp)
                                            )
                                            .border(
                                                width = if (isSelected) 1.5.dp else 1.dp,
                                                color = if (isSelected) Color(0xFF00E5FF) else Color(0x33FFFFFF),
                                                shape = RoundedCornerShape(8.dp)
                                            )
                                            .tvFocusable(
                                                onClick = {
                                                    viewModel.setSubtitleSizeState(sz)
                                                }
                                            )
                                            .padding(horizontal = 12.dp, vertical = 10.dp)
                                    ) {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Text(sz, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Medium)
                                            if (isSelected) {
                                                Icon(Icons.Default.Check, contentDescription = "Sélectionné", tint = Color(0xFF00E5FF), modifier = Modifier.size(16.dp))
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun FullScreenVideoPlayer(
    channel: ChannelItem,
    viewModel: IptvViewModel,
    onClose: () -> Unit
) {
    val context = LocalContext.current
    val focusRequester = remember { FocusRequester() }
    var showOsd by remember { mutableStateOf(true) }
    var showSidebar by remember { mutableStateOf(false) }
    var showPlayerSettingsMenu by remember { mutableStateOf(false) }
    var showSubtitleSettingsBottomSheet by remember { mutableStateOf(false) }
    var showCatchupDialogForChannel by remember { mutableStateOf<ChannelItem?>(null) }
    
    // Cycle state: 0 = initial, 1 = sidebar open, 2 = sidebar closed/hidden after being open
    var clickCycleState by remember { mutableStateOf(0) }
    
    val handleOkOrTap: () -> Unit = {
        if (showCatchupDialogForChannel != null) {
            showCatchupDialogForChannel = null
        } else if (showPlayerSettingsMenu) {
            showPlayerSettingsMenu = false
        } else {
            when (clickCycleState) {
                0 -> {
                    showSidebar = true
                    showOsd = true
                    clickCycleState = 1
                }
                1 -> {
                    showSidebar = false
                    showOsd = false
                    clickCycleState = 2
                }
                2 -> {
                    onClose()
                }
            }
        }
    }

    LaunchedEffect(showSidebar) {
        if (showSidebar) {
            clickCycleState = 1
        } else {
            if (clickCycleState == 1) {
                clickCycleState = 2
            }
        }
    }

    val resizeModeState by viewModel.resizeModeState.collectAsState()
    val activeAudioFormat by viewModel.activeAudioFormat.collectAsState()
    val activeVideoQuality by viewModel.activeVideoQuality.collectAsState()
    val playbackSpeedState by viewModel.playbackSpeedState.collectAsState()
    
    val playerPrefs = remember { context.getSharedPreferences("iptv_player_prefs", android.content.Context.MODE_PRIVATE) }
    val subtitlesEnabled by viewModel.subtitlesEnabled.collectAsState()
    val subtitleStyleMode by viewModel.subtitleStyleMode.collectAsState()
    val subtitleSizeState by viewModel.subtitleSizeState.collectAsState()
    
    val captionStyle = remember(subtitleStyleMode) {
        when {
            subtitleStyleMode.contains("Bande blanche", ignoreCase = true) || subtitleStyleMode.contains("texte noir", ignoreCase = true) -> androidx.media3.ui.CaptionStyleCompat(
                android.graphics.Color.BLACK,
                android.graphics.Color.WHITE,
                android.graphics.Color.TRANSPARENT,
                androidx.media3.ui.CaptionStyleCompat.EDGE_TYPE_NONE,
                android.graphics.Color.WHITE,
                com.example.ui.SubtitleFonts.bold
            )
            subtitleStyleMode.contains("Bande noire, texte blanc", ignoreCase = true) -> androidx.media3.ui.CaptionStyleCompat(
                android.graphics.Color.WHITE,
                android.graphics.Color.BLACK,
                android.graphics.Color.TRANSPARENT,
                androidx.media3.ui.CaptionStyleCompat.EDGE_TYPE_NONE,
                android.graphics.Color.BLACK,
                com.example.ui.SubtitleFonts.bold
            )
            subtitleStyleMode.contains("Bande noire", ignoreCase = true) -> androidx.media3.ui.CaptionStyleCompat(
                android.graphics.Color.parseColor("#FFE000"),
                android.graphics.Color.BLACK,
                android.graphics.Color.TRANSPARENT,
                androidx.media3.ui.CaptionStyleCompat.EDGE_TYPE_NONE,
                android.graphics.Color.BLACK,
                com.example.ui.SubtitleFonts.bold
            )
            subtitleStyleMode.contains("texte blanc", ignoreCase = true) -> androidx.media3.ui.CaptionStyleCompat(
                android.graphics.Color.WHITE,
                android.graphics.Color.TRANSPARENT,
                android.graphics.Color.TRANSPARENT,
                androidx.media3.ui.CaptionStyleCompat.EDGE_TYPE_OUTLINE,
                android.graphics.Color.BLACK,
                com.example.ui.SubtitleFonts.bold
            )
            subtitleStyleMode.contains("Adaptatif", ignoreCase = true) -> androidx.media3.ui.CaptionStyleCompat(
                android.graphics.Color.WHITE,
                android.graphics.Color.TRANSPARENT,
                android.graphics.Color.TRANSPARENT,
                androidx.media3.ui.CaptionStyleCompat.EDGE_TYPE_OUTLINE,
                android.graphics.Color.BLACK,
                com.example.ui.SubtitleFonts.bold
            )
            subtitleStyleMode.contains("vert", ignoreCase = true) || subtitleStyleMode.contains("#00FF66", ignoreCase = true) -> androidx.media3.ui.CaptionStyleCompat(
                android.graphics.Color.parseColor("#00FF66"),
                android.graphics.Color.TRANSPARENT,
                android.graphics.Color.TRANSPARENT,
                androidx.media3.ui.CaptionStyleCompat.EDGE_TYPE_OUTLINE,
                android.graphics.Color.BLACK,
                com.example.ui.SubtitleFonts.bold
            )
            subtitleStyleMode.contains("cyan", ignoreCase = true) || subtitleStyleMode.contains("#00E5FF", ignoreCase = true) -> androidx.media3.ui.CaptionStyleCompat(
                android.graphics.Color.parseColor("#00E5FF"),
                android.graphics.Color.TRANSPARENT,
                android.graphics.Color.TRANSPARENT,
                androidx.media3.ui.CaptionStyleCompat.EDGE_TYPE_OUTLINE,
                android.graphics.Color.BLACK,
                com.example.ui.SubtitleFonts.bold
            )
            else -> androidx.media3.ui.CaptionStyleCompat(
                android.graphics.Color.parseColor("#FFE000"),
                android.graphics.Color.TRANSPARENT,
                android.graphics.Color.TRANSPARENT,
                androidx.media3.ui.CaptionStyleCompat.EDGE_TYPE_OUTLINE,
                android.graphics.Color.BLACK,
                com.example.ui.SubtitleFonts.bold
            )
        }
    }

    val subtitleSizeInSp = remember(subtitleSizeState) {
        when (subtitleSizeState) {
            "Petit" -> 16f
            "Moyen" -> 22f
            "Grand" -> 28f
            "Très Grand" -> 36f
            else -> 22f
        }
    }

    val brightnessLevel by viewModel.brightnessLevel.collectAsState()
    val zoomLevel by viewModel.zoomLevel.collectAsState()
    val imageEnhancementMode by viewModel.imageEnhancementMode.collectAsState()
    var hudMessage by remember { mutableStateOf<String?>(null) }
    var hudJob by remember { mutableStateOf<kotlinx.coroutines.Job?>(null) }
    
    var isBufferingState by remember { mutableStateOf(false) }
    var consecutiveBufferingSeconds by remember { mutableStateOf(0) }
    
    var availableAudioTracks by remember { mutableStateOf<List<Pair<androidx.media3.common.Tracks.Group, Int>>>(emptyList()) }
    var availableSubtitleTracks by remember { mutableStateOf<List<Pair<androidx.media3.common.Tracks.Group, Int>>>(emptyList()) }
    
    var digitBuffer by remember { mutableStateOf("") }
    val coroutineScope = rememberCoroutineScope()
    var bufferJob by remember { mutableStateOf<kotlinx.coroutines.Job?>(null) }
    
    val showHud = remember(coroutineScope) {
        { message: String ->
            hudJob?.cancel()
            hudMessage = message
            hudJob = coroutineScope.launch {
                delay(2000)
                hudMessage = null
            }
        }
    }
    
    val sidebarLazyListState = rememberLazyListState()
    val channels by viewModel.channels.collectAsState()
    val seriesEpisodes by viewModel.seriesEpisodes.collectAsState()
    val watchProgressList by viewModel.watchProgressList.collectAsState()

    BackHandler(enabled = showSubtitleSettingsBottomSheet || showPlayerSettingsMenu || showSidebar || showOsd || showCatchupDialogForChannel != null) {
        if (showCatchupDialogForChannel != null) {
            showCatchupDialogForChannel = null
        } else if (showSubtitleSettingsBottomSheet) {
            showSubtitleSettingsBottomSheet = false
        } else if (showPlayerSettingsMenu) {
            showPlayerSettingsMenu = false
        } else if (showSidebar) {
            showSidebar = false
        } else if (showOsd) {
            showOsd = false
        }
    }

    val sidebarItems = remember(channels, channel, seriesEpisodes) {
        if (channel.type == "Series") {
            val seriesName = channel.name.substringBefore(" - ").ifEmpty { channel.name }
            seriesEpisodes.map { ep ->
                val epTitle = if (ep.name.startsWith(seriesName, ignoreCase = true)) {
                    ep.name
                } else {
                    val seasonKey = normalizeSeasonKey(ep.season)
                    "$seriesName - $seasonKey - ${ep.name}"
                }
                ChannelItem(
                    playlistId = channel.playlistId,
                    name = epTitle,
                    streamUrl = ep.url,
                    logoUrl = channel.logoUrl,
                    groupName = channel.groupName,
                    type = "Series",
                    stalkerId = channel.stalkerId
                )
            }
        } else {
            channels.filter { it.type == channel.type }
        }
    }

    val activeIndex = remember(sidebarItems, channel) {
        sidebarItems.indexOfFirst { it.streamUrl == channel.streamUrl }
    }

    var sidebarCursorIndex by remember(showSidebar) {
        mutableIntStateOf(if (activeIndex >= 0) activeIndex else 0)
    }

    val sidebarFocusRequesters = remember(sidebarItems) { mutableMapOf<Int, FocusRequester>() }
    val sidebarCatchupRequesters = remember(sidebarItems) { mutableMapOf<Int, FocusRequester>() }

    LaunchedEffect(showSidebar, activeIndex) {
        if (showSidebar) {
            val indexToFocus = if (activeIndex >= 0) activeIndex else 0
            sidebarCursorIndex = indexToFocus
            if (indexToFocus >= 0 && indexToFocus < sidebarItems.size) {
                sidebarLazyListState.scrollToItem(indexToFocus)
                delay(150) // allow binding and rendering of the list item
                sidebarFocusRequesters[indexToFocus]?.requestFocus()
            }
        } else {
            delay(50)
            try {
                focusRequester.requestFocus()
            } catch (e: Exception) {
                // Ignore focus request failure if player state changed
            }
        }
    }
    val isCurrentFavorite by viewModel.isCurrentChannelFavorite.collectAsState()
    val isRecording by viewModel.isRecording.collectAsState()
    val recordingDuration by viewModel.recordingDurationSeconds.collectAsState()
    val recordingChannel by viewModel.recordingChannel.collectAsState()

    val playbackUrl by viewModel.playbackUrl.collectAsState()
    val playbackHeaders by viewModel.playbackHeaders.collectAsState()
    val playbackLoading by viewModel.playbackLoading.collectAsState()
    val playbackErrorState by viewModel.playbackError.collectAsState()
    val isTimeshiftActive by viewModel.isTimeshiftActive.collectAsState()
    val currentTimeshiftProgram by viewModel.currentTimeshiftProgram.collectAsState()

    val recInfiniteTransition = androidx.compose.animation.core.rememberInfiniteTransition(label = "rec_blink")
    val recBlinkAlpha by recInfiniteTransition.animateFloat(
        initialValue = 1f,
        targetValue = 0.2f,
        animationSpec = androidx.compose.animation.core.infiniteRepeatable(
            animation = androidx.compose.animation.core.tween(500, easing = androidx.compose.animation.core.LinearEasing),
            repeatMode = androidx.compose.animation.core.RepeatMode.Reverse
        ),
        label = "alpha"
    )
    val epgProgramsList by viewModel.epgProgramsList.collectAsState()
    val catchupEpg by viewModel.catchupEpg.collectAsState()
    var reloadTrigger by remember(playbackUrl) { mutableStateOf(0) }

    val useExternalPlayer by viewModel.useExternalPlayer.collectAsState()

    val currentCalendar = remember(channel) { java.util.Calendar.getInstance() }
    val currentHour = currentCalendar.get(java.util.Calendar.HOUR_OF_DAY)
    val currentMinute = currentCalendar.get(java.util.Calendar.MINUTE)

    val activeChannelEpg = remember(channel, epgProgramsList, catchupEpg) {
        val programs = if (epgProgramsList.isNotEmpty()) {
            epgProgramsList.map { item ->
                EpgProgram(
                    title = item.name,
                    startTime = item.startTimeFormatted,
                    endTime = item.stopTimeFormatted,
                    description = item.description,
                    startHour = 0,
                    endHour = 0,
                    startTimestamp = item.startTimestamp,
                    endTimestamp = item.stopTimestamp,
                    realId = item.realId,
                    id = item.id,
                    markArchive = item.markArchive
                )
            }
        } else if (catchupEpg.isNotEmpty()) {
            catchupEpg
        } else {
            getAutomaticEpgForChannel(channel.name)
        }
        val nowMs = System.currentTimeMillis()
        val currentProg = programs.find { nowMs in (it.startTimestamp)..(it.endTimestamp - 1L) } ?: programs.find { currentHour >= it.startHour && currentHour < it.endHour } ?: programs.last()
        val nextProg = programs.find { it.startTimestamp >= currentProg.endTimestamp } ?: programs.find { it.startHour == (currentProg.endHour % 24) } ?: programs.first()
        val totalMs = if (currentProg.startTimestamp > 0L) currentProg.endTimestamp - currentProg.startTimestamp else (currentProg.endHour - currentProg.startHour) * 3600000L
        val elapsedMs = if (currentProg.startTimestamp > 0L) nowMs - currentProg.startTimestamp else ((currentHour - currentProg.startHour) * 60 + currentMinute) * 60000L
        val progress = if (totalMs > 0) (elapsedMs.toFloat() / totalMs.toFloat()).coerceIn(0f, 1f) else 0f
        Triple(currentProg, nextProg, progress)
    }

    if (useExternalPlayer) {
        LaunchedEffect(playbackUrl) {
            if (!playbackUrl.isNullOrBlank()) {
                val intent = Intent(Intent.ACTION_VIEW).apply {
                    setDataAndType(Uri.parse(playbackUrl), "video/*")
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    if (playbackHeaders.isNotEmpty()) {
                        val headersBundle = android.os.Bundle()
                        for ((key, value) in playbackHeaders) {
                            headersBundle.putString(key, value)
                        }
                        putExtra("android.media.intent.extra.HTTP_HEADERS", headersBundle)
                        putExtra("headers", playbackHeaders.map { "${it.key}: ${it.value}" }.toTypedArray())
                    }
                }
                try {
                    context.startActivity(intent)
                } catch (e: Exception) {
                    Toast.makeText(context, "Impossible de lancer le lecteur externe: ${e.localizedMessage}", Toast.LENGTH_LONG).show()
                }
                onClose()
            }
        }

        // LaunchedEffect moved below after playerError declaration

        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.Black),
            contentAlignment = Alignment.Center
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                CircularProgressIndicator(
                    color = Color(0xFFFFFF00),
                    strokeWidth = 4.dp
                )
                Spacer(modifier = Modifier.height(16.dp))
                Text(
                    text = "Lancement du lecteur externe...",
                    color = Color.White,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = channel.name,
                    color = Color.Gray,
                    fontSize = 14.sp
                )
            }
        }
        return
    }

    // Use the single shared ExoPlayer instance from the ViewModel
    val exoPlayer = remember(viewModel) { viewModel.getSharedPlayer() }

    val subtitleTranslationEnabled by viewModel.subtitleTranslationEnabled.collectAsState()
    val subtitleOcrEnabled by viewModel.subtitleOcrEnabled.collectAsState()
    val subtitleTargetLanguage by viewModel.subtitleTargetLanguage.collectAsState()
    val translatedSubtitleText by viewModel.translatedSubtitleText.collectAsState()
    val externalTranslatedSubtitle by viewModel.externalTranslatedSubtitle.collectAsState()
    val currentSubtitleText by viewModel.currentSubtitleText.collectAsState()
    val voiceSubtitlesEnabled by viewModel.voiceSubtitlesEnabled.collectAsState()
    val voiceSubtitleLanguage by viewModel.voiceSubtitleLanguage.collectAsState()
    val voiceSpeechDetected by viewModel.voiceSpeechDetected.collectAsState()
    val isVoiceModelDownloading by viewModel.isVoiceModelDownloading.collectAsState()
    val voiceModelDownloadMessage by viewModel.voiceModelDownloadMessage.collectAsState()

    LaunchedEffect(playbackSpeedState, exoPlayer) {
        exoPlayer?.setPlaybackSpeed(playbackSpeedState)
    }

    var playerError by remember { mutableStateOf<String?>(null) }
    
    LaunchedEffect(playbackErrorState, isTimeshiftActive) {
        val err = playbackErrorState
        if (!err.isNullOrBlank() && !err.contains("cancel", ignoreCase = true) && !err.contains("coroutine", ignoreCase = true)) {
            Log.e("IptvPlayer", "Player error state: $err")
            playerError = err
        }
    }
    
    var currentPosition by remember { mutableStateOf(0L) }
    var videoDuration by remember { mutableStateOf(0L) }
    var isSeeking by remember { mutableStateOf(false) }
    var isPlayingState by remember { mutableStateOf(true) }

    val isVODorSeekable = videoDuration > 0 || channel.type == "Series" || channel.type == "Movie" || isTimeshiftActive || (exoPlayer?.isCurrentMediaItemSeekable == true)
    val effectiveDuration = remember(videoDuration, watchProgressList, channel) {
        if (videoDuration > 0L) {
            videoDuration
        } else {
            val wpMatch = watchProgressList.find { wp ->
                wp.episodeId == channel.streamUrl ||
                (channel.type == "Series" && (wp.title.endsWith(channel.name) || wp.title.contains(channel.name))) ||
                (channel.type == "Movie" && wp.title.equals(channel.name, ignoreCase = true))
            }
            wpMatch?.durationMs ?: 0L
        }
    }

    val formatPlaybackTime = remember {
        { ms: Long ->
            if (ms <= 0) {
                "00:00"
            } else {
                val totalSeconds = ms / 1000
                val seconds = totalSeconds % 60
                val minutes = (totalSeconds / 60) % 60
                val hours = totalSeconds / 3600
                if (hours > 0) {
                    String.format("%02d:%02d:%02d", hours, minutes, seconds)
                } else {
                    String.format("%02d:%02d", minutes, seconds)
                }
            }
        }
    }

    LaunchedEffect(exoPlayer) {
        while (true) {
            exoPlayer?.let { player ->
                if (!isSeeking) {
                    currentPosition = player.currentPosition
                    videoDuration = player.duration.coerceAtLeast(0L)
                }
                isPlayingState = player.isPlaying
            }
            delay(500)
        }
    }

    DisposableEffect(exoPlayer) {
        val stateListener = object : androidx.media3.common.Player.Listener {
            override fun onEvents(player: androidx.media3.common.Player, events: androidx.media3.common.Player.Events) {
                if (events.contains(androidx.media3.common.Player.EVENT_PLAY_WHEN_READY_CHANGED) ||
                    events.contains(androidx.media3.common.Player.EVENT_PLAYBACK_STATE_CHANGED) ||
                    events.contains(androidx.media3.common.Player.EVENT_IS_PLAYING_CHANGED)
                ) {
                    isPlayingState = player.isPlaying
                    if (!isSeeking) {
                        currentPosition = player.currentPosition
                        videoDuration = player.duration.coerceAtLeast(0L)
                    }
                    isBufferingState = player.playbackState == androidx.media3.common.Player.STATE_BUFFERING
                    if (isTimeshiftActive && player.playbackState == androidx.media3.common.Player.STATE_ENDED) {
                        Log.d("CatchupDebug", "STATE_ENDED pendant le catchup. Position: ${player.currentPosition}ms, Durée totale: ${player.duration}ms, URL: $playbackUrl")
                        if (player.currentPosition < 15000L) {
                            Log.w("CatchupDebug", "STATE_ENDED au début du replay. Auto re-préparation du lecteur...")
                            coroutineScope.launch {
                                delay(1000)
                                player.prepare()
                                player.play()
                            }
                        } else {
                            Log.d("CatchupDebug", "Fin du replay atteinte, retour au direct...")
                            showHud("Fin du replay — Retour au direct")
                            coroutineScope.launch {
                                delay(1200)
                                viewModel.stopTimeshift()
                            }
                        }
                    }
                }
                if (events.contains(androidx.media3.common.Player.EVENT_TRACKS_CHANGED)) {
                    val tracks = player.currentTracks
                    val audios = mutableListOf<Pair<androidx.media3.common.Tracks.Group, Int>>()
                    val subs = mutableListOf<Pair<androidx.media3.common.Tracks.Group, Int>>()
                    for (group in tracks.groups) {
                        if (group.type == androidx.media3.common.C.TRACK_TYPE_AUDIO) {
                            for (i in 0 until group.length) {
                                if (group.isTrackSupported(i)) {
                                    audios.add(Pair(group, i))
                                }
                            }
                        } else if (group.type == androidx.media3.common.C.TRACK_TYPE_TEXT) {
                            for (i in 0 until group.length) {
                                subs.add(Pair(group, i))
                            }
                        }
                    }
                    availableAudioTracks = audios
                    availableSubtitleTracks = subs

                    if (subtitlesEnabled || subtitleTranslationEnabled) {
                        val hasSelectedSubTrack = subs.any { (group, idx) -> group.isTrackSelected(idx) }
                        if (!hasSelectedSubTrack && subs.isNotEmpty()) {
                            val (firstGroup, firstIdx) = subs.first()
                            player.trackSelectionParameters = player.trackSelectionParameters.buildUpon()
                                .setTrackTypeDisabled(androidx.media3.common.C.TRACK_TYPE_TEXT, false)
                                .clearOverridesOfType(androidx.media3.common.C.TRACK_TYPE_TEXT)
                                .setOverrideForType(androidx.media3.common.TrackSelectionOverride(firstGroup.mediaTrackGroup, firstIdx))
                                .build()
                        }
                    } else {
                        player.trackSelectionParameters = player.trackSelectionParameters.buildUpon()
                            .setTrackTypeDisabled(androidx.media3.common.C.TRACK_TYPE_TEXT, true)
                            .clearOverridesOfType(androidx.media3.common.C.TRACK_TYPE_TEXT)
                            .build()
                    }
                }
            }
        }
        exoPlayer?.addListener(stateListener)
        onDispose {
            exoPlayer?.removeListener(stateListener)
        }
    }

    // Robust playback watchdog to automatically recover and reload the stream in case of network freezes, frozen frames, or endless buffering
    LaunchedEffect(exoPlayer, playbackUrl) {
        var lastPosition = -1L
        var stuckSeconds = 0
        var bufferingSeconds = 0
        var autoReloadCount = 0

        while (true) {
            delay(1000)
            exoPlayer?.let { player ->
                if (player.playWhenReady) {
                    val state = player.playbackState
                    if (state == androidx.media3.common.Player.STATE_READY) {
                        val currentPos = player.currentPosition
                        if (currentPos == lastPosition && !isSeeking && currentPos > 0) {
                            stuckSeconds++
                            if (stuckSeconds >= 6) { // 6 consecutive seconds of frozen position (fast recovery)
                                stuckSeconds = 0
                                if (autoReloadCount < 6) { // Up to 5 auto reloads
                                    autoReloadCount++
                                    Log.d("IptvPlayer", "Position stuck at $currentPos. Triggering automatic stream reload ($autoReloadCount/5)...")
                                    reloadTrigger++
                                } else {
                                    Log.d("IptvPlayer", "Position stuck, but max auto-reloads reached. Resetting count to try again.")
                                    autoReloadCount = 0 // Continue trying after limit to ensure "sans rupture"
                                }
                            }
                        } else {
                            stuckSeconds = 0
                        }
                        lastPosition = currentPos
                    } else {
                        stuckSeconds = 0
                    }

                    if (state == androidx.media3.common.Player.STATE_BUFFERING) {
                        bufferingSeconds++
                        if (bufferingSeconds >= 10) { // 10 consecutive seconds of buffering (fast recovery)
                            bufferingSeconds = 0
                            if (autoReloadCount < 6) {
                                autoReloadCount++
                                Log.d("IptvPlayer", "Buffering for too long. Triggering automatic stream reload ($autoReloadCount/5)...")
                                reloadTrigger++
                            } else {
                                Log.d("IptvPlayer", "Endless buffering, resetting count to keep trying.")
                                autoReloadCount = 0 // Keep trying
                            }
                        }
                    } else {
                        bufferingSeconds = 0
                    }
                } else {
                    stuckSeconds = 0
                    bufferingSeconds = 0
                }
            }
        }
    }

    LaunchedEffect(exoPlayer, showPlayerSettingsMenu) {
        exoPlayer?.let { player ->
            val tracks = player.currentTracks
            val audios = mutableListOf<Pair<androidx.media3.common.Tracks.Group, Int>>()
            val subs = mutableListOf<Pair<androidx.media3.common.Tracks.Group, Int>>()
            for (group in tracks.groups) {
                if (group.type == androidx.media3.common.C.TRACK_TYPE_AUDIO) {
                    for (i in 0 until group.length) {
                        if (group.isTrackSupported(i)) {
                            audios.add(Pair(group, i))
                        }
                    }
                } else if (group.type == androidx.media3.common.C.TRACK_TYPE_TEXT) {
                    for (i in 0 until group.length) {
                        subs.add(Pair(group, i))
                    }
                }
            }
            availableAudioTracks = audios
            availableSubtitleTracks = subs
            if (!subtitlesEnabled && !subtitleTranslationEnabled) {
                player.trackSelectionParameters = player.trackSelectionParameters.buildUpon()
                    .setTrackTypeDisabled(androidx.media3.common.C.TRACK_TYPE_TEXT, true)
                    .build()
            }
        }
    }

    LaunchedEffect(subtitlesEnabled, subtitleTranslationEnabled, exoPlayer, availableSubtitleTracks) {
        exoPlayer?.let { player ->
            val enableText = subtitlesEnabled || subtitleTranslationEnabled
            player.trackSelectionParameters = player.trackSelectionParameters.buildUpon()
                .setTrackTypeDisabled(androidx.media3.common.C.TRACK_TYPE_TEXT, !enableText)
                .apply {
                    if (!enableText) {
                        clearOverridesOfType(androidx.media3.common.C.TRACK_TYPE_TEXT)
                    } else if (availableSubtitleTracks.isNotEmpty()) {
                        val hasSelected = availableSubtitleTracks.any { (g, idx) -> g.isTrackSelected(idx) }
                        if (!hasSelected) {
                            val (firstGroup, firstIdx) = availableSubtitleTracks.first()
                            setOverrideForType(androidx.media3.common.TrackSelectionOverride(firstGroup.mediaTrackGroup, firstIdx))
                        }
                    }
                }
                .build()
        }
    }
    


    LaunchedEffect(playbackErrorState) {
        val err = playbackErrorState
        if (!err.isNullOrBlank() && !err.contains("cancel", ignoreCase = true) && !err.contains("coroutine", ignoreCase = true)) {
            playerError = err
        }
    }

    // Keep player playing when exiting full screen (do not release shared player)
    DisposableEffect(exoPlayer) {
        onDispose {
            // Keep shared player active
        }
    }

    var retryMimeType by remember(playbackUrl) { mutableStateOf<String?>(null) }
    var retryCount by remember(playbackUrl) { mutableStateOf(0) }
    var errorRetryCount by remember(playbackUrl) { mutableStateOf(0) }

    // Single error listener attached to the player with auto-retry on format failures
    DisposableEffect(exoPlayer, playbackUrl, retryMimeType) {
        val listener = object : androidx.media3.common.Player.Listener {
            override fun onPlayerError(error: androidx.media3.common.PlaybackException) {
                val urlToPlay = playbackUrl
                Log.e("IptvPlayer", "Playback error: ${error.message} (code: ${error.errorCode})", error)
                if (isTimeshiftActive) {
                    Log.d("CatchupDebug", "Playback error during catchup (Code: ${error.errorCode}, Msg: ${error.message}). Attempting recovery...")
                }

                // BehindLiveWindow automatic instant recovery
                if (error.errorCode == androidx.media3.common.PlaybackException.ERROR_CODE_BEHIND_LIVE_WINDOW) {
                    Log.d("IptvPlayer", "Behind live window error detected. Seeking to live edge...")
                    exoPlayer?.apply {
                        seekToDefaultPosition()
                        prepare()
                        play()
                    }
                    return
                }
                
                val isNetworkError = error.errorCode == androidx.media3.common.PlaybackException.ERROR_CODE_IO_NETWORK_CONNECTION_FAILED ||
                        error.errorCode == androidx.media3.common.PlaybackException.ERROR_CODE_IO_BAD_HTTP_STATUS ||
                        error.errorCode == androidx.media3.common.PlaybackException.ERROR_CODE_IO_UNSPECIFIED
                        
                if (isNetworkError && errorRetryCount < 6 && !urlToPlay.isNullOrBlank()) {
                    errorRetryCount++
                    val retryDelay = 1200L // Fast retry delay (1.2 seconds)
                    Log.d("IptvPlayer", "Network or HTTP error. Auto-retrying in $retryDelay ms (Attempt $errorRetryCount/5)...")
                    coroutineScope.launch {
                        delay(retryDelay)
                        if (errorRetryCount >= 3) {
                            // After 3 failed network attempts, force reload the media item entirely to re-handshake and reconnect
                            try {
                                viewModel.playOnSharedPlayer(urlToPlay, playbackHeaders, false)
                            } catch (e: Exception) {
                                exoPlayer?.apply {
                                    prepare()
                                    play()
                                }
                            }
                        } else {
                            exoPlayer?.apply {
                                prepare()
                                play()
                            }
                        }
                    }
                    return
                }
                
                val isFormatError = error.errorCode == androidx.media3.common.PlaybackException.ERROR_CODE_PARSING_CONTAINER_UNSUPPORTED ||
                        error.errorCode == androidx.media3.common.PlaybackException.ERROR_CODE_PARSING_CONTAINER_MALFORMED ||
                        error.errorCode == androidx.media3.common.PlaybackException.ERROR_CODE_DECODING_FAILED ||
                        error.errorCode == androidx.media3.common.PlaybackException.ERROR_CODE_IO_UNSPECIFIED
                        
                if (isFormatError && retryCount < 3 && !urlToPlay.isNullOrBlank()) {
                    retryCount++
                    if (retryCount == 1) {
                        Log.d("IptvPlayer", "Format error: Retrying with container auto-sniffing (AUTO)...")
                        retryMimeType = "AUTO"
                    } else if (retryCount == 2) {
                        Log.d("IptvPlayer", "Format error: Retrying with HLS mime type...")
                        retryMimeType = androidx.media3.common.MimeTypes.APPLICATION_M3U8
                    } else if (retryCount == 3) {
                        Log.d("IptvPlayer", "Format error: Retrying with MPEG-TS mime type...")
                        retryMimeType = "video/mp2t"
                    }
                    return
                }
                
                playerError = when (error.errorCode) {
                    androidx.media3.common.PlaybackException.ERROR_CODE_IO_NETWORK_CONNECTION_FAILED -> 
                        "Erreur de connexion réseau (Internet hors-ligne)"
                    androidx.media3.common.PlaybackException.ERROR_CODE_IO_BAD_HTTP_STATUS -> 
                        "Erreur de flux HTTP (Code de retour invalide ou flux indisponible)"
                    androidx.media3.common.PlaybackException.ERROR_CODE_DECODER_INIT_FAILED -> 
                        "Échec de l'initialisation du décodeur vidéo"
                    else -> error.localizedMessage ?: "Impossible d'ouvrir ce flux vidéo"
                }
            }

            override fun onTracksChanged(tracks: androidx.media3.common.Tracks) {
                val audioGroups = tracks.groups.filter { it.type == androidx.media3.common.C.TRACK_TYPE_AUDIO }
                if (audioGroups.isNotEmpty()) {
                    val hasSelectedAudio = audioGroups.any { group ->
                        (0 until group.length).any { idx -> group.isTrackSelected(idx) && group.isTrackSupported(idx) }
                    }
                    if (!hasSelectedAudio) {
                        for (group in audioGroups) {
                            for (i in 0 until group.length) {
                                if (group.isTrackSupported(i)) {
                                    Log.d("IptvPlayer", "Auto-selecting supported audio track for live stream")
                                    exoPlayer?.trackSelectionParameters = exoPlayer.trackSelectionParameters.buildUpon()
                                        .setTrackTypeDisabled(androidx.media3.common.C.TRACK_TYPE_AUDIO, false)
                                        .clearOverridesOfType(androidx.media3.common.C.TRACK_TYPE_AUDIO)
                                        .setOverrideForType(androidx.media3.common.TrackSelectionOverride(group.mediaTrackGroup, i))
                                        .build()
                                    break
                                }
                            }
                        }
                    }
                }
            }
        }
        exoPlayer?.addListener(listener)
        onDispose {
            exoPlayer?.removeListener(listener)
        }
    }

    // Dynamically update media item whenever the stream URL, retry MIME type, or reload trigger changes - Super Fast Zapping & Auto-Recovery!
    LaunchedEffect(playbackUrl, playbackHeaders, exoPlayer, retryMimeType, reloadTrigger) {
        playerError = null
        if (!playbackUrl.isNullOrBlank()) {
            try {
                val mime = if (retryMimeType != null) {
                    if (retryMimeType == "AUTO") null else retryMimeType
                } else {
                    if (playbackUrl!!.contains(".m3u8", ignoreCase = true) || playbackUrl!!.contains("type=m3u8", ignoreCase = true)) {
                        androidx.media3.common.MimeTypes.APPLICATION_M3U8
                    } else if (playbackUrl!!.contains(".mpd", ignoreCase = true)) {
                        androidx.media3.common.MimeTypes.APPLICATION_MPD
                    } else if (playbackUrl!!.contains(".ism", ignoreCase = true)) {
                        androidx.media3.common.MimeTypes.APPLICATION_SS
                    } else if (playbackUrl!!.contains(".mp4", ignoreCase = true) || playbackUrl!!.contains("format=mp4", ignoreCase = true)) {
                        androidx.media3.common.MimeTypes.VIDEO_MP4
                    } else if (playbackUrl!!.contains(".mkv", ignoreCase = true) || playbackUrl!!.contains("format=mkv", ignoreCase = true)) {
                        androidx.media3.common.MimeTypes.VIDEO_MATROSKA
                    } else if (playbackUrl!!.contains(".avi", ignoreCase = true) || playbackUrl!!.contains("format=avi", ignoreCase = true)) {
                        androidx.media3.common.MimeTypes.VIDEO_AVI
                    } else if (playbackUrl!!.contains(".flv", ignoreCase = true) || playbackUrl!!.contains("format=flv", ignoreCase = true)) {
                        androidx.media3.common.MimeTypes.VIDEO_FLV
                    } else if (playbackUrl!!.contains(".ts", ignoreCase = true) || playbackUrl!!.contains("output=ts", ignoreCase = true) || playbackUrl!!.contains("format=ts", ignoreCase = true) || playbackUrl!!.startsWith("content://") || playbackUrl!!.startsWith("file://") || playbackUrl!!.contains("IPTV_REC")) {
                        "video/mp2t"
                    } else {
                        null
                    }
                }
                
                val headersWithMime = if (mime != null) {
                    playbackHeaders + ("mime" to mime)
                } else {
                    playbackHeaders
                }
                
                viewModel.playOnSharedPlayer(playbackUrl!!, headersWithMime, isMuted = false)
            } catch (e: Exception) {
                Log.e("IptvPlayer", "Error preparing source: ${e.message}", e)
                playerError = e.localizedMessage
            }
        } else {
            if (playbackErrorState != null) {
                playerError = playbackErrorState
            } else if (!playbackLoading) {
                playerError = null
            }
        }
    }

    LaunchedEffect(Unit) {
        focusRequester.requestFocus()
    }

    // OSD timer
    LaunchedEffect(showOsd, isPlayingState, isSeeking) {
        if (showOsd && isPlayingState && !isSeeking) {
            delay(5000)
            showOsd = false
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black)
            .focusRequester(focusRequester)
            .focusable()
            .onKeyEvent { keyEvent ->
                if (keyEvent.type == KeyEventType.KeyDown) {
                    val nativeCode = keyEvent.nativeKeyEvent.keyCode
                    when {
                        (keyEvent.key == Key.Zero || keyEvent.key == Key.One || keyEvent.key == Key.Two || 
                         keyEvent.key == Key.Three || keyEvent.key == Key.Four || keyEvent.key == Key.Five || 
                         keyEvent.key == Key.Six || keyEvent.key == Key.Seven || keyEvent.key == Key.Eight || 
                         keyEvent.key == Key.Nine || (nativeCode in 7..16)) -> {
                            val digit = when {
                                keyEvent.key == Key.Zero || nativeCode == 7 -> "0"
                                keyEvent.key == Key.One || nativeCode == 8 -> "1"
                                keyEvent.key == Key.Two || nativeCode == 9 -> "2"
                                keyEvent.key == Key.Three || nativeCode == 10 -> "3"
                                keyEvent.key == Key.Four || nativeCode == 11 -> "4"
                                keyEvent.key == Key.Five || nativeCode == 12 -> "5"
                                keyEvent.key == Key.Six || nativeCode == 13 -> "6"
                                keyEvent.key == Key.Seven || nativeCode == 14 -> "7"
                                keyEvent.key == Key.Eight || nativeCode == 15 -> "8"
                                keyEvent.key == Key.Nine || nativeCode == 16 -> "9"
                                else -> null
                            }
                            if (digit != null) {
                                bufferJob?.cancel()
                                digitBuffer += digit
                                showOsd = true
                                bufferJob = coroutineScope.launch {
                                    delay(1500)
                                    val targetIndex = digitBuffer.toIntOrNull()
                                    if (targetIndex != null && targetIndex > 0 && targetIndex <= sidebarItems.size) {
                                        val targetChannel = sidebarItems[targetIndex - 1]
                                        viewModel.selectChannel(targetChannel, keepFullScreen = true)
                                    }
                                    digitBuffer = ""
                                }
                                true
                            } else {
                                false
                            }
                        }
                        nativeCode == 166 || nativeCode == 92 -> { // KEYCODE_CHANNEL_UP, KEYCODE_PAGE_UP
                            if (showSidebar) {
                                if (sidebarItems.isNotEmpty()) {
                                    val prevIdx = if (sidebarCursorIndex > 0) sidebarCursorIndex - 1 else sidebarItems.size - 1
                                    sidebarCursorIndex = prevIdx
                                    coroutineScope.launch {
                                        sidebarLazyListState.animateScrollToItem(prevIdx)
                                        delay(40)
                                        sidebarFocusRequesters[prevIdx]?.requestFocus()
                                    }
                                }
                                true
                            } else {
                                viewModel.selectNextChannel()
                                showOsd = true
                                true
                            }
                        }
                        keyEvent.key == Key.DirectionUp || nativeCode == 19 -> {
                            if (showSidebar) {
                                if (sidebarItems.isNotEmpty()) {
                                    val prevIdx = if (sidebarCursorIndex > 0) sidebarCursorIndex - 1 else sidebarItems.size - 1
                                    sidebarCursorIndex = prevIdx
                                    coroutineScope.launch {
                                        sidebarLazyListState.animateScrollToItem(prevIdx)
                                        delay(40)
                                        sidebarFocusRequesters[prevIdx]?.requestFocus()
                                    }
                                }
                                true
                            } else {
                                viewModel.selectNextChannel()
                                showOsd = true
                                true
                            }
                        }
                        nativeCode == 167 || nativeCode == 93 -> { // KEYCODE_CHANNEL_DOWN, KEYCODE_PAGE_DOWN
                            if (showSidebar) {
                                if (sidebarItems.isNotEmpty()) {
                                    val nextIdx = if (sidebarCursorIndex < sidebarItems.size - 1) sidebarCursorIndex + 1 else 0
                                    sidebarCursorIndex = nextIdx
                                    coroutineScope.launch {
                                        sidebarLazyListState.animateScrollToItem(nextIdx)
                                        delay(40)
                                        sidebarFocusRequesters[nextIdx]?.requestFocus()
                                    }
                                }
                                true
                            } else {
                                viewModel.selectPreviousChannel()
                                showOsd = true
                                true
                            }
                        }
                        keyEvent.key == Key.DirectionDown || nativeCode == 20 -> {
                            if (showSidebar) {
                                if (sidebarItems.isNotEmpty()) {
                                    val nextIdx = if (sidebarCursorIndex < sidebarItems.size - 1) sidebarCursorIndex + 1 else 0
                                    sidebarCursorIndex = nextIdx
                                    coroutineScope.launch {
                                        sidebarLazyListState.animateScrollToItem(nextIdx)
                                        delay(40)
                                        sidebarFocusRequesters[nextIdx]?.requestFocus()
                                    }
                                }
                                true
                            } else {
                                viewModel.selectPreviousChannel()
                                showOsd = true
                                true
                            }
                        }
                        keyEvent.key == Key.DirectionLeft -> {
                            if (isVODorSeekable) {
                                val newPos = (currentPosition - 10000L).coerceAtLeast(0L)
                                exoPlayer?.seekTo(newPos)
                                currentPosition = newPos
                                showOsd = true
                                showHud("⏪ -10s (${formatPlaybackTime(newPos)})")
                                true
                            } else {
                                // Open lateral channel list sidebar only if OSD and sidebar are both closed
                                if (!showSidebar && !showOsd) {
                                    showSidebar = true
                                    showOsd = false
                                    true
                                } else {
                                    false
                                }
                            }
                        }
                        keyEvent.key == Key.DirectionRight || nativeCode == 22 -> {
                            if (showSidebar) {
                                false
                            } else if (showPlayerSettingsMenu) {
                                false
                            } else if (isVODorSeekable) {
                                val maxPos = if (effectiveDuration > 0L) effectiveDuration else Long.MAX_VALUE
                                val newPos = (currentPosition + 10000L).coerceAtMost(maxPos)
                                exoPlayer?.seekTo(newPos)
                                currentPosition = newPos
                                showOsd = true
                                showHud("⏩ +10s (${formatPlaybackTime(newPos)})")
                                true
                            } else {
                                showCatchupDialogForChannel = channel
                                showOsd = false
                                true
                            }
                        }
                        nativeCode == 89 || nativeCode == 273 || nativeCode == 275 -> { // REWIND (-30s/-60s)
                            if (isVODorSeekable) {
                                val jump = if (nativeCode == 273) 60000L else 30000L
                                val newPos = (currentPosition - jump).coerceAtLeast(0L)
                                exoPlayer?.seekTo(newPos)
                                currentPosition = newPos
                                showOsd = true
                                showHud("⏪ -${jump / 1000}s (${formatPlaybackTime(newPos)})")
                                true
                            } else false
                        }
                        nativeCode == 90 || nativeCode == 272 || nativeCode == 274 -> { // FAST FORWARD (+30s/+60s)
                            if (isVODorSeekable) {
                                val jump = if (nativeCode == 272) 60000L else 30000L
                                val maxPos = if (effectiveDuration > 0L) effectiveDuration else Long.MAX_VALUE
                                val newPos = (currentPosition + jump).coerceAtMost(maxPos)
                                exoPlayer?.seekTo(newPos)
                                currentPosition = newPos
                                showOsd = true
                                showHud("⏩ +${jump / 1000}s (${formatPlaybackTime(newPos)})")
                                true
                            } else false
                        }
                        keyEvent.key == Key.DirectionCenter || keyEvent.key == Key.Enter || keyEvent.key == Key.NumPadEnter ||
                        nativeCode == 23 || nativeCode == 66 || nativeCode == 160 || nativeCode == 313 || nativeCode == 85 || nativeCode == 126 -> {
                            if (showSidebar) {
                                if (sidebarItems.isNotEmpty() && sidebarCursorIndex in sidebarItems.indices) {
                                    val target = sidebarItems[sidebarCursorIndex]
                                    val chProgress = watchProgressList.find { wp ->
                                        wp.episodeId == target.streamUrl ||
                                        (target.type == "Series" && (wp.title.endsWith(target.name) || wp.title.contains(target.name))) ||
                                        (target.type == "Movie" && wp.title.equals(target.name, ignoreCase = true))
                                    }
                                    val startPos = if (chProgress != null && chProgress.positionMs > 5000L) chProgress.positionMs else 0L
                                    viewModel.selectChannel(
                                        target,
                                        keepFullScreen = true,
                                        skipResumeCheck = false,
                                        startPositionMs = startPos
                                    )
                                }
                                true
                            } else {
                                handleOkOrTap()
                                true
                            }
                        }
                        keyEvent.key == Key.Back -> {
                            if (showCatchupDialogForChannel != null) {
                                showCatchupDialogForChannel = null
                                true
                            } else if (showPlayerSettingsMenu) {
                                showPlayerSettingsMenu = false
                                true
                            } else if (showSidebar) {
                                showSidebar = false
                                true
                            } else if (showOsd) {
                                showOsd = false
                                true
                            } else {
                                onClose()
                                true
                            }
                        }
                        else -> false
                    }
                } else {
                    false
                }
            }
            .combinedClickable(
                onClick = {
                    handleOkOrTap()
                }
            )
    ) {
        Column(
            modifier = Modifier
                .align(Alignment.TopEnd)
                .padding(24.dp)
                .zIndex(20f),
            horizontalAlignment = Alignment.End,
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            if (digitBuffer.isNotEmpty()) {
                Box(
                    modifier = Modifier
                        .background(Color.Black.copy(alpha = 0.85f), shape = RoundedCornerShape(8.dp))
                        .border(2.dp, Color(0xFF00E5FF), shape = RoundedCornerShape(8.dp))
                        .padding(horizontal = 24.dp, vertical = 12.dp)
                ) {
                    Text(
                        text = digitBuffer,
                        color = Color(0xFF00E5FF),
                        fontSize = 32.sp,
                        fontWeight = FontWeight.ExtraBold,
                        fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace
                    )
                }
            }

            if (isRecording) {
                val formattedTime = String.format("%02d:%02d", recordingDuration / 60, recordingDuration % 60)
                Surface(
                    onClick = { viewModel.stopRecording() },
                    shape = RoundedCornerShape(24.dp),
                    color = Color(0xFFDC2626),
                    shadowElevation = 8.dp,
                    modifier = Modifier
                        .alpha(recBlinkAlpha)
                        .tvFocusable(
                            focusedColor = Color(0xFFEF4444),
                            borderRadius = 24.dp,
                            onClick = { viewModel.stopRecording() }
                        )
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(10.dp)
                                .background(Color.White, shape = CircleShape)
                        )
                        Text(
                            text = "REC $formattedTime",
                            color = Color.White,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Box(
                            modifier = Modifier
                                .size(22.dp)
                                .background(Color.White.copy(alpha = 0.3f), shape = CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Stop,
                                contentDescription = "Arrêter l'enregistrement",
                                tint = Color.White,
                                modifier = Modifier.size(14.dp)
                            )
                        }
                    }
                }
            }
        }

        if (playerError != null) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color(0xFF0B0E14)),
                contentAlignment = Alignment.Center
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center,
                    modifier = Modifier.padding(32.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Warning,
                        contentDescription = "Playback Error",
                        tint = Color(0xFFEF4444),
                        modifier = Modifier.size(64.dp)
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    Text(
                        text = if (isTimeshiftActive) "Programme indisponible en replay" else "Impossible d'ouvrir cette chaîne",
                        color = Color.White,
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold,
                        textAlign = TextAlign.Center
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = playerError ?: "Le flux n'est pas disponible actuellement.",
                        color = Color(0xFF9CA3AF),
                        fontSize = 14.sp,
                        textAlign = TextAlign.Center
                    )
                    Spacer(modifier = Modifier.height(24.dp))
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        Button(
                            onClick = {
                                playerError = null
                                onClose()
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF374151))
                        ) {
                            Text("Fermer", color = Color.White)
                        }
                        if (isTimeshiftActive) {
                            Button(
                                onClick = {
                                    playerError = null
                                    viewModel.stopTimeshift()
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF3B82F6))
                            ) {
                                Text("Revenir au direct", color = Color.White)
                            }
                            Button(
                                onClick = {
                                    val ch = channel
                                    val prog = currentTimeshiftProgram
                                    if (ch != null && prog != null) {
                                        playerError = null
                                        viewModel.playCatchupProgram(
                                            channel = ch,
                                            program = EpgProgramItem(
                                                name = prog.title,
                                                description = prog.description,
                                                startTimestamp = prog.startTimestamp,
                                                stopTimestamp = prog.endTimestamp,
                                                startTimeFormatted = prog.startTime,
                                                stopTimeFormatted = prog.endTime,
                                                realId = prog.realId,
                                                id = prog.id,
                                                markArchive = 1
                                            )
                                        )
                                    }
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF10B981))
                            ) {
                                Text("Réessayer", color = Color.White)
                            }
                        } else {
                            Button(
                                onClick = { viewModel.selectNextChannel() },
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF10B981))
                            ) {
                                Text("Chaîne Suivante", color = Color.White)
                            }
                        }
                    }
                }
            }
        } else if (exoPlayer == null) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color.Black),
                contentAlignment = Alignment.Center
            ) {
                CircularProgressIndicator(
                    modifier = Modifier.size(48.dp),
                    color = MaterialTheme.colorScheme.primary
                )
            }
        } else {
            AndroidView(
                factory = { ctx ->
                    PlayerView(ctx).apply {
                        useController = false
                        layoutParams = FrameLayout.LayoutParams(
                            FrameLayout.LayoutParams.MATCH_PARENT,
                            FrameLayout.LayoutParams.MATCH_PARENT
                        )
                        subtitleView?.apply {
                            visibility = if (subtitlesEnabled && !subtitleTranslationEnabled) android.view.View.VISIBLE else android.view.View.GONE
                            setViewType(androidx.media3.ui.SubtitleView.VIEW_TYPE_CANVAS)
                            setStyle(captionStyle)
                            setFixedTextSize(android.util.TypedValue.COMPLEX_UNIT_SP, subtitleSizeInSp)
                        }
                    }
                },
                update = { playerView ->
                    if (playerView.player != exoPlayer) {
                        playerView.player = exoPlayer
                    }
                    playerView.resizeMode = resizeModeState
                    Log.d("SubtitleDebug", "COMPOSABLE=FullScreenVideoPlayer | subtitlesEnabled=$subtitlesEnabled | translationEnabled=$subtitleTranslationEnabled | targetLang=$subtitleTargetLanguage | styleMode=$subtitleStyleMode")
                    playerView.subtitleView?.let { subView ->
                        if (subtitleTranslationEnabled || voiceSubtitlesEnabled) {
                            subView.setCues(emptyList())
                            subView.visibility = android.view.View.GONE
                        } else if (subtitlesEnabled) {
                            val hasCustomComposeSubs = !currentSubtitleText.isNullOrBlank()
                            if (hasCustomComposeSubs) {
                                subView.setCues(emptyList())
                                subView.visibility = android.view.View.GONE
                            } else {
                                subView.visibility = android.view.View.VISIBLE
                                subView.setStyle(captionStyle)
                                subView.setFixedTextSize(android.util.TypedValue.COMPLEX_UNIT_SP, subtitleSizeInSp)
                                subView.requestLayout()
                                subView.invalidate()
                            }
                        } else {
                            subView.setCues(emptyList())
                            subView.visibility = android.view.View.GONE
                        }
                    } ?: run {
                        Log.d("SubtitleDebug", "COMPOSABLE=FullScreenVideoPlayer | playerView.subtitleView is null")
                    }
                },
                onRelease = { playerView ->
                    playerView.player = null
                },
                modifier = Modifier
                    .fillMaxSize()
                    .graphicsLayer(scaleX = zoomLevel, scaleY = zoomLevel)
            )
        }

        // Brightness Overlay (above video, below OSD/controls)
        if (brightnessLevel < 1.0f) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color.Black.copy(alpha = (1.0f - brightnessLevel).coerceIn(0f, 0.9f)))
            )
        } else if (brightnessLevel > 1.0f) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color.White.copy(alpha = ((brightnessLevel - 1.0f) * 0.35f).coerceIn(0f, 0.35f)))
            )
        }

        // Image Enhancement Overlay (above video, below OSD/controls)
        if (imageEnhancementMode != "Désactivé") {
            val (overlayColor, blendMode) = when (imageEnhancementMode) {
                "Cinéma" -> Color(0xFFFFA000).copy(alpha = 0.08f) to BlendMode.Color
                "Sport" -> Color(0xFF00FF66).copy(alpha = 0.05f) to BlendMode.Overlay
                "Doux" -> Color(0xFFFFD54F).copy(alpha = 0.12f) to BlendMode.Modulate
                "Éclatant" -> Color(0xFF00E5FF).copy(alpha = 0.06f) to BlendMode.Overlay
                else -> Color.Transparent to BlendMode.SrcOver
            }
            if (overlayColor != Color.Transparent) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .drawBehind {
                            drawRect(color = overlayColor, blendMode = blendMode)
                        }
                )
            }
        }

        // Custom Subtitles Overlay (Compose) - Supports translation, CEA-608/WebVTT, OCR & Voice STT with full styling
        val effectiveTranslatedText = if (!translatedSubtitleText.isNullOrBlank()) translatedSubtitleText else externalTranslatedSubtitle
        val displaySubtitleText = if (subtitlesEnabled || subtitleTranslationEnabled || voiceSubtitlesEnabled) {
            if (subtitleTranslationEnabled) {
                if (!effectiveTranslatedText.isNullOrBlank()) {
                    effectiveTranslatedText
                } else {
                    currentSubtitleText
                }
            } else if (!currentSubtitleText.isNullOrBlank()) {
                currentSubtitleText
            } else {
                null
            }
        } else {
            null
        }

        val pureSubtitleText = remember(displaySubtitleText) {
            if (displaySubtitleText.isNullOrBlank()) ""
            else cleanSubtitleOnlyText(displaySubtitleText)
        }

        com.example.ui.VoiceDiagnosticsOverlay(enabled = voiceSubtitlesEnabled)
if (pureSubtitleText.isNotBlank()) {
            val (translatedTextColor, translatedBgColor, translatedHasShadow) = remember(subtitleStyleMode) {
                when {
                    subtitleStyleMode.contains("vert", ignoreCase = true) || subtitleStyleMode.contains("#00FF66", ignoreCase = true) -> Triple(
                        Color(0xFF00FF66),
                        Color.Black.copy(alpha = 0.65f),
                        true
                    )
                    subtitleStyleMode.contains("cyan", ignoreCase = true) || subtitleStyleMode.contains("#00E5FF", ignoreCase = true) -> Triple(
                        Color(0xFF00E5FF),
                        Color.Black.copy(alpha = 0.65f),
                        true
                    )
                    subtitleStyleMode.contains("Bande blanche", ignoreCase = true) || subtitleStyleMode.contains("texte noir", ignoreCase = true) -> Triple(
                        Color.Black,
                        Color.White.copy(alpha = 0.95f),
                        false
                    )
                    subtitleStyleMode.contains("Bande noire, texte blanc", ignoreCase = true) -> Triple(
                        Color.White,
                        Color.Black.copy(alpha = 0.85f),
                        false
                    )
                    subtitleStyleMode.contains("Bande noire, texte jaune", ignoreCase = true) -> Triple(
                        Color(0xFFFFE000),
                        Color.Black.copy(alpha = 0.85f),
                        false
                    )
                    subtitleStyleMode.contains("texte blanc", ignoreCase = true) -> Triple(
                        Color.White,
                        Color.Black.copy(alpha = 0.85f),
                        false
                    )
                    subtitleStyleMode.contains("Adaptatif", ignoreCase = true) -> Triple(
                        Color.White,
                        Color.Black.copy(alpha = 0.65f),
                        true
                    )
                    else -> Triple(
                        Color(0xFFFFE000), // Yellow #FFE000
                        Color.Black.copy(alpha = 0.65f),
                        true
                    )
                }
            }

            val isArabicFullscreenSubtitle = remember(pureSubtitleText) {
                pureSubtitleText.any { it in '\u0600'..'\u06FF' || it in '\u0750'..'\u077F' || it in '\u08A0'..'\u08FF' || it in '\uFB50'..'\uFDFF' || it in '\uFE70'..'\uFEFF' }
            }

            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(bottom = 36.dp, start = 32.dp, end = 32.dp),
                contentAlignment = Alignment.BottomCenter
            ) {
                CompositionLocalProvider(
                    LocalLayoutDirection provides (if (isArabicFullscreenSubtitle) LayoutDirection.Rtl else LayoutDirection.Ltr)
                ) {
                    Text(
                        text = pureSubtitleText,
                        fontFamily = com.example.ui.SubtitleFontFamily,
                        color = translatedTextColor,
                        fontSize = subtitleSizeInSp.sp,
                        lineHeight = (subtitleSizeInSp * 1.35f).sp,
                        fontWeight = FontWeight.Bold,
                        textAlign = TextAlign.Center,
                        style = TextStyle(
                            shadow = if (translatedHasShadow) androidx.compose.ui.graphics.Shadow(
                                color = Color.Black,
                                offset = androidx.compose.ui.geometry.Offset(2f, 2f),
                                blurRadius = 4f
                            ) else null
                        ),
                        modifier = Modifier
                            .background(
                                translatedBgColor,
                                shape = RoundedCornerShape(8.dp)
                            )
                            .padding(horizontal = 18.dp, vertical = 10.dp)
                    )
                }
            }
        }

        if (voiceSubtitlesEnabled && isVoiceModelDownloading) {
            Box(
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .padding(top = 24.dp, end = 24.dp)
                    .background(Color(0xFF0F172A).copy(alpha = 0.9f), shape = RoundedCornerShape(10.dp))
                    .border(1.dp, Color(0xFF00E5FF).copy(alpha = 0.6f), shape = RoundedCornerShape(10.dp))
                    .padding(horizontal = 14.dp, vertical = 8.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(16.dp),
                        color = Color(0xFF00E5FF),
                        strokeWidth = 2.dp
                    )
                    Text(
                        text = voiceModelDownloadMessage ?: "Modèle vocal IA en préparation...",
                        color = Color.White,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Medium
                    )
                }
            }
        }

        // HUD Overlay for Brightness / Aspect Ratio changes
        AnimatedVisibility(
            visible = hudMessage != null,
            enter = fadeIn() + scaleIn(initialScale = 0.8f),
            exit = fadeOut() + scaleOut(targetScale = 0.8f),
            modifier = Modifier
                .align(Alignment.CenterEnd)
                .padding(end = 48.dp)
        ) {
            hudMessage?.let { msg ->
                Box(
                    modifier = Modifier
                        .background(Color.Black.copy(alpha = 0.85f), shape = RoundedCornerShape(16.dp))
                        .border(1.5.dp, Color(0xFF00E5FF), shape = RoundedCornerShape(16.dp))
                        .padding(horizontal = 24.dp, vertical = 12.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        val isFormat = msg.contains("Format")
                        Icon(
                            imageVector = if (isFormat) Icons.Default.AspectRatio else Icons.Default.Brightness6,
                            contentDescription = null,
                            tint = Color(0xFF00E5FF),
                            modifier = Modifier.size(24.dp)
                        )
                        Text(
                            text = msg,
                            color = Color.White,
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }



        // Custom On-Screen Display (OSD) Overlay
        if (showOsd) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color.Black.copy(alpha = 0.4f))
                    .padding(24.dp)
            ) {
                // Top controls row
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .align(Alignment.TopCenter),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconButton(
                            onClick = onClose,
                            modifier = Modifier
                                .background(Color.Black.copy(alpha = 0.6f), shape = RoundedCornerShape(8.dp))
                                .tvFocusable(onClick = onClose)
                        ) {
                            Icon(Icons.Default.ArrowBack, contentDescription = "Close", tint = Color.White)
                        }

                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                        Button(
                            onClick = { showSidebar = true },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E2430)),
                            modifier = Modifier.tvFocusable(onClick = { showSidebar = true })
                        ) {
                            Icon(Icons.Default.Menu, contentDescription = "Playlist", tint = Color.White, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Playlist Latérale", color = Color.White, fontSize = 12.sp)
                        }

                        Button(
                            onClick = { showSubtitleSettingsBottomSheet = true },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E293B)),
                            border = BorderStroke(1.dp, Color(0xFF00E5FF).copy(alpha = 0.6f)),
                            modifier = Modifier.tvFocusable(onClick = { showSubtitleSettingsBottomSheet = true })
                        ) {
                            Icon(
                                imageVector = Icons.Default.Subtitles,
                                contentDescription = "Sous-titres & Vocal TV",
                                tint = Color(0xFF00E5FF),
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("💬 Sous-titres & Vocal TV", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }

                        IconButton(
                            onClick = { viewModel.toggleFavorite(channel) },
                            modifier = Modifier
                                .background(Color.Black.copy(alpha = 0.6f), shape = RoundedCornerShape(8.dp))
                                .tvFocusable(onClick = { viewModel.toggleFavorite(channel) })
                        ) {
                            Icon(
                                imageVector = if (isCurrentFavorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                                contentDescription = "Favorite",
                                tint = if (isCurrentFavorite) Color(0xFFEF4444) else Color.White
                            )
                        }

                        IconButton(
                            onClick = { showPlayerSettingsMenu = true },
                            modifier = Modifier
                                .background(Color.Black.copy(alpha = 0.6f), shape = RoundedCornerShape(8.dp))
                                .tvFocusable(onClick = { showPlayerSettingsMenu = true })
                        ) {
                            Icon(
                                imageVector = Icons.Default.MoreVert,
                                contentDescription = "Paramètres",
                                tint = Color.White
                            )
                        }
                    }
                }





                // Receiver-style Bottom Info Banner
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF0B0E14).copy(alpha = 0.85f)),
                    border = BorderStroke(1.dp, Color(0xFF1E2430)),
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .fillMaxWidth()
                        .padding(bottom = 8.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp)
                    ) {
                        // 'Live' vs 'Archive' Mode Indicator (if channel supports catchup)
                        if (channel.hasCatchup) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(bottom = 12.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    // Mode Badge
                                    Box(
                                        modifier = Modifier
                                            .background(
                                                color = if (isTimeshiftActive) Color(0xFFF59E0B) else Color(0xFF10B981),
                                                shape = RoundedCornerShape(4.dp)
                                            )
                                            .padding(horizontal = 8.dp, vertical = 4.dp)
                                    ) {
                                        Text(
                                            text = if (isTimeshiftActive) "MODE ARCHIVE" else "MODE EN DIRECT",
                                            color = Color.White,
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                    
                                    Text(
                                        text = if (isTimeshiftActive) "Lecture d'un enregistrement différé" else "Diffusion en temps réel",
                                        color = Color.LightGray,
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Medium
                                    )
                                }
                                
                                // Quick action button
                                androidx.compose.material3.TextButton(
                                    onClick = {
                                        if (isTimeshiftActive) {
                                            viewModel.stopTimeshift()
                                        } else {
                                            showCatchupDialogForChannel = channel
                                        }
                                    },
                                    colors = androidx.compose.material3.ButtonDefaults.textButtonColors(
                                        contentColor = if (isTimeshiftActive) Color(0xFF10B981) else CeylanColor
                                    ),
                                    modifier = Modifier.tvFocusable(
                                        onClick = {
                                            if (isTimeshiftActive) {
                                                viewModel.stopTimeshift()
                                            } else {
                                                showCatchupDialogForChannel = channel
                                            }
                                        }
                                    )
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(
                                            imageVector = if (isTimeshiftActive) Icons.Default.PlayArrow else Icons.Default.History,
                                            contentDescription = null,
                                            modifier = Modifier.size(16.dp)
                                        )
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text(
                                            text = if (isTimeshiftActive) "REVENIR AU DIRECT" else "VOIR LES ARCHIVES (EPG)",
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }
                            }
                        }

                        // Progress Slider / Seekbar if seekable video
                        if (isVODorSeekable) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(bottom = 8.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                // Bouton Recommencer au début
                                Surface(
                                    onClick = {
                                        exoPlayer?.seekTo(0L)
                                        currentPosition = 0L
                                        showHud("⏪ Recommencer au début (00:00)")
                                    },
                                    modifier = Modifier
                                        .height(34.dp)
                                        .tvFocusable(
                                            focusedColor = Color(0xFF00E5FF),
                                            borderRadius = 17.dp,
                                            onClick = {
                                                exoPlayer?.seekTo(0L)
                                                currentPosition = 0L
                                                showHud("⏪ Recommencer au début (00:00)")
                                            }
                                        ),
                                    shape = RoundedCornerShape(17.dp),
                                    color = Color.Black.copy(alpha = 0.5f),
                                    border = BorderStroke(1.dp, Color(0xFF00E5FF).copy(alpha = 0.6f))
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        modifier = Modifier.padding(horizontal = 10.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Refresh,
                                            contentDescription = "Recommencer au début",
                                            tint = Color(0xFF00E5FF),
                                            modifier = Modifier.size(16.dp)
                                        )
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("Début", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                    }
                                }

                                // Reculer 30s
                                IconButton(
                                    onClick = {
                                        val newPos = (currentPosition - 30000L).coerceAtLeast(0L)
                                        exoPlayer?.seekTo(newPos)
                                        currentPosition = newPos
                                        showHud("⏪ -30s (${formatPlaybackTime(newPos)})")
                                    },
                                    modifier = Modifier
                                        .size(34.dp)
                                        .background(Color.Black.copy(alpha = 0.4f), shape = CircleShape)
                                        .tvFocusable(onClick = {
                                            val newPos = (currentPosition - 30000L).coerceAtLeast(0L)
                                            exoPlayer?.seekTo(newPos)
                                            currentPosition = newPos
                                            showHud("⏪ -30s (${formatPlaybackTime(newPos)})")
                                        })
                                ) {
                                    Text("-30s", color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                }

                                // Reculer 10s
                                IconButton(
                                    onClick = {
                                        val newPos = (currentPosition - 10000L).coerceAtLeast(0L)
                                        exoPlayer?.seekTo(newPos)
                                        currentPosition = newPos
                                        showHud("⏪ -10s (${formatPlaybackTime(newPos)})")
                                    },
                                    modifier = Modifier
                                        .size(34.dp)
                                        .background(Color.Black.copy(alpha = 0.4f), shape = CircleShape)
                                        .tvFocusable(onClick = {
                                            val newPos = (currentPosition - 10000L).coerceAtLeast(0L)
                                            exoPlayer?.seekTo(newPos)
                                            currentPosition = newPos
                                            showHud("⏪ -10s (${formatPlaybackTime(newPos)})")
                                        })
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.FastRewind,
                                        contentDescription = "Reculer 10s",
                                        tint = Color.White,
                                        modifier = Modifier.size(18.dp)
                                    )
                                }

                                Text(
                                    text = formatPlaybackTime(currentPosition),
                                    color = Color.White,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold
                                )

                                val sliderMax = if (effectiveDuration > 0L) effectiveDuration.toFloat() else (currentPosition.coerceAtLeast(60000L) * 1.5f)
                                Slider(
                                    value = currentPosition.toFloat().coerceIn(0f, sliderMax),
                                    onValueChange = { newValue ->
                                        isSeeking = true
                                        currentPosition = newValue.toLong()
                                    },
                                    onValueChangeFinished = {
                                        exoPlayer?.seekTo(currentPosition)
                                        isSeeking = false
                                        showHud("Position: ${formatPlaybackTime(currentPosition)}")
                                    },
                                    valueRange = 0f..sliderMax,
                                    colors = SliderDefaults.colors(
                                        activeTrackColor = Color(0xFF10B981),
                                        inactiveTrackColor = Color.Gray.copy(alpha = 0.5f),
                                        thumbColor = Color(0xFF10B981)
                                    ),
                                    modifier = Modifier.weight(1f)
                                )

                                Text(
                                    text = if (effectiveDuration > 0L) formatPlaybackTime(effectiveDuration) else "--:--",
                                    color = Color.LightGray,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Medium
                                )

                                // Avancer 10s
                                IconButton(
                                    onClick = {
                                        val maxPos = if (effectiveDuration > 0L) effectiveDuration else Long.MAX_VALUE
                                        val newPos = (currentPosition + 10000L).coerceAtMost(maxPos)
                                        exoPlayer?.seekTo(newPos)
                                        currentPosition = newPos
                                        showHud("⏩ +10s (${formatPlaybackTime(newPos)})")
                                    },
                                    modifier = Modifier
                                        .size(34.dp)
                                        .background(Color.Black.copy(alpha = 0.4f), shape = CircleShape)
                                        .tvFocusable(onClick = {
                                            val maxPos = if (effectiveDuration > 0L) effectiveDuration else Long.MAX_VALUE
                                            val newPos = (currentPosition + 10000L).coerceAtMost(maxPos)
                                            exoPlayer?.seekTo(newPos)
                                            currentPosition = newPos
                                            showHud("⏩ +10s (${formatPlaybackTime(newPos)})")
                                        })
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.FastForward,
                                        contentDescription = "Avancer 10s",
                                        tint = Color.White,
                                        modifier = Modifier.size(18.dp)
                                    )
                                }

                                // Avancer 30s
                                IconButton(
                                    onClick = {
                                        val maxPos = if (effectiveDuration > 0L) effectiveDuration else Long.MAX_VALUE
                                        val newPos = (currentPosition + 30000L).coerceAtMost(maxPos)
                                        exoPlayer?.seekTo(newPos)
                                        currentPosition = newPos
                                        showHud("⏩ +30s (${formatPlaybackTime(newPos)})")
                                    },
                                    modifier = Modifier
                                        .size(34.dp)
                                        .background(Color.Black.copy(alpha = 0.4f), shape = CircleShape)
                                        .tvFocusable(onClick = {
                                            val maxPos = if (effectiveDuration > 0L) effectiveDuration else Long.MAX_VALUE
                                            val newPos = (currentPosition + 30000L).coerceAtMost(maxPos)
                                            exoPlayer?.seekTo(newPos)
                                            currentPosition = newPos
                                            showHud("⏩ +30s (${formatPlaybackTime(newPos)})")
                                        })
                                ) {
                                    Text("+30s", color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(0.65f)) {
                                if (channel.logoUrl.isNotEmpty()) {
                                    AsyncImage(
                                        model = channel.logoUrl,
                                        contentDescription = channel.name,
                                        modifier = Modifier
                                            .size(90.dp)
                                            .clip(RoundedCornerShape(12.dp))
                                    )
                                    Spacer(modifier = Modifier.width(16.dp))
                                }

                                Column {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text(
                                            text = channel.name.uppercase(),
                                            color = Color.White,
                                            fontSize = 18.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                        
                                        if (isRecording) {
                                            Spacer(modifier = Modifier.width(12.dp))
                                            Row(
                                                verticalAlignment = Alignment.CenterVertically,
                                                modifier = Modifier
                                                    .alpha(recBlinkAlpha)
                                                    .background(Color.Red, shape = RoundedCornerShape(4.dp))
                                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                                            ) {
                                                Box(
                                                    modifier = Modifier
                                                        .size(6.dp)
                                                        .background(Color.White, shape = CircleShape)
                                                )
                                                Spacer(modifier = Modifier.width(4.dp))
                                                Text("REC ${recordingDuration}s", color = Color.White, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                                            }
                                        }
                                    }
                                    Spacer(modifier = Modifier.height(4.dp))
                                    val streamDetails = if (channel.type == "Movie" || channel.type == "Series") {
                                        "VIDÉO À LA DEMANDE"
                                    } else {
                                        "CATÉGORIE: ${channel.groupName.uppercase()}"
                                    }
                                    val annotatedStreamDetails = androidx.compose.ui.text.buildAnnotatedString {
                                        val patterns = listOf("ⓉⓋ", "🅃🅅", "🆃🆅", "TV")
                                        append(streamDetails)
                                        patterns.forEach { pattern ->
                                            var index = streamDetails.indexOf(pattern, ignoreCase = true)
                                            while (index != -1) {
                                                addStyle(
                                                    style = androidx.compose.ui.text.SpanStyle(color = Color(0xFF10B981), fontWeight = FontWeight.Bold),
                                                    start = index,
                                                    end = index + pattern.length
                                                )
                                                index = streamDetails.indexOf(pattern, index + 1, ignoreCase = true)
                                            }
                                        }
                                    }
                                    Text(
                                        text = annotatedStreamDetails,
                                        color = Color.LightGray,
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Medium
                                    )
                                    Spacer(modifier = Modifier.height(4.dp))
                                    
                                    if (channel.type == "Movie" || channel.type == "Series") {
                                        Text(
                                            text = "En cours de lecture: Film/Série en streaming direct",
                                            color = Color.Gray,
                                            fontSize = 11.sp
                                        )
                                    } else if (isTimeshiftActive && currentTimeshiftProgram != null) {
                                        val prog = currentTimeshiftProgram!!
                                        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                            Row(
                                                verticalAlignment = Alignment.CenterVertically,
                                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                                            ) {
                                                Text(
                                                    text = "🔴 TIMESHIFT / REPLAY : ${prog.title}",
                                                    color = Color(0xFFFF9800),
                                                    fontSize = 12.sp,
                                                    fontWeight = FontWeight.Bold
                                                )
                                            }
                                            Text(
                                                text = "Horaire original : ${prog.startTime} - ${prog.endTime} • ${prog.description}",
                                                color = Color.LightGray,
                                                fontSize = 11.sp,
                                                maxLines = 1,
                                                overflow = TextOverflow.Ellipsis
                                            )
                                        }
                                    } else {
                                        // Dynamic EPG Integration
                                        val (currentProg, nextProg, progress) = activeChannelEpg
                                        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                            Row(
                                                verticalAlignment = Alignment.CenterVertically,
                                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                                            ) {
                                                Text(
                                                    text = "Maintenant: ${currentProg.title} [${currentProg.startTime} - ${currentProg.endTime}]",
                                                    color = Color(0xFF00E5FF),
                                                    fontSize = 11.sp,
                                                    fontWeight = FontWeight.Bold
                                                )
                                                // Small progress indicator
                                                Box(
                                                    modifier = Modifier
                                                        .width(80.dp)
                                                        .height(4.dp)
                                                        .background(Color.White.copy(alpha = 0.2f), shape = RoundedCornerShape(2.dp))
                                                ) {
                                                    Box(
                                                        modifier = Modifier
                                                            .fillMaxHeight()
                                                            .fillMaxWidth(progress)
                                                            .background(Color(0xFF00E5FF), shape = RoundedCornerShape(2.dp))
                                                    )
                                                }
                                            }
                                            Text(
                                                text = "Suivant: ${nextProg.title} [${nextProg.startTime} - ${nextProg.endTime}]",
                                                color = Color.Gray,
                                                fontSize = 10.sp
                                            )
                                        }
                                    }
                                }
                            }

                            // Right: clock & playback controls (moved down)
                            Column(
                                horizontalAlignment = Alignment.End,
                                modifier = Modifier.weight(0.35f),
                                verticalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Text(
                                    text = java.text.SimpleDateFormat("HH:mm:ss", java.util.Locale.getDefault()).format(java.util.Date()),
                                    color = Color.White,
                                    fontSize = 18.sp,
                                    fontWeight = FontWeight.Bold
                                )

                                Row(
                                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    // Play/Pause button
                                    IconButton(
                                        onClick = {
                                            exoPlayer?.let { player ->
                                                if (player.isPlaying) {
                                                    player.pause()
                                                } else {
                                                    player.play()
                                                }
                                                isPlayingState = player.isPlaying
                                            }
                                        },
                                        modifier = Modifier
                                            .size(40.dp)
                                            .background(
                                                brush = androidx.compose.ui.graphics.Brush.linearGradient(
                                                    colors = listOf(Color(0xFF00E5FF), Color(0xFF10B981))
                                                ),
                                                shape = CircleShape
                                            )
                                            .tvFocusable(
                                                focusedColor = Color.White,
                                                borderRadius = 20.dp,
                                                onClick = {
                                                    exoPlayer?.let { player ->
                                                        if (player.isPlaying) {
                                                            player.pause()
                                                        } else {
                                                            player.play()
                                                        }
                                                        isPlayingState = player.isPlaying
                                                    }
                                                }
                                            )
                                    ) {
                                        Icon(
                                            imageVector = if (isPlayingState) Icons.Default.Pause else Icons.Default.PlayArrow,
                                            contentDescription = if (isPlayingState) "Pause" else "Play",
                                            tint = Color.White,
                                            modifier = Modifier.size(20.dp)
                                        )
                                    }

                                    // Record button
                                    val isCurrentRecordingThis = isRecording && recordingChannel?.streamUrl == channel.streamUrl
                                    IconButton(
                                        onClick = {
                                            if (isCurrentRecordingThis) {
                                                viewModel.stopRecording()
                                            } else {
                                                viewModel.startRecording(channel)
                                            }
                                        },
                                        modifier = Modifier
                                            .size(40.dp)
                                            .alpha(if (isCurrentRecordingThis) recBlinkAlpha else 1f)
                                            .background(
                                                color = if (isCurrentRecordingThis) Color(0xFFEF4444) else Color(0xFF1E293B),
                                                shape = CircleShape
                                            )
                                            .tvFocusable(
                                                focusedColor = Color.White,
                                                borderRadius = 20.dp,
                                                onClick = {
                                                    if (isCurrentRecordingThis) {
                                                        viewModel.stopRecording()
                                                    } else {
                                                        viewModel.startRecording(channel)
                                                    }
                                                }
                                            )
                                    ) {
                                        Icon(
                                            imageVector = if (isCurrentRecordingThis) Icons.Default.Close else Icons.Default.FiberManualRecord,
                                            contentDescription = if (isCurrentRecordingThis) "Stop Recording" else "Record",
                                            tint = if (isCurrentRecordingThis) Color.White else Color(0xFFEF4444),
                                            modifier = Modifier.size(20.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // Sliding Lateral Sidebar Channel list
        AnimatedVisibility(
            visible = showSidebar,
            enter = slideInHorizontally(initialOffsetX = { -it }) + fadeIn(),
            exit = slideOutHorizontally(targetOffsetX = { -it }) + fadeOut(),
            modifier = Modifier
                .align(Alignment.CenterStart)
                .fillMaxHeight()
                .width(420.dp)
                .background(Color(0xF209061C))
                .border(BorderStroke(2.dp, Color(0xFF332766)))
                .padding(horizontal = 16.dp, vertical = 18.dp)
        ) {
            Column(modifier = Modifier.fillMaxSize()) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 16.dp, start = 4.dp, end = 4.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "PLAYLIST",
                            color = Color(0xFF00E5FF),
                            fontSize = 24.sp,
                            fontWeight = FontWeight.Black,
                            letterSpacing = 0.5.sp
                        )
                        Text(
                            text = "LATÉRALE",
                            color = Color(0xFF00E5FF),
                            fontSize = 24.sp,
                            fontWeight = FontWeight.Black,
                            letterSpacing = 0.5.sp
                        )
                    }
                    Box(
                        modifier = Modifier
                            .size(44.dp)
                            .border(2.dp, Color.White.copy(alpha = 0.9f), CircleShape)
                            .clickable { showSidebar = false }
                            .tvFocusable(
                                focusedColor = CeylanColor,
                                borderRadius = 22.dp,
                                onClick = { showSidebar = false }
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            Icons.Default.Close,
                            contentDescription = "Fermer",
                            tint = Color.White,
                            modifier = Modifier.size(24.dp)
                        )
                    }
                }
                LazyColumn(
                    state = sidebarLazyListState,
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    itemsIndexed(sidebarItems, key = { index, ch -> if (ch.id != 0L) "sb_${ch.id}" else "sb_url_${ch.streamUrl}_$index" }) { index, ch ->
                        val isCurrent = ch.streamUrl == channel.streamUrl
                        val focusRequesterItem = remember { FocusRequester() }
                        val focusRequesterCatchup = remember { FocusRequester() }
                        
                        DisposableEffect(index) {
                            sidebarFocusRequesters[index] = focusRequesterItem
                            sidebarCatchupRequesters[index] = focusRequesterCatchup
                            onDispose {
                                sidebarFocusRequesters.remove(index)
                                sidebarCatchupRequesters.remove(index)
                            }
                        }

                        // Display number: index + 1
                        val itemNum = "${index + 1}"

                        val chProgress = remember(ch, watchProgressList) {
                            watchProgressList.find { wp ->
                                wp.episodeId == ch.streamUrl ||
                                (ch.type == "Series" && (wp.title.endsWith(ch.name) || wp.title.contains(ch.name))) ||
                                (ch.type == "Movie" && wp.title.equals(ch.name, ignoreCase = true))
                            }
                        }
                        val isChInProgress = chProgress != null && chProgress.positionMs > 5000L
                        val chProgressPercent = if (chProgress != null && chProgress.durationMs > 0) {
                            (chProgress.positionMs.toFloat() / chProgress.durationMs.toFloat()).coerceIn(0f, 1f)
                        } else 0f

                        val hasCatchup = (ch.type == "Live" || ch.type == "TV") && (ch.hasCatchup || ch.tvArchiveDuration > 0 || ch.catchupDurationDays > 0)
                        val openCatchupDialog = {
                            showCatchupDialogForChannel = ch
                        }

                        val handleSelectSidebarChannel = {
                            val startPos = if (isChInProgress) (chProgress?.positionMs ?: 0L) else 0L
                            viewModel.selectChannel(
                                ch,
                                keepFullScreen = true,
                                skipResumeCheck = false,
                                startPositionMs = startPos
                            )
                        }

                        var isChannelFocused by remember { mutableStateOf(false) }
                        var isCatchupFocused by remember { mutableStateOf(false) }

                        val isCurrentAndActive = isCurrent && !isCatchupFocused
                        val channelBorderWidth = when {
                            isCurrentAndActive -> 2.dp
                            isChannelFocused -> 1.5.dp
                            else -> 0.dp
                        }
                        val channelBorderColor = when {
                            isCurrentAndActive -> Color(0xFF00E5FF)
                            isChannelFocused -> Color(0xFF00E5FF).copy(alpha = 0.6f)
                            else -> Color.Transparent
                        }

                        Row(
                            modifier = Modifier
                                .fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            // 1. Channel Line (Isolated clickable card for playing the channel with single clean contour)
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .background(
                                        if (isChannelFocused || isCurrentAndActive) Color(0xFF0D1E3A) else Color(0xFF131530),
                                        shape = RoundedCornerShape(16.dp)
                                    )
                                    .border(
                                        width = channelBorderWidth,
                                        color = channelBorderColor,
                                        shape = RoundedCornerShape(16.dp)
                                    )
                                    .focusRequester(focusRequesterItem)
                                    .onFocusChanged {
                                        isChannelFocused = it.isFocused
                                        if (it.isFocused) {
                                            sidebarCursorIndex = index
                                        }
                                    }
                                    .focusable()
                                    .clickable { handleSelectSidebarChannel() }
                                    .onKeyEvent { keyEvent ->
                                        if (keyEvent.type == KeyEventType.KeyDown) {
                                            val native = keyEvent.nativeKeyEvent.keyCode
                                            if (keyEvent.key == Key.DirectionUp || native == 19 || native == 166 || native == 92) {
                                                if (sidebarItems.isNotEmpty()) {
                                                    val prevIdx = if (index > 0) index - 1 else sidebarItems.size - 1
                                                    sidebarCursorIndex = prevIdx
                                                    coroutineScope.launch {
                                                        sidebarLazyListState.animateScrollToItem(prevIdx)
                                                        delay(40)
                                                        sidebarFocusRequesters[prevIdx]?.requestFocus()
                                                    }
                                                }
                                                true
                                            } else if (keyEvent.key == Key.DirectionDown || native == 20 || native == 167 || native == 93) {
                                                if (sidebarItems.isNotEmpty()) {
                                                    val nextIdx = if (index < sidebarItems.size - 1) index + 1 else 0
                                                    sidebarCursorIndex = nextIdx
                                                    coroutineScope.launch {
                                                        sidebarLazyListState.animateScrollToItem(nextIdx)
                                                        delay(40)
                                                        sidebarFocusRequesters[nextIdx]?.requestFocus()
                                                    }
                                                }
                                                true
                                            } else if (keyEvent.key == Key.DirectionCenter || keyEvent.key == Key.Enter || keyEvent.key == Key.NumPadEnter || native == 23 || native == 66) {
                                                handleSelectSidebarChannel()
                                                true
                                            } else if ((keyEvent.key == Key.DirectionRight || native == 22) && hasCatchup) {
                                                focusRequesterCatchup.requestFocus()
                                                true
                                            } else if (keyEvent.key == Key.DirectionRight || native == 22 || keyEvent.key == Key.Back) {
                                                showSidebar = false
                                                true
                                            } else {
                                                false
                                            }
                                        } else {
                                            false
                                        }
                                    }
                                    .padding(horizontal = 16.dp, vertical = 12.dp)
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = itemNum,
                                        color = Color(0xFFFFD600),
                                        fontSize = if (isChannelFocused || isCurrent) 32.sp else 28.sp,
                                        fontWeight = FontWeight.Black,
                                        modifier = Modifier.widthIn(min = 46.dp)
                                    )
                                    Spacer(modifier = Modifier.width(10.dp))
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = ch.name,
                                            color = Color.White,
                                            fontSize = 17.sp,
                                            fontWeight = if (isChannelFocused || isCurrent) FontWeight.Black else FontWeight.Bold,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )

                                        if (isChInProgress && chProgress != null) {
                                            val stoppedSec = chProgress.positionMs / 1000
                                            val sMin = stoppedSec / 60
                                            val sSec = stoppedSec % 60
                                            Spacer(modifier = Modifier.height(3.dp))
                                            val epSubText = if (chProgress.episodeNumber > 0) {
                                                if (chProgress.seasonNumber > 0) "S${chProgress.seasonNumber} • EP ${chProgress.episodeNumber} • Reprendre à %02d:%02d".format(sMin, sSec)
                                                else "Épisode ${chProgress.episodeNumber} • Reprendre à %02d:%02d".format(sMin, sSec)
                                            } else {
                                                "Reprendre à %02d:%02d".format(sMin, sSec)
                                            }
                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                Box(
                                                    modifier = Modifier
                                                        .background(Color(0xFF00E5FF).copy(alpha = 0.18f), shape = RoundedCornerShape(4.dp))
                                                        .border(1.dp, Color(0xFF00E5FF).copy(alpha = 0.6f), shape = RoundedCornerShape(4.dp))
                                                        .padding(horizontal = 5.dp, vertical = 1.dp)
                                                ) {
                                                    Text("EN COURS", color = Color.White, fontSize = 9.sp, fontWeight = FontWeight.Black)
                                                }
                                                Spacer(modifier = Modifier.width(6.dp))
                                                Text(
                                                    text = epSubText,
                                                    color = Color(0xFF00E5FF),
                                                    fontSize = 11.5.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    maxLines = 1,
                                                    overflow = TextOverflow.Ellipsis
                                                )
                                            }
                                            Spacer(modifier = Modifier.height(4.dp))
                                            LinearProgressIndicator(
                                                progress = { chProgressPercent },
                                                modifier = Modifier
                                                    .fillMaxWidth(0.9f)
                                                    .height(3.5.dp)
                                                    .clip(RoundedCornerShape(2.dp)),
                                                color = Color(0xFFFFD600),
                                                trackColor = Color(0xFF251D4A)
                                            )
                                        }
                                    }

                                    if (!hasCatchup) {
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Icon(
                                            imageVector = Icons.Default.KeyboardArrowRight,
                                            contentDescription = null,
                                            tint = if (isChannelFocused || isCurrent) Color(0xFF00E5FF) else Color(0xFF5A688A),
                                            modifier = Modifier.size(22.dp)
                                        )
                                    }
                                }
                            }

                            // 2. Catch-up Icon (ISOLATED from the channel line for independent remote control)
                            if (hasCatchup) {
                                Spacer(modifier = Modifier.width(8.dp))
                                Box(
                                    modifier = Modifier
                                        .size(46.dp)
                                        .clip(RoundedCornerShape(12.dp))
                                        .background(
                                            if (isCatchupFocused) Color(0xFF00E5FF).copy(alpha = 0.35f)
                                            else Color(0xFF00E5FF).copy(alpha = 0.15f)
                                        )
                                        .border(
                                            width = if (isCatchupFocused) 2.dp else 1.2.dp,
                                            color = if (isCatchupFocused) Color(0xFFFFD600) else Color(0xFF00E5FF).copy(alpha = 0.8f),
                                            shape = RoundedCornerShape(12.dp)
                                        )
                                        .focusRequester(focusRequesterCatchup)
                                        .onFocusChanged {
                                            isCatchupFocused = it.isFocused
                                        }
                                        .focusable()
                                        .clickable { openCatchupDialog() }
                                        .onKeyEvent { keyEvent ->
                                            if (keyEvent.type == KeyEventType.KeyDown) {
                                                val native = keyEvent.nativeKeyEvent.keyCode
                                                if (keyEvent.key == Key.DirectionLeft || native == 21) {
                                                    focusRequesterItem.requestFocus()
                                                    true
                                                } else if (keyEvent.key == Key.DirectionUp || native == 19 || native == 166 || native == 92) {
                                                    if (sidebarItems.isNotEmpty()) {
                                                        val prevIdx = if (index > 0) index - 1 else sidebarItems.size - 1
                                                        sidebarCursorIndex = prevIdx
                                                        coroutineScope.launch {
                                                            sidebarLazyListState.animateScrollToItem(prevIdx)
                                                            delay(40)
                                                            val prevCh = sidebarItems[prevIdx]
                                                            val prevHasCatchup = (prevCh.type == "Live" || prevCh.type == "TV") && (prevCh.hasCatchup || prevCh.tvArchiveDuration > 0 || prevCh.catchupDurationDays > 0)
                                                            if (prevHasCatchup && sidebarCatchupRequesters.containsKey(prevIdx)) {
                                                                sidebarCatchupRequesters[prevIdx]?.requestFocus()
                                                            } else {
                                                                sidebarFocusRequesters[prevIdx]?.requestFocus()
                                                            }
                                                        }
                                                    }
                                                    true
                                                } else if (keyEvent.key == Key.DirectionDown || native == 20 || native == 167 || native == 93) {
                                                    if (sidebarItems.isNotEmpty()) {
                                                        val nextIdx = if (index < sidebarItems.size - 1) index + 1 else 0
                                                        sidebarCursorIndex = nextIdx
                                                        coroutineScope.launch {
                                                            sidebarLazyListState.animateScrollToItem(nextIdx)
                                                            delay(40)
                                                            val nextCh = sidebarItems[nextIdx]
                                                            val nextHasCatchup = (nextCh.type == "Live" || nextCh.type == "TV") && (nextCh.hasCatchup || nextCh.tvArchiveDuration > 0 || nextCh.catchupDurationDays > 0)
                                                            if (nextHasCatchup && sidebarCatchupRequesters.containsKey(nextIdx)) {
                                                                sidebarCatchupRequesters[nextIdx]?.requestFocus()
                                                            } else {
                                                                sidebarFocusRequesters[nextIdx]?.requestFocus()
                                                            }
                                                        }
                                                    }
                                                    true
                                                } else if (keyEvent.key == Key.DirectionCenter || keyEvent.key == Key.Enter || keyEvent.key == Key.NumPadEnter || native == 23 || native == 66) {
                                                    openCatchupDialog()
                                                    true
                                                } else if (keyEvent.key == Key.DirectionRight || native == 22 || keyEvent.key == Key.Back) {
                                                    showSidebar = false
                                                    true
                                                } else {
                                                    false
                                                }
                                            } else {
                                                false
                                            }
                                        },
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.History,
                                        contentDescription = "Voir le programme EPG et calendrier Catch-up",
                                        tint = if (isCatchupFocused) Color(0xFFFFD600) else Color(0xFF00E5FF),
                                        modifier = Modifier.size(24.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // Sliding Lateral Settings Submenu (Right side)
        AnimatedVisibility(
            visible = showPlayerSettingsMenu,
            enter = slideInHorizontally(initialOffsetX = { it }) + fadeIn(),
            exit = slideOutHorizontally(targetOffsetX = { it }) + fadeOut(),
            modifier = Modifier
                .align(Alignment.CenterEnd)
                .fillMaxHeight()
                .width(320.dp)
                .background(Color(0xFF0F172A).copy(alpha = 0.95f))
                .border(BorderStroke(1.dp, Color(0xFF1E293B)))
                .padding(20.dp)
        ) {
            Column {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Icon(Icons.Default.Settings, contentDescription = "Paramètres", tint = Color(0xFF00E5FF))
                        Text(
                            text = "Paramètres Vidéo",
                            color = Color.White,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    IconButton(onClick = { showPlayerSettingsMenu = false }) {
                        Icon(Icons.Default.Close, contentDescription = "Fermer", tint = Color.White)
                    }
                }
                Spacer(modifier = Modifier.height(16.dp))

                Button(
                    onClick = {
                        showSubtitleSettingsBottomSheet = true
                        showPlayerSettingsMenu = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E293B)),
                    border = BorderStroke(1.dp, Color(0xFF00E5FF).copy(alpha = 0.6f)),
                    modifier = Modifier
                        .fillMaxWidth()
                        .tvFocusable(onClick = {
                            showSubtitleSettingsBottomSheet = true
                            showPlayerSettingsMenu = false
                        })
                ) {
                    Icon(
                        imageVector = Icons.Default.Subtitles,
                        contentDescription = "Sous-titres & Vocal TV",
                        tint = Color(0xFF00E5FF),
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("💬 Sous-titres & Vocal TV", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
                Spacer(modifier = Modifier.height(12.dp))

                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(16.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    // Category Item
                    item {
                        Column {
                            Text("SOUS-CATÉGORIE", color = Color(0xFF00E5FF), fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                            Spacer(modifier = Modifier.height(4.dp))
                            Card(
                                colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B)),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text(
                                    text = channel.groupName,
                                    color = Color.White,
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(12.dp)
                                )
                            }
                        }
                    }

                    // Brightness (Luminosité) Option (Slider)
                    item {
                        Column {
                            Text("LUMINOSITÉ", color = Color(0xFF00E5FF), fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                            Spacer(modifier = Modifier.height(8.dp))
                            var isBrightFocused by remember { mutableStateOf(false) }
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .onFocusChanged { isBrightFocused = it.isFocused }
                                    .border(
                                        width = if (isBrightFocused) 1.5.dp else 1.dp,
                                        color = if (isBrightFocused) Color(0xFF00E5FF) else Color(0x33FFFFFF),
                                        shape = RoundedCornerShape(8.dp)
                                    )
                                    .background(
                                        if (isBrightFocused) Color(0x1F00E5FF) else Color(0xFF1E293B),
                                        shape = RoundedCornerShape(8.dp)
                                    )
                                    .focusable()
                                    .onKeyEvent { keyEvent ->
                                        if (keyEvent.type == KeyEventType.KeyDown) {
                                            when (keyEvent.key) {
                                                Key.DirectionLeft -> {
                                                    viewModel.setBrightnessLevel((brightnessLevel - 0.05f).coerceIn(0.1f, 2.0f))
                                                    true
                                                }
                                                Key.DirectionRight -> {
                                                    viewModel.setBrightnessLevel((brightnessLevel + 0.05f).coerceIn(0.1f, 2.0f))
                                                    true
                                                }
                                                else -> false
                                            }
                                        } else {
                                            false
                                        }
                                    }
                                    .padding(horizontal = 12.dp, vertical = 8.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Brightness5,
                                    contentDescription = "Luminosité",
                                    tint = Color(0xFF00E5FF),
                                    modifier = Modifier.size(18.dp)
                                )
                                Slider(
                                    value = brightnessLevel,
                                    onValueChange = { viewModel.setBrightnessLevel(it) },
                                    valueRange = 0.1f..2.0f,
                                    colors = SliderDefaults.colors(
                                        activeTrackColor = Color(0xFF00E5FF),
                                        inactiveTrackColor = Color.Gray.copy(alpha = 0.5f),
                                        thumbColor = Color(0xFF00E5FF)
                                    ),
                                    modifier = Modifier.weight(1f)
                                )
                                Text(
                                    text = "${(brightnessLevel * 100).toInt()}%",
                                    color = Color.White,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.width(38.dp),
                                    textAlign = TextAlign.End
                                )
                            }
                        }
                    }

                    // Zoom de l'écran Option (Slider)
                    item {
                        Column {
                            Text("ZOOM DE L'ÉCRAN", color = Color(0xFF00E5FF), fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                            Spacer(modifier = Modifier.height(8.dp))
                            var isZoomSliderFocused by remember { mutableStateOf(false) }
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .onFocusChanged { isZoomSliderFocused = it.isFocused }
                                    .border(
                                        width = if (isZoomSliderFocused) 1.5.dp else 1.dp,
                                        color = if (isZoomSliderFocused) Color(0xFF00E5FF) else Color(0x33FFFFFF),
                                        shape = RoundedCornerShape(8.dp)
                                    )
                                    .background(
                                        if (isZoomSliderFocused) Color(0x1F00E5FF) else Color(0xFF1E293B),
                                        shape = RoundedCornerShape(8.dp)
                                    )
                                    .focusable()
                                    .onKeyEvent { keyEvent ->
                                        if (keyEvent.type == KeyEventType.KeyDown) {
                                            when (keyEvent.key) {
                                                Key.DirectionLeft -> {
                                                    viewModel.setZoomLevel((zoomLevel - 0.05f).coerceIn(0.5f, 2.5f))
                                                    true
                                                }
                                                Key.DirectionRight -> {
                                                    viewModel.setZoomLevel((zoomLevel + 0.05f).coerceIn(0.5f, 2.5f))
                                                    true
                                                }
                                                else -> false
                                            }
                                        } else {
                                            false
                                        }
                                    }
                                    .padding(horizontal = 12.dp, vertical = 8.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.ZoomIn,
                                    contentDescription = "Zoom",
                                    tint = Color(0xFF00E5FF),
                                    modifier = Modifier.size(18.dp)
                                )
                                Slider(
                                    value = zoomLevel,
                                    onValueChange = { viewModel.setZoomLevel(it) },
                                    valueRange = 0.5f..2.5f,
                                    colors = SliderDefaults.colors(
                                        activeTrackColor = Color(0xFF00E5FF),
                                        inactiveTrackColor = Color.Gray.copy(alpha = 0.5f),
                                        thumbColor = Color(0xFF00E5FF)
                                    ),
                                    modifier = Modifier.weight(1f)
                                )
                                Text(
                                    text = "${((zoomLevel * 100).toInt() / 100.0)}x",
                                    color = Color.White,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.width(38.dp),
                                    textAlign = TextAlign.End
                                )
                            }
                        }
                    }

                    // Image Enhancement (Amélioration d'image) Option
                    item {
                        Column {
                            Text("AMÉLIORATION D'IMAGE", color = Color(0xFF00E5FF), fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                            Spacer(modifier = Modifier.height(8.dp))
                            val enhancementModes = listOf(
                                "Désactivé" to "Désactivé (Standard)",
                                "Cinéma" to "Cinéma (Contraste chaud)",
                                "Sport" to "Sport (Couleurs éclatantes)",
                                "Doux" to "Mode Doux (Anti-lumière bleue)",
                                "Éclatant" to "Éclatant (Vivid)"
                            )
                            enhancementModes.forEach { (mode, label) ->
                                val isSelected = imageEnhancementMode == mode
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 4.dp)
                                        .background(
                                            if (isSelected) Color(0x3300E5FF) else Color.Transparent,
                                            shape = RoundedCornerShape(8.dp)
                                        )
                                        .border(
                                            width = if (isSelected) 1.5.dp else 1.dp,
                                            color = if (isSelected) Color(0xFF00E5FF) else Color(0x33FFFFFF),
                                            shape = RoundedCornerShape(8.dp)
                                        )
                                        .tvFocusable(
                                            onClick = {
                                                viewModel.setImageEnhancementMode(mode)
                                                showHud("Image : $label")
                                            }
                                        )
                                        .padding(horizontal = 12.dp, vertical = 10.dp)
                                ) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(label, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Medium)
                                        if (isSelected) {
                                            Icon(Icons.Default.Check, contentDescription = "Sélectionné", tint = Color(0xFF00E5FF), modifier = Modifier.size(16.dp))
                                        }
                                    }
                                }
                            }
                        }
                    }

                    // Format & Quality Option
                    item {
                        Column {
                            Text("FORMAT VIDÉO & QUALITÉ", color = Color(0xFF00E5FF), fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                            Spacer(modifier = Modifier.height(8.dp))
                            val qualities = listOf("Auto (UHD/FHD)", "UHD 4K (HEVC)", "Full HD 1080p", "HD 720p")
                            qualities.forEach { q ->
                                val isSelected = activeVideoQuality == q
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 4.dp)
                                        .background(
                                            if (isSelected) Color(0x3300E5FF) else Color.Transparent,
                                            shape = RoundedCornerShape(8.dp)
                                        )
                                        .border(
                                            width = if (isSelected) 1.5.dp else 1.dp,
                                            color = if (isSelected) Color(0xFF00E5FF) else Color(0x33FFFFFF),
                                            shape = RoundedCornerShape(8.dp)
                                        )
                                        .tvFocusable(
                                            onClick = {
                                                viewModel.setActiveVideoQuality(q)
                                            }
                                        )
                                        .padding(horizontal = 12.dp, vertical = 10.dp)
                                ) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(q, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Medium)
                                        if (isSelected) {
                                            Icon(Icons.Default.Check, contentDescription = "Sélectionné", tint = Color(0xFF00E5FF), modifier = Modifier.size(16.dp))
                                        }
                                    }
                                }
                            }
                        }
                    }

                    // Real Audio Tracks / Format Selector
                    if (availableAudioTracks.isNotEmpty()) {
                        item {
                            Column {
                                Text("PISTE AUDIO", color = Color(0xFF00E5FF), fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                                Spacer(modifier = Modifier.height(8.dp))
                                availableAudioTracks.forEach { (group, trackIndex) ->
                                    val format = group.getTrackFormat(trackIndex)
                                    val isSelected = group.isTrackSelected(trackIndex)
                                    
                                    val displayName = when {
                                        !format.label.isNullOrBlank() -> format.label!!
                                        !format.language.isNullOrBlank() -> {
                                            when (format.language!!.lowercase()) {
                                                "fr", "fra", "fre" -> "Français"
                                                "en", "eng" -> "English"
                                                "es", "spa" -> "Español"
                                                "de", "deu", "ger" -> "Deutsch"
                                                "it", "ita" -> "Italiano"
                                                "pt", "por" -> "Português"
                                                "ar", "ara" -> "العربية"
                                                "ru", "rus" -> "Русский"
                                                "tr", "tur" -> "Türkçe"
                                                else -> format.language!!.uppercase()
                                            }
                                        }
                                        else -> "Piste Audio ${trackIndex + 1}"
                                    }
                                    
                                    Box(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(vertical = 4.dp)
                                            .background(
                                                if (isSelected) Color(0x3300E5FF) else Color.Transparent,
                                                shape = RoundedCornerShape(8.dp)
                                            )
                                            .border(
                                                width = if (isSelected) 1.5.dp else 1.dp,
                                                color = if (isSelected) Color(0xFF00E5FF) else Color(0x33FFFFFF),
                                                shape = RoundedCornerShape(8.dp)
                                            )
                                            .tvFocusable(
                                                onClick = {
                                                    exoPlayer?.let { player ->
                                                        player.trackSelectionParameters = player.trackSelectionParameters.buildUpon()
                                                            .clearOverridesOfType(androidx.media3.common.C.TRACK_TYPE_AUDIO)
                                                            .setOverrideForType(androidx.media3.common.TrackSelectionOverride(group.mediaTrackGroup, trackIndex))
                                                            .build()
                                                    }
                                                }
                                            )
                                            .padding(horizontal = 12.dp, vertical = 10.dp)
                                    ) {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Text(displayName, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Medium)
                                            if (isSelected) {
                                                Icon(Icons.Default.Check, contentDescription = "Sélectionné", tint = Color(0xFF00E5FF), modifier = Modifier.size(16.dp))
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    } else {
                        item {
                            Column {
                                Text("FORMAT AUDIO", color = Color(0xFF00E5FF), fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                                Spacer(modifier = Modifier.height(8.dp))
                                val audioFormats = listOf("Stéréo (Défaut)", "Dolby Digital 5.1", "AC3 HEVC Audio", "Mono")
                                audioFormats.forEach { fmt ->
                                    val isSelected = activeAudioFormat == fmt
                                    Box(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(vertical = 4.dp)
                                            .background(
                                                if (isSelected) Color(0x3300E5FF) else Color.Transparent,
                                                shape = RoundedCornerShape(8.dp)
                                            )
                                            .border(
                                                width = if (isSelected) 1.5.dp else 1.dp,
                                                color = if (isSelected) Color(0xFF00E5FF) else Color(0x33FFFFFF),
                                                shape = RoundedCornerShape(8.dp)
                                            )
                                            .tvFocusable(
                                                onClick = {
                                                    viewModel.setActiveAudioFormat(fmt)
                                                }
                                            )
                                            .padding(horizontal = 12.dp, vertical = 10.dp)
                                    ) {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Text(fmt, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Medium)
                                            if (isSelected) {
                                                Icon(Icons.Default.Check, contentDescription = "Sélectionné", tint = Color(0xFF00E5FF), modifier = Modifier.size(16.dp))
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }

                    // Subtitles Real Selection & Activation
                    item {
                        Column {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text("SOUS-TITRES", color = Color(0xFF00E5FF), fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)

                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(4.dp),
                                    modifier = Modifier
                                        .background(Color(0xFF1E293B), shape = RoundedCornerShape(12.dp))
                                        .tvFocusable(
                                            onClick = {
                                                val current = viewModel.subtitlesEnabled.value
                                                val newEnabled = !current
                                                com.example.debug.GlobalDebugSystem.logFunctionCall("toggleSubtitles_FullScreen", "old" to current, "new" to newEnabled)
                                                viewModel.setSubtitlesEnabled(newEnabled)
                                                if (!newEnabled) {
                                                    viewModel.setSubtitleTranslationEnabled(false)
                                                }
                                            }
                                        )
                                        .padding(horizontal = 8.dp, vertical = 4.dp)
                                ) {
                                    Icon(
                                        imageVector = if (subtitlesEnabled) Icons.Default.CheckCircle else Icons.Default.Close,
                                        contentDescription = "Activer/Désactiver",
                                        tint = if (subtitlesEnabled) Color(0xFF10B981) else Color.Gray,
                                        modifier = Modifier.size(14.dp)
                                    )
                                    Text(
                                        text = if (subtitlesEnabled) "Actifs" else "Désactivés",
                                        color = Color.White,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                            Spacer(modifier = Modifier.height(8.dp))
                            
                            val detectedSubtitleLang by viewModel.detectedSubtitleLanguage.collectAsState()
                            if (availableSubtitleTracks.isEmpty()) {
                                Card(
                                    colors = CardDefaults.cardColors(containerColor = Color(0x1F1E293B)),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Column(modifier = Modifier.padding(12.dp)) {
                                        Text(
                                            text = if (!detectedSubtitleLang.isNullOrBlank()) "Sous-titres détectés en direct" else "Détection automatique des sous-titres...",
                                            color = if (!detectedSubtitleLang.isNullOrBlank()) Color(0xFF10B981) else Color.Gray,
                                            fontSize = 12.sp,
                                            fontWeight = FontWeight.Medium
                                        )
                                        if (!detectedSubtitleLang.isNullOrBlank()) {
                                            Spacer(modifier = Modifier.height(2.dp))
                                            Text(
                                                text = "Langue source : $detectedSubtitleLang",
                                                color = Color(0xFF00E5FF),
                                                fontSize = 11.sp
                                            )
                                        }
                                    }
                                }
                            } else {
                                availableSubtitleTracks.forEach { (group, trackIndex) ->
                                    val format = group.getTrackFormat(trackIndex)
                                    val isSelected = group.isTrackSelected(trackIndex) && subtitlesEnabled
                                    
                                    val displayName = when {
                                        !format.label.isNullOrBlank() -> format.label!!
                                        !format.language.isNullOrBlank() -> com.example.data.TranslationManager.getLanguageDisplayName(format.language)
                                        else -> "Piste de sous-titre ${trackIndex + 1}"
                                    }
                                    
                                    Box(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(vertical = 4.dp)
                                            .background(
                                                if (isSelected) Color(0x3300E5FF) else Color.Transparent,
                                                shape = RoundedCornerShape(8.dp)
                                            )
                                            .border(
                                                width = if (isSelected) 1.5.dp else 1.dp,
                                                color = if (isSelected) Color(0xFF00E5FF) else Color(0x33FFFFFF),
                                                shape = RoundedCornerShape(8.dp)
                                            )
                                            .tvFocusable(
                                                onClick = {
                                                    val current = viewModel.subtitlesEnabled.value
                                                    val isCurrentlySelected = isSelected
                                                    val newEnabled = if (isCurrentlySelected) !current else true
                                                    com.example.debug.GlobalDebugSystem.logFunctionCall("selectSubtitleTrack_FullScreen", "oldEnabled" to current, "newEnabled" to newEnabled, "trackIndex" to trackIndex)
                                                    viewModel.setSubtitlesEnabled(newEnabled)
                                                    if (newEnabled) {
                                                        viewModel.activeSubtitleLanguage = format.language
                                                        exoPlayer?.let { player ->
                                                            player.trackSelectionParameters = player.trackSelectionParameters.buildUpon()
                                                                .setTrackTypeDisabled(androidx.media3.common.C.TRACK_TYPE_TEXT, false)
                                                                .clearOverridesOfType(androidx.media3.common.C.TRACK_TYPE_TEXT)
                                                                .setOverrideForType(androidx.media3.common.TrackSelectionOverride(group.mediaTrackGroup, trackIndex))
                                                                .build()
                                                        }
                                                    } else {
                                                        exoPlayer?.let { player ->
                                                            player.trackSelectionParameters = player.trackSelectionParameters.buildUpon()
                                                                .setTrackTypeDisabled(androidx.media3.common.C.TRACK_TYPE_TEXT, true)
                                                                .clearOverridesOfType(androidx.media3.common.C.TRACK_TYPE_TEXT)
                                                                .build()
                                                        }
                                                    }
                                                }
                                            )
                                            .padding(horizontal = 12.dp, vertical = 10.dp)
                                    ) {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Text(displayName, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Medium)
                                            if (isSelected) {
                                                Icon(Icons.Default.Check, contentDescription = "Sélectionné", tint = Color(0xFF00E5FF), modifier = Modifier.size(16.dp))
                                            }
                                        }
                                    }
                                }
                                if (!detectedSubtitleLang.isNullOrBlank()) {
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        text = "Langue source détectée : $detectedSubtitleLang",
                                        color = Color(0xFF10B981),
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Medium
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(10.dp))

                            // Bouton d'accès direct au panneau complet des sous-titres et Vosk (centralisation sans doublons)
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(Color(0x3300E5FF), shape = RoundedCornerShape(8.dp))
                                    .border(width = 1.dp, color = Color(0xFF00E5FF), shape = RoundedCornerShape(8.dp))
                                    .tvFocusable(
                                        onClick = {
                                            showPlayerSettingsMenu = false
                                            showSubtitleSettingsBottomSheet = true
                                        }
                                    )
                                    .padding(horizontal = 12.dp, vertical = 10.dp)
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                        Icon(
                                            imageVector = Icons.Default.Subtitles,
                                            contentDescription = null,
                                            tint = Color(0xFF00E5FF),
                                            modifier = Modifier.size(18.dp)
                                        )
                                        Column {
                                            Text(
                                                text = "Paramètres Sous-titres & Sherpa-ONNX",
                                                color = Color.White,
                                                fontSize = 13.sp,
                                                fontWeight = FontWeight.Bold
                                            )
                                            Text(
                                                text = "Vocal IA, synchro, traduction, styles",
                                                color = Color(0xFF94A3B8),
                                                fontSize = 11.sp
                                            )
                                        }
                                    }
                                    Icon(
                                        imageVector = Icons.Default.ArrowForwardIos,
                                        contentDescription = null,
                                        tint = Color(0xFF00E5FF),
                                        modifier = Modifier.size(14.dp)
                                    )
                                }
                            }
                        }
                    }





                    // Format Screen Ratio
                    item {
                        Column {
                            Text("FORMAT DE L'ÉCRAN", color = Color(0xFF00E5FF), fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                            Spacer(modifier = Modifier.height(8.dp))
                            val aspectRatios = listOf(
                                Pair("Ajuster (Fit 16:9)", 0),
                                Pair("Étirer (Stretch)", 3),
                                Pair("Zoom intelligent", 4)
                            )
                            aspectRatios.forEach { (label, mode) ->
                                val isSelected = resizeModeState == mode
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 4.dp)
                                        .background(
                                            if (isSelected) Color(0x3300E5FF) else Color.Transparent,
                                            shape = RoundedCornerShape(8.dp)
                                        )
                                        .border(
                                            width = if (isSelected) 1.5.dp else 1.dp,
                                            color = if (isSelected) Color(0xFF00E5FF) else Color(0x33FFFFFF),
                                            shape = RoundedCornerShape(8.dp)
                                        )
                                        .tvFocusable(
                                            onClick = {
                                                viewModel.setResizeModeState(mode)
                                            }
                                        )
                                        .padding(horizontal = 12.dp, vertical = 10.dp)
                                ) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(label, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Medium)
                                        if (isSelected) {
                                            Icon(Icons.Default.Check, contentDescription = "Sélectionné", tint = Color(0xFF00E5FF), modifier = Modifier.size(16.dp))
                                        }
                                    }
                                }
                            }
                        }
                    }

                    // Speed factor option
                    item {
                        Column {
                            Text("VITESSE DE LECTURE", color = Color(0xFF00E5FF), fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                            Spacer(modifier = Modifier.height(8.dp))
                            val speeds = listOf(
                                Pair("Normale (1.0x)", 1.0f),
                                Pair("Lente (0.75x)", 0.75f),
                                Pair("Rapide (1.25x)", 1.25f),
                                Pair("Accélérée (1.5x)", 1.5f)
                            )
                            speeds.forEach { (label, value) ->
                                val isSelected = playbackSpeedState == value
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 4.dp)
                                        .background(
                                            if (isSelected) Color(0x3300E5FF) else Color.Transparent,
                                            shape = RoundedCornerShape(8.dp)
                                        )
                                        .border(
                                            width = if (isSelected) 1.5.dp else 1.dp,
                                            color = if (isSelected) Color(0xFF00E5FF) else Color(0x33FFFFFF),
                                            shape = RoundedCornerShape(8.dp)
                                        )
                                        .tvFocusable(
                                            onClick = {
                                                viewModel.setPlaybackSpeedState(value)
                                            }
                                        )
                                        .padding(horizontal = 12.dp, vertical = 10.dp)
                                ) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(label, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Medium)
                                        if (isSelected) {
                                            Icon(Icons.Default.Check, contentDescription = "Sélectionné", tint = Color(0xFF00E5FF), modifier = Modifier.size(16.dp))
                                        }
                                    }
                                }
                            }
                        }
                    }

                    // Share Stream URL Option
                    item {
                        Column {
                            Text("PARTAGER LE FLUX", color = Color(0xFF00E5FF), fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                            Spacer(modifier = Modifier.height(8.dp))
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(Color(0xFF10B981).copy(alpha = 0.2f), shape = RoundedCornerShape(8.dp))
                                    .border(1.dp, Color(0xFF10B981), shape = RoundedCornerShape(8.dp))
                                    .tvFocusable(
                                        onClick = {
                                            val urlToShare = playbackUrl ?: channel.streamUrl
                                            if (urlToShare.isNotBlank()) {
                                                val clipboard = context.getSystemService(android.content.Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
                                                val clip = android.content.ClipData.newPlainText("IPTV Stream URL", urlToShare)
                                                clipboard.setPrimaryClip(clip)
                                                Toast.makeText(context, "Lien du flux copié dans le presse-papiers !", Toast.LENGTH_SHORT).show()
                                                
                                                try {
                                                    val sendIntent = android.content.Intent().apply {
                                                        action = android.content.Intent.ACTION_SEND
                                                        putExtra(android.content.Intent.EXTRA_TEXT, urlToShare)
                                                        type = "text/plain"
                                                    }
                                                    val shareIntent = android.content.Intent.createChooser(sendIntent, "Partager le lien du flux")
                                                    context.startActivity(shareIntent)
                                                } catch (e: Exception) {
                                                    Log.e("ShareStream", "Error sharing stream intent: ${e.message}")
                                                }
                                            }
                                        }
                                    )
                                    .padding(horizontal = 12.dp, vertical = 12.dp)
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                        Icon(Icons.Default.Share, contentDescription = "Partager", tint = Color(0xFF10B981), modifier = Modifier.size(18.dp))
                                        Text("Partager le lien du flux...", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                                    }
                                    Icon(Icons.Default.ContentCopy, contentDescription = "Copier", tint = Color(0xFF10B981), modifier = Modifier.size(16.dp))
                                }
                            }
                        }
                    }
                }
            }
        }

        if (showCatchupDialogForChannel != null) {
            CatchupProgramsDialog(
                channel = showCatchupDialogForChannel!!,
                viewModel = viewModel,
                onDismiss = { showCatchupDialogForChannel = null },
                onProgramPlayed = { showSidebar = false }
            )
        }

        if (showSubtitleSettingsBottomSheet) {
            LiveTvSubtitleSettingsDialog(
                viewModel = viewModel,
                onDismiss = { showSubtitleSettingsBottomSheet = false }
            )
        }
    }
}

@Composable
fun Modifier.tvFocusable(
    focusedColor: Color = Color(0xFF10B981),
    borderRadius: androidx.compose.ui.unit.Dp = 8.dp,
    onFocus: (() -> Unit)? = null,
    onClick: () -> Unit
): Modifier {
    var isFocused by remember { mutableStateOf(false) }
    
    // Smoothly cycle/animate colors when focused to meet "le pointeur change des couleurs ou je navigue"
    val infiniteTransition = rememberInfiniteTransition(label = "FocusColorTransition")
    val animatedColor by infiniteTransition.animateColor(
        initialValue = focusedColor,
        targetValue = Color(0xFF00E5FF), // Cyan transition
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "FocusBorderColor"
    )

    LaunchedEffect(isFocused) {
        if (isFocused) {
            onFocus?.invoke()
        }
    }

    return this
        .onFocusChanged { isFocused = it.isFocused }
        .scale(if (isFocused) 1.05f else 1.0f)
        .background(
            color = if (isFocused) animatedColor.copy(alpha = 0.18f) else Color.Transparent,
            shape = RoundedCornerShape(borderRadius)
        )
        .border(
            width = if (isFocused) 3.dp else 0.dp,
            color = if (isFocused) animatedColor else Color.Transparent,
            shape = RoundedCornerShape(borderRadius)
        )
        .onKeyEvent { keyEvent ->
            val nativeCode = keyEvent.nativeKeyEvent.keyCode
            val isSelectKey = keyEvent.key == Key.DirectionCenter ||
                keyEvent.key == Key.Enter ||
                keyEvent.key == Key.NumPadEnter ||
                nativeCode == 23 || // KEYCODE_DPAD_CENTER
                nativeCode == 66 || // KEYCODE_ENTER
                nativeCode == 160 || // KEYCODE_NUMPAD_ENTER
                nativeCode == 313 || // KEYCODE_SELECT
                nativeCode == 85 || // KEYCODE_MEDIA_PLAY_PAUSE
                nativeCode == 126   // KEYCODE_MEDIA_PLAY
            if (isFocused && isSelectKey) {
                if (keyEvent.type == KeyEventType.KeyDown) {
                    onClick()
                }
                true
            } else {
                false
            }
        }
        .focusable()
        .clickable(onClick = onClick)
}

fun openRecordingWithExternalPlayer(context: Context, item: RecordingItem) {
    try {
        val uri = if (item.filepath.startsWith("content://") || item.filepath.startsWith("file://") || item.filepath.startsWith("http")) {
            Uri.parse(item.filepath)
        } else {
            Uri.fromFile(java.io.File(item.filepath))
        }

        // Verify if the file is still reachable/accessible
        val exists = try {
            if (uri.scheme == "content") {
                val pfd = context.contentResolver.openFileDescriptor(uri, "r")
                if (pfd != null) {
                    pfd.close()
                    true
                } else {
                    false
                }
            } else if (uri.scheme == "file") {
                val file = uri.path?.let { java.io.File(it) }
                file != null && file.exists()
            } else {
                true
            }
        } catch (e: Exception) {
            false
        }

        if (!exists) {
            Toast.makeText(context, "Ce fichier n'existe plus", Toast.LENGTH_SHORT).show()
            return
        }

        val pathLower = item.filepath.lowercase()
        val mimeType = when {
            pathLower.endsWith(".ts") -> "video/mp2t"
            pathLower.endsWith(".mp4") -> "video/mp4"
            pathLower.endsWith(".mkv") -> "video/x-matroska"
            pathLower.endsWith(".avi") -> "video/x-msvideo"
            pathLower.endsWith(".webm") -> "video/webm"
            else -> "video/*"
        }

        val intent = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(uri, mimeType)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }

        val chooser = Intent.createChooser(intent, "Ouvrir avec...")
        chooser.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(chooser)
    } catch (e: android.content.ActivityNotFoundException) {
        Toast.makeText(context, "Aucune application de lecture vidéo installée sur cet appareil", Toast.LENGTH_LONG).show()
    } catch (e: Exception) {
        Toast.makeText(context, "Impossible d'ouvrir la vidéo : ${e.message ?: "erreur"}", Toast.LENGTH_SHORT).show()
    }
}

@Composable
fun RecordingsSection(viewModel: IptvViewModel) {
    val context = LocalContext.current
    val recordings by viewModel.recordingsList.collectAsState()

    Column(modifier = Modifier.fillMaxSize()) {
        Text(
            text = "Mes Enregistrements TV",
            color = Color.White,
            fontSize = 24.sp,
            fontWeight = FontWeight.Bold
        )
        Spacer(modifier = Modifier.height(16.dp))

        if (recordings.isEmpty()) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        imageVector = Icons.Default.PlayArrow,
                        contentDescription = "Aucun enregistrement",
                        tint = Color.Gray,
                        modifier = Modifier.size(64.dp)
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    Text(
                        text = "Aucun enregistrement disponible.\nEnregistrez vos chaînes préférées depuis l'écran de visionnage réduit.",
                        color = Color.Gray,
                        fontSize = 15.sp,
                        textAlign = TextAlign.Center
                    )
                }
            }
        } else {
            LazyVerticalGrid(
                columns = GridCells.Adaptive(minSize = 280.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp),
                horizontalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                itemsIndexed(recordings, key = { index, item -> "rec_${item.id}_${item.filepath}_$index" }) { index, item ->
                    val playUrl = if (item.filepath.startsWith("content://") || item.filepath.startsWith("file://") || item.filepath.startsWith("http")) item.filepath else "file://${item.filepath}"
                    Card(
                        colors = CardDefaults.cardColors(containerColor = Color(0xFF1E2430)),
                        modifier = Modifier
                            .fillMaxWidth()
                            .tvFocusable(
                                onClick = {
                                    viewModel.playChannelDirectly(item.channelName, playUrl, playlistId = item.playlistId, type = "Recording", keepFullScreen = true)
                                }
                            )
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier.weight(0.7f)
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .background(Color(0x2200E5FF), shape = RoundedCornerShape(4.dp))
                                            .padding(horizontal = 6.dp, vertical = 2.dp)
                                    ) {
                                        Text(
                                            text = String.format("%02d", index + 1),
                                            color = Color(0xFF00E5FF),
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = item.channelName.uppercase(),
                                        color = Color.White,
                                        fontSize = 18.sp,
                                        fontWeight = FontWeight.Bold,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                                Box(
                                    modifier = Modifier
                                        .background(Color(0xFFEF4444), shape = RoundedCornerShape(4.dp))
                                        .padding(horizontal = 6.dp, vertical = 2.dp)
                                ) {
                                    Text("REC", color = Color.White, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = "TITRE: ${item.programTitle.uppercase()}",
                                color = Color.LightGray,
                                fontSize = 13.sp,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "Durée estimée: ${item.durationMinutes} min",
                                color = Color.Gray,
                                fontSize = 12.sp
                            )
                            Spacer(modifier = Modifier.height(12.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(
                                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Button(
                                        onClick = {
                                            viewModel.playChannelDirectly(item.channelName, playUrl, playlistId = item.playlistId, type = "Recording", keepFullScreen = true)
                                        },
                                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF10B981)),
                                        modifier = Modifier.tvFocusable(onClick = {
                                            viewModel.playChannelDirectly(item.channelName, playUrl, playlistId = item.playlistId, type = "Recording", keepFullScreen = true)
                                        })
                                    ) {
                                        Icon(Icons.Default.PlayArrow, contentDescription = "Lire", tint = Color.White, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("Lire", color = Color.White, fontSize = 12.sp)
                                    }

                                    Button(
                                        onClick = {
                                            openRecordingWithExternalPlayer(context, item)
                                        },
                                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E293B)),
                                        border = BorderStroke(1.dp, Color(0xFF00E5FF).copy(alpha = 0.5f)),
                                        modifier = Modifier.tvFocusable(onClick = {
                                            openRecordingWithExternalPlayer(context, item)
                                        })
                                    ) {
                                        Icon(Icons.Default.Share, contentDescription = "Ouvrir avec", tint = Color(0xFF00E5FF), modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("Ouvrir avec", color = Color.White, fontSize = 12.sp)
                                    }
                                }

                                IconButton(
                                    onClick = {
                                        viewModel.deleteRecording(item.id, item.filepath)
                                    }
                                ) {
                                    Icon(Icons.Default.Delete, contentDescription = "Supprimer", tint = Color(0xFFEF4444))
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun PauseIcon(modifier: Modifier = Modifier, color: Color = Color.White) {
    Row(
        modifier = modifier,
        horizontalArrangement = Arrangement.spacedBy(4.dp, Alignment.CenterHorizontally),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(modifier = Modifier.width(6.dp).fillMaxHeight().background(color, shape = RoundedCornerShape(1.dp)))
        Box(modifier = Modifier.width(6.dp).fillMaxHeight().background(color, shape = RoundedCornerShape(1.dp)))
    }
}

@Composable
fun SkipPreviousIcon(modifier: Modifier = Modifier, color: Color = Color.White) {
    Box(modifier = modifier, contentAlignment = Alignment.Center) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center) {
            Box(modifier = Modifier.width(4.dp).height(18.dp).background(color, shape = RoundedCornerShape(1.dp)))
            Spacer(modifier = Modifier.width(2.dp))
            androidx.compose.foundation.Canvas(modifier = Modifier.size(14.dp)) {
                val path = androidx.compose.ui.graphics.Path().apply {
                    moveTo(size.width, 0f)
                    lineTo(0f, size.height / 2f)
                    lineTo(size.width, size.height)
                    close()
                }
                drawPath(path, color)
            }
        }
    }
}

@Composable
fun SkipNextIcon(modifier: Modifier = Modifier, color: Color = Color.White) {
    Box(modifier = modifier, contentAlignment = Alignment.Center) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center) {
            androidx.compose.foundation.Canvas(modifier = Modifier.size(14.dp)) {
                val path = androidx.compose.ui.graphics.Path().apply {
                    moveTo(0f, 0f)
                    lineTo(size.width, size.height / 2f)
                    lineTo(0f, size.height)
                    close()
                }
                drawPath(path, color)
            }
            Spacer(modifier = Modifier.width(2.dp))
            Box(modifier = Modifier.width(4.dp).height(18.dp).background(color, shape = RoundedCornerShape(1.dp)))
        }
    }
}

@Composable
fun GlassmorphicCard(
    modifier: Modifier = Modifier,
    borderColor: Color = Color(0x33FFFFFF),
    content: @Composable BoxScope.() -> Unit
) {
    Box(
        modifier = modifier
            .background(Color(0x2B1E293B), shape = RoundedCornerShape(16.dp))
            .border(1.dp, borderColor, shape = RoundedCornerShape(16.dp))
            .padding(16.dp),
        content = content
    )
}

@Composable
fun LiveClock() {
    var timeText by remember { mutableStateOf("MONDAY, JUNE 29, 2026 13:51") }
    LaunchedEffect(Unit) {
        while (true) {
            try {
                val cal = java.util.Calendar.getInstance()
                val sdf = java.text.SimpleDateFormat("EEEE, MMMM dd, yyyy HH:mm", java.util.Locale.ENGLISH)
                timeText = sdf.format(cal.time).uppercase()
            } catch (e: Exception) {
                // fallback
            }
            delay(1000)
        }
    }

    Box(
        modifier = Modifier
            .background(Color(0xFF120E33), shape = RoundedCornerShape(16.dp))
            .border(1.2.dp, Color(0xFF261F58), shape = RoundedCornerShape(16.dp))
            .padding(horizontal = 16.dp, vertical = 8.dp)
    ) {
        Text(
            text = timeText,
            color = Color.White,
            fontSize = 13.sp,
            fontWeight = FontWeight.ExtraBold,
            letterSpacing = 0.8.sp
        )
    }
}

@Composable
fun CarouselCard(
    title: String,
    description: String,
    icon: ImageVector,
    color: Color,
    onClick: () -> Unit
) {
    var isFocused by remember { mutableStateOf(false) }
    Card(
        colors = CardDefaults.cardColors(
            containerColor = if (isFocused) color.copy(alpha = 0.22f) else Color(0xFF161033)
        ),
        border = BorderStroke(
            width = if (isFocused) 2.dp else 1.5.dp,
            color = if (isFocused) color else Color(0xFF332766)
        ),
        shape = RoundedCornerShape(20.dp),
        modifier = Modifier
            .width(260.dp)
            .height(160.dp)
            .onFocusChanged { isFocused = it.isFocused }
            .tvFocusable(
                focusedColor = color,
                borderRadius = 20.dp,
                onClick = onClick
            )
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            verticalArrangement = Arrangement.SpaceBetween,
            horizontalAlignment = Alignment.Start
        ) {
            Box(
                modifier = Modifier
                    .size(42.dp)
                    .background(color.copy(alpha = 0.15f), shape = RoundedCornerShape(12.dp))
                    .border(1.5.dp, color.copy(alpha = 0.5f), shape = RoundedCornerShape(12.dp)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = title,
                    tint = color,
                    modifier = Modifier.size(22.dp)
                )
            }
            
            Column {
                Text(
                    text = title,
                    color = Color.White,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Black,
                    letterSpacing = 0.8.sp
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = description,
                    color = Color(0xFFA0A0C0),
                    fontSize = 11.5.sp,
                    fontWeight = FontWeight.SemiBold
                )
            }
        }
    }
}

@Composable
fun TvHomeScreen(viewModel: IptvViewModel) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 24.dp, vertical = 14.dp)
            .verticalScroll(rememberScrollState()),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Top row with Title and clock
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "PORTAL IP",
                        color = Color.White,
                        fontSize = 28.sp,
                        fontWeight = FontWeight.Black,
                        letterSpacing = 2.sp
                    )
                    Text(
                        text = "TV",
                        color = CeylanColor,
                        fontSize = 28.sp,
                        fontWeight = FontWeight.Black,
                        letterSpacing = 2.sp
                    )
                }
                Text(
                    text = "BIENVENUE SUR VOTRE PORTAIL MULTIMÉDIA",
                    color = Color(0xFF00E5FF),
                    fontSize = 11.5.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp
                )
            }

            // Dynamic Clock Top-Right
            LiveClock()
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Center Area: Welcome branding and visual carousel selector
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier
                .background(Color(0xFF161033), shape = RoundedCornerShape(14.dp))
                .border(1.5.dp, Color(0xFF00E5FF).copy(alpha = 0.6f), shape = RoundedCornerShape(14.dp))
                .padding(horizontal = 18.dp, vertical = 6.dp)
        ) {
            Icon(
                imageVector = Icons.Default.Tv,
                contentDescription = "Portal Logo",
                tint = Color(0xFF00E5FF),
                modifier = Modifier.size(24.dp)
            )
            Spacer(modifier = Modifier.width(10.dp))
            Column {
                Text(
                    text = "PORTAIL MULTIMÉDIA",
                    color = Color.White,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Black,
                    letterSpacing = 1.2.sp
                )
                Text(
                    text = "ACCÈS PREMIUM AUX CONTENUS",
                    color = CeylanColor,
                    fontSize = 8.5.sp,
                    fontWeight = FontWeight.Black,
                    letterSpacing = 0.5.sp
                )
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Carousel layout
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(18.dp, Alignment.CenterHorizontally),
            verticalAlignment = Alignment.CenterVertically
        ) {
            CarouselCard(
                title = "TÉLÉ LIVE",
                description = "Chaînes en direct",
                icon = Icons.Default.PlayArrow,
                color = Color(0xFF10B981),
                onClick = { viewModel.setScreen("Live") }
            )
            CarouselCard(
                title = "FILMS VOD",
                description = "Vidéoclub complet",
                icon = Icons.Default.Theaters,
                color = CeylanColor,
                onClick = { viewModel.setScreen("Movies") }
            )
            CarouselCard(
                title = "SÉRIES TV",
                description = "Saisons et épisodes",
                icon = Icons.Default.LiveTv,
                color = Color(0xFF8B5CF6),
                onClick = { viewModel.setScreen("Series") }
            )
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Continue Watching Section
        ContinueWatchingRow(viewModel = viewModel)
    }
}

@Composable
fun HorizontalCategoryBar(
    categories: List<String>,
    selectedCategory: String,
    onCategorySelected: (String) -> Unit
) {
    val listState = rememberLazyListState()
    val selectedIndex = remember(categories, selectedCategory) {
        categories.indexOfFirst { it.equals(selectedCategory, ignoreCase = true) }.coerceAtLeast(0)
    }

    LaunchedEffect(selectedIndex, selectedCategory) {
        if (categories.isNotEmpty() && selectedIndex in categories.indices) {
            listState.animateScrollToItem(selectedIndex)
        }
    }

    LazyRow(
        state = listState,
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp),
        horizontalArrangement = Arrangement.spacedBy(10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        items(categories, key = { it }) { category ->
            val isSelected = category.equals(selectedCategory, ignoreCase = true)
            val containerColor = if (isSelected) CeylanColor else Color(0xFF161033)
            val textColor = Color.White
            val borderColor = if (isSelected) CeylanColor else Color(0xFF332766)
            
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(16.dp))
                    .background(containerColor)
                    .border(
                        width = if (isSelected) 2.dp else 1.5.dp,
                        color = borderColor,
                        shape = RoundedCornerShape(16.dp)
                    )
                    .tvFocusable(
                        focusedColor = CeylanColor,
                        borderRadius = 16.dp,
                        onClick = { onCategorySelected(category) }
                    )
                    .padding(horizontal = 18.dp, vertical = 10.dp),
                contentAlignment = Alignment.Center
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    if (isSelected) {
                        Box(
                            modifier = Modifier
                                .size(8.dp)
                                .background(Color.White, shape = CircleShape)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                    }
                    Text(
                        text = category.uppercase(),
                        color = textColor,
                        fontSize = 12.sp,
                        fontWeight = if (isSelected) FontWeight.Black else FontWeight.Bold,
                        letterSpacing = 0.5.sp
                    )
                }
            }
        }
    }
}

@Composable
fun TvCategorySelectorPopup(
    categories: List<String> = emptyList(),
    onCategorySelected: (String) -> Unit,
    onDismiss: () -> Unit
) {
    val displayCategories = if (categories.isNotEmpty()) {
        categories
    } else {
        listOf("Tous", "SPORTS [EN]", "REALITY SHOWS [EN]", "DOCUMENTARY [EN]", "KIDS", "NEW ADDED [EN]")
    }
    
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .background(Color(0xE60F172A), shape = RoundedCornerShape(16.dp))
            .border(2.dp, Color(0xFF00E5FF), shape = RoundedCornerShape(16.dp))
            .padding(16.dp)
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                text = "FILTRER LES SÉLECTIONS",
                color = Color.White,
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.sp,
                modifier = Modifier.padding(bottom = 12.dp)
            )
            
            Column(
                modifier = Modifier.fillMaxWidth().verticalScroll(rememberScrollState()).heightIn(max = 350.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                displayCategories.forEach { cat ->
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(Color(0x33FFFFFF), shape = RoundedCornerShape(8.dp))
                            .tvFocusable(
                                focusedColor = Color(0xFF00E5FF),
                                borderRadius = 8.dp,
                                onClick = {
                                    val formattedCat = if (cat == "ALL" || cat == "Tous") "Tous" else cat
                                    onCategorySelected(formattedCat)
                                }
                            )
                            .padding(12.dp),
                        contentAlignment = Alignment.CenterStart
                    ) {
                        Text(
                            text = cat,
                            color = Color.White,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
            Spacer(modifier = Modifier.height(12.dp))
            Button(
                onClick = onDismiss,
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFEF4444)),
                modifier = Modifier.tvFocusable(
                    focusedColor = Color(0xFFEF4444),
                    borderRadius = 8.dp,
                    onClick = onDismiss
                )
            ) {
                Text("FERMER", color = Color.White, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
fun MagCategoryMenuPopup(
    categories: List<String>,
    selectedCategory: String,
    onCategorySelected: (String) -> Unit,
    onDismiss: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0x99000000))
            .clickable { onDismiss() },
        contentAlignment = Alignment.CenterStart
    ) {
        Box(
            modifier = Modifier
                .padding(start = 32.dp)
                .width(340.dp)
                .background(Color(0xFF090D16), shape = RoundedCornerShape(12.dp))
                .border(2.dp, Color(0xFF00E5FF), shape = RoundedCornerShape(12.dp))
                .clickable(enabled = false) {}
                .padding(16.dp)
        ) {
            Column {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "CATÉGORIES MAG / AURA",
                        color = Color(0xFF00E5FF),
                        fontSize = 14.sp,
                        fontWeight = FontWeight.ExtraBold,
                        letterSpacing = 1.5.sp
                    )
                    IconButton(
                        onClick = onDismiss,
                        modifier = Modifier.size(24.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Fermer",
                            tint = Color.Gray,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }
                
                Spacer(modifier = Modifier.height(12.dp))
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(1.dp)
                        .background(Color(0x22FFFFFF))
                )
                Spacer(modifier = Modifier.height(12.dp))
                
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .verticalScroll(rememberScrollState())
                        .heightIn(max = 350.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    categories.forEach { category ->
                        val isSelected = category.lowercase() == selectedCategory.lowercase()
                        var isFocused by remember { mutableStateOf(false) }
                        
                        val highlightWhite = isSelected || isFocused
                        val itemBgColor = if (highlightWhite) CeylanColor else Color.Transparent
                        val itemTextColor = Color.White
                        val itemBorderColor = if (isFocused) Color(0xFF00E5FF) else if (isSelected) CeylanColor else Color.Transparent
                        
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(itemBgColor, shape = RoundedCornerShape(6.dp))
                                .border(1.dp, itemBorderColor, shape = RoundedCornerShape(6.dp))
                                .onFocusChanged { isFocused = it.isFocused }
                                .tvFocusable(
                                    focusedColor = CeylanColor,
                                    borderRadius = 6.dp,
                                    onClick = {
                                        onCategorySelected(category)
                                        onDismiss()
                                    }
                                )
                                .padding(horizontal = 12.dp, vertical = 10.dp),
                            contentAlignment = Alignment.CenterStart
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text(
                                    text = category.uppercase(),
                                    color = itemTextColor,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold,
                                    letterSpacing = 0.5.sp
                                )
                                if (isSelected) {
                                    Icon(
                                        imageVector = Icons.Default.Check,
                                        contentDescription = "Selected",
                                        tint = Color.White,
                                        modifier = Modifier.size(14.dp)
                                    )
                                }
                            }
                        }
                    }
                }
                
                Spacer(modifier = Modifier.height(12.dp))
                
                Text(
                    text = "Utilisez ▲/▼ et OK pour choisir",
                    color = Color.Gray,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Medium,
                    modifier = Modifier.align(Alignment.CenterHorizontally)
                )
            }
        }
    }
}

@Composable
fun NorwayFlag(modifier: Modifier = Modifier) {
    Canvas(modifier = modifier.aspectRatio(11f / 8f)) {
        val w = size.width
        val h = size.height
        // Red background
        drawRect(color = Color(0xFFBA0C2F))
        
        // White cross
        val whiteW = w * 0.1818f
        val whiteH = h * 0.25f
        val crossX = w * 0.2727f // Nordic cross is offset to the left
        
        // vertical white
        drawRect(
            color = Color.White,
            topLeft = androidx.compose.ui.geometry.Offset(crossX, 0f),
            size = androidx.compose.ui.geometry.Size(whiteW, h)
        )
        // horizontal white
        drawRect(
            color = Color.White,
            topLeft = androidx.compose.ui.geometry.Offset(0f, (h - whiteH) / 2f),
            size = androidx.compose.ui.geometry.Size(w, whiteH)
        )
        
        // Blue cross (half size of white)
        val blueW = w * 0.0909f
        val blueH = h * 0.125f
        
        // vertical blue
        drawRect(
            color = Color(0xFF00205B),
            topLeft = androidx.compose.ui.geometry.Offset(crossX + (whiteW - blueW) / 2f, 0f),
            size = androidx.compose.ui.geometry.Size(blueW, h)
        )
        // horizontal blue
        drawRect(
            color = Color(0xFF00205B),
            topLeft = androidx.compose.ui.geometry.Offset(0f, (h - blueH) / 2f),
            size = androidx.compose.ui.geometry.Size(w, blueH)
        )
    }
}

@Composable
fun BrazilFlag(modifier: Modifier = Modifier) {
    Canvas(modifier = modifier.aspectRatio(11f / 8f)) {
        val w = size.width
        val h = size.height
        // Green background
        drawRect(color = Color(0xFF009739))
        
        // Yellow rhombus
        val path = androidx.compose.ui.graphics.Path().apply {
            moveTo(w / 2f, h * 0.1f) // Top
            lineTo(w * 0.9f, h / 2f) // Right
            lineTo(w / 2f, h * 0.9f) // Bottom
            lineTo(w * 0.1f, h / 2f) // Left
            close()
        }
        drawPath(path = path, color = Color(0xFFFEDF00))
        
        // Blue circle
        drawCircle(
            color = Color(0xFF002776),
            radius = h * 0.25f,
            center = androidx.compose.ui.geometry.Offset(w / 2f, h / 2f)
        )
        
        // White band
        val circleRadius = h * 0.25f
        drawArc(
            color = Color.White,
            startAngle = 160f,
            sweepAngle = 40f,
            useCenter = false,
            topLeft = androidx.compose.ui.geometry.Offset(w / 2f - circleRadius, h / 2f - circleRadius),
            size = androidx.compose.ui.geometry.Size(circleRadius * 2, circleRadius * 2),
            style = androidx.compose.ui.graphics.drawscope.Stroke(width = 2.dp.toPx())
        )
    }
}

@Composable
fun SoccerFieldSimulation(modifier: Modifier = Modifier) {
    Canvas(modifier = modifier) {
        val w = size.width
        val h = size.height
        
        // Green field gradient (resembling a grass field pitch)
        drawRect(
            brush = androidx.compose.ui.graphics.Brush.verticalGradient(
                colors = listOf(
                    Color(0xFF132D15).copy(alpha = 0.5f), // Dark forest green
                    Color(0xFF225227).copy(alpha = 0.85f), // Vibrant grass green
                    Color(0xFF0F3212).copy(alpha = 0.95f) // Deep pitch green
                )
            )
        )
        
        // Draw the white pitch markings (semi-transparent white)
        val linePaint = Color.White.copy(alpha = 0.35f)
        val strokeW = 2.dp.toPx()
        
        // Bottom boundary line
        drawLine(
            color = linePaint,
            start = androidx.compose.ui.geometry.Offset(0f, h - 2.dp.toPx()),
            end = androidx.compose.ui.geometry.Offset(w, h - 2.dp.toPx()),
            strokeWidth = strokeW
        )
        
        // Halfway or penalty box line
        drawLine(
            color = linePaint,
            start = androidx.compose.ui.geometry.Offset(w * 0.15f, 0f),
            end = androidx.compose.ui.geometry.Offset(w * 0.15f, h),
            strokeWidth = strokeW
        )
        
        // Center circle / Penalty arc
        drawArc(
            color = linePaint,
            startAngle = -90f,
            sweepAngle = 180f,
            useCenter = false,
            topLeft = androidx.compose.ui.geometry.Offset(w * 0.05f, h * 0.25f),
            size = androidx.compose.ui.geometry.Size(h * 0.5f, h * 0.5f),
            style = androidx.compose.ui.graphics.drawscope.Stroke(width = strokeW)
        )
    }
}

@Composable
fun BeInSportsLogo(modifier: Modifier = Modifier) {
    Row(
        modifier = modifier
            .background(
                brush = androidx.compose.ui.graphics.Brush.linearGradient(
                    colors = listOf(
                        Color(0xFF4A0E4E), // Deep purple
                        Color(0xFF8A1538), // Qatar/beIN Maroon/purple-pink
                        Color(0xFFD81B60)  // Pinkish magenta accent
                    )
                ),
                shape = RoundedCornerShape(6.dp)
            )
            .border(1.dp, Color.White.copy(alpha = 0.3f), shape = RoundedCornerShape(6.dp))
            .padding(horizontal = 8.dp, vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        Text(
            text = "beIN",
            color = Color.White,
            fontSize = 14.sp,
            fontWeight = FontWeight.ExtraBold,
            fontStyle = androidx.compose.ui.text.font.FontStyle.Italic,
            letterSpacing = (-0.5).sp
        )
        Text(
            text = "SPORTS",
            color = Color(0xFFE20074), // Bright purple/pink logo color
            fontSize = 11.sp,
            fontWeight = FontWeight.Black,
            letterSpacing = 0.5.sp
        )
    }
}

@Composable
fun LiveSportsTicker(modifier: Modifier = Modifier) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .background(Color(0xFF071A0E).copy(alpha = 0.9f)) // Dark green/black background
            .border(BorderStroke(1.dp, Color(0xFF133F23)), shape = RoundedCornerShape(4.dp))
            .padding(horizontal = 16.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        // News commentary / match information ticker
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            modifier = Modifier.weight(1f)
        ) {
            Box(
                modifier = Modifier
                    .background(Color(0xFFBA0C2F), shape = RoundedCornerShape(2.dp))
                    .padding(horizontal = 6.dp, vertical = 1.dp)
            ) {
                Text(
                    text = "COMMENTARY",
                    color = Color.White,
                    fontSize = 9.sp,
                    fontWeight = FontWeight.Bold
                )
            }
            
            Text(
                text = "🏆 FIFA WORLD CUP 2026 - ROUND OF 16: CANADA VS MOROCCO • LIVE MATCH COVERAGE • SPECTACULAR ATMOSPHERE IN THE STADIUM • REPLAYS OF GOALS IN THE NEWS BULLETIN COMING NEXT...",
                color = Color.White,
                fontSize = 12.sp,
                fontWeight = FontWeight.Medium,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}


@Composable
fun TvLiveSection(viewModel: IptvViewModel) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val playlistChannels by viewModel.channels.collectAsState()
    val selectedChannel by viewModel.selectedChannel.collectAsState()
    val selectedCategory by viewModel.selectedCategory.collectAsState()
    val isPlaying by viewModel.isPlaying.collectAsState()
    var searchQuery by remember { mutableStateOf("") }
    var showCategoryMenu by remember { mutableStateOf(false) }
    val isCategorySelected by viewModel.isLiveCategorySelected.collectAsState()
    val epgProgramsList by viewModel.epgProgramsList.collectAsState()
    val catchupEpg by viewModel.catchupEpg.collectAsState()
    
    var lastChannelClickTime by remember { mutableStateOf(0L) }
    var lastClickChannelUrl by remember { mutableStateOf("") }
    var showCatchupDialogForChannel by remember { mutableStateOf<ChannelItem?>(null) }
    
    if (showCategoryMenu) {
        BackHandler {
            showCategoryMenu = false
        }
    }

    var timeString by remember { mutableStateOf("19:22") }
    LaunchedEffect(Unit) {
        while (true) {
            val cal = java.util.Calendar.getInstance()
            val hour = String.format("%02d", cal.get(java.util.Calendar.HOUR_OF_DAY))
            val min = String.format("%02d", cal.get(java.util.Calendar.MINUTE))
            timeString = "$hour:$min"
            kotlinx.coroutines.delay(10000)
        }
    }

    val liveCategories = remember(playlistChannels) {
        val groups = playlistChannels.filter { it.type == "Live" }.map { it.groupName }.distinct().filter { it.isNotEmpty() }.sorted()
        listOf("Tous") + groups
    }

    val liveCategoryCounts = remember(playlistChannels) {
        val liveChannels = playlistChannels.filter { it.type == "Live" }
        val totalLive = liveChannels.size
        val map = mutableMapOf<String, Int>()
        map["Tous"] = totalLive
        for (ch in liveChannels) {
            val key = ch.groupName
            if (key.isNotEmpty()) {
                map[key] = (map[key] ?: 0) + 1
            }
        }
        map
    }

    val verticalMenuCategories = remember(liveCategories) {
        liveCategories
    }

    LaunchedEffect(liveCategories) {
        if (!liveCategories.contains(selectedCategory)) {
            val current = selectedChannel
            if (current != null && current.type == "Live" && liveCategories.contains(current.groupName)) {
                viewModel.selectCategory(current.groupName)
            } else if (liveCategories.isNotEmpty()) {
                viewModel.selectCategory(liveCategories.first())
            } else {
                viewModel.selectCategory("")
            }
        }
    }

    // Synchronize category with currently playing channel (e.g. after fullscreen zapping or channel change)
    LaunchedEffect(selectedChannel) {
        val current = selectedChannel
        if (current != null && current.type == "Live" && current.groupName.isNotBlank()) {
            if (selectedCategory != "Tous" && !selectedCategory.equals(current.groupName, ignoreCase = true) && liveCategories.contains(current.groupName)) {
                viewModel.selectCategory(current.groupName)
            }
        }
    }

    // Combine and apply category and search filters
    val displayedChannels = remember(playlistChannels, selectedCategory, searchQuery) {
        val list = playlistChannels.filter { it.type == "Live" }
        val categoryFiltered = if (selectedCategory.isEmpty() || selectedCategory == "Tous") {
            list
        } else {
            list.filter { it.groupName.equals(selectedCategory, ignoreCase = true) }
        }
        if (searchQuery.isEmpty()) {
            categoryFiltered
        } else {
            categoryFiltered.filter { it.name.lowercase().contains(searchQuery.lowercase().trim()) }
        }
    }

    // Select first channel ONLY when no channel is selected or when category changes and current channel does not exist in playlist
    LaunchedEffect(selectedCategory) {
        if (displayedChannels.isNotEmpty()) {
            val current = selectedChannel
            if (current == null || !displayedChannels.any { it.streamUrl == current.streamUrl }) {
                // If current channel belongs to another category and user explicitly changed category, select first channel of new category
                if (current == null || !playlistChannels.any { it.streamUrl == current.streamUrl }) {
                    val firstChan = displayedChannels.first()
                    if (isPlaying) {
                        viewModel.selectChannel(firstChan, keepFullScreen = false)
                    } else {
                        viewModel.selectChannelPreview(firstChan)
                    }
                }
            }
        }
    }

    LaunchedEffect(displayedChannels) {
        if (displayedChannels.isNotEmpty()) {
            val current = selectedChannel
            if (current == null) {
                val firstChan = displayedChannels.first()
                if (isPlaying) {
                    viewModel.selectChannel(firstChan, keepFullScreen = false)
                } else {
                    viewModel.selectChannelPreview(firstChan)
                }
            }
        }
    }

    val activeChannel = displayedChannels.find { it.streamUrl == selectedChannel?.streamUrl }
        ?: (if (selectedChannel != null && playlistChannels.any { it.streamUrl == selectedChannel?.streamUrl }) selectedChannel else displayedChannels.firstOrNull())

    val activeChannelIndex = remember(displayedChannels, activeChannel) {
        if (activeChannel != null) {
            displayedChannels.indexOfFirst { it.streamUrl == activeChannel.streamUrl }.coerceAtLeast(0)
        } else {
            0
        }
    }
    val totalRecords = displayedChannels.size
    val channelsPerPage = 12
    val currentPage = remember(activeChannelIndex, totalRecords) {
        if (totalRecords > 0) {
            (activeChannelIndex / channelsPerPage) + 1
        } else {
            1
        }
    }
    val totalPages = remember(totalRecords) {
        if (totalRecords > 0) {
            (totalRecords + channelsPerPage - 1) / channelsPerPage
        } else {
            1
        }
    }

    // Determine EPG Text dynamically from system time
    val currentCalendar = remember { java.util.Calendar.getInstance() }
    val currentHour = currentCalendar.get(java.util.Calendar.HOUR_OF_DAY)
    val currentMinute = currentCalendar.get(java.util.Calendar.MINUTE)

    val activeChannelEpg = remember(activeChannel, epgProgramsList, catchupEpg) {
        if (activeChannel == null) null
        else {
            val programs = if (epgProgramsList.isNotEmpty()) {
                epgProgramsList.map { item ->
                    EpgProgram(
                        title = item.name,
                        startTime = item.startTimeFormatted,
                        endTime = item.stopTimeFormatted,
                        description = item.description,
                        startHour = 0,
                        endHour = 0,
                        startTimestamp = item.startTimestamp,
                        endTimestamp = item.stopTimestamp,
                        realId = item.realId,
                        id = item.id,
                        markArchive = item.markArchive
                    )
                }
            } else if (catchupEpg.isNotEmpty()) {
                catchupEpg
            } else {
                getAutomaticEpgForChannel(activeChannel.name)
            }
            val nowMs = System.currentTimeMillis()
            val currentProg = programs.find { nowMs in (it.startTimestamp)..(it.endTimestamp - 1L) } ?: programs.find { currentHour >= it.startHour && currentHour < it.endHour } ?: programs.last()
            val nextProg = programs.find { it.startTimestamp >= currentProg.endTimestamp } ?: programs.find { it.startHour == (currentProg.endHour % 24) } ?: programs.first()
            val totalMs = if (currentProg.startTimestamp > 0L) currentProg.endTimestamp - currentProg.startTimestamp else (currentProg.endHour - currentProg.startHour) * 3600000L
            val elapsedMs = if (currentProg.startTimestamp > 0L) nowMs - currentProg.startTimestamp else ((currentHour - currentProg.startHour) * 60 + currentMinute) * 60000L
            val progress = if (totalMs > 0) (elapsedMs.toFloat() / totalMs.toFloat()).coerceIn(0f, 1f) else 0f
            Triple(currentProg, nextProg, progress)
        }
    }

    Box(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        if (playlistChannels.filter { it.type == "Live" }.isEmpty()) {
            Box(
                modifier = Modifier.fillMaxSize(),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        imageVector = Icons.Default.PlayArrow,
                        contentDescription = null,
                        tint = Color(0xFF00E5FF),
                        modifier = Modifier.size(64.dp)
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    Text(
                        text = "AUCUNE CHAÎNE LIVE DISPONIBLE",
                        color = Color.White,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Veuillez importer ou sélectionner un portail/playlist pour charger des chaînes.",
                        color = Color.Gray,
                        fontSize = 13.sp
                    )
                }
            }
        } else if (!isCategorySelected) {
            Column(modifier = Modifier.fillMaxSize()) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth().padding(bottom = 16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "TV EN DIRECT / CATÉGORIES",
                            color = Color.White,
                            fontSize = 24.sp,
                            fontWeight = FontWeight.Black,
                            letterSpacing = 1.sp
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = "Veuillez choisir une sous-catégorie pour voir les chaînes",
                            color = Color(0xFF00E5FF),
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    
                    LiveClock()
                }
                
                // Categories Grid
                val categoryGridState = androidx.compose.foundation.lazy.grid.rememberLazyGridState()
                val activeCategoryIdx = remember(liveCategories, selectedCategory) {
                    liveCategories.indexOfFirst { it.equals(selectedCategory, ignoreCase = true) }.coerceAtLeast(0)
                }
                LaunchedEffect(activeCategoryIdx, isCategorySelected) {
                    if (!isCategorySelected && liveCategories.isNotEmpty() && activeCategoryIdx in liveCategories.indices) {
                        categoryGridState.animateScrollToItem(activeCategoryIdx)
                    }
                }

                androidx.compose.foundation.lazy.grid.LazyVerticalGrid(
                    state = categoryGridState,
                    columns = androidx.compose.foundation.lazy.grid.GridCells.Adaptive(minSize = 220.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp),
                    horizontalArrangement = Arrangement.spacedBy(16.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    items(liveCategories, key = { it }) { category ->
                        val count = if (category.equals("Tous", ignoreCase = true)) liveCategoryCounts["Tous"] ?: 0 else liveCategoryCounts[category] ?: 0
                        val isSelected = category.equals(selectedCategory, ignoreCase = true)
                        val focusRequester = remember { FocusRequester() }

                        LaunchedEffect(isCategorySelected, isSelected) {
                            if (!isCategorySelected && isSelected) {
                                delay(60)
                                try {
                                    focusRequester.requestFocus()
                                } catch (e: Exception) {
                                    // ignore
                                }
                            }
                        }

                        val isTous = category.equals("Tous", ignoreCase = true)
                        val cardBg = when {
                            isSelected -> CeylanColor
                            isTous -> Color(0xFF22174B)
                            else -> Color(0xFF161033)
                        }
                        val cardBorder = if (isSelected) CeylanColor else Color(0xFF332766)
                        val textCol = Color.White
                        val subTextCol = if (isSelected) Color.White.copy(alpha = 0.9f) else CeylanColor
                        val iconTint = if (isSelected) Color.White else Color(0xFF00E5FF)

                        Card(
                            colors = CardDefaults.cardColors(containerColor = cardBg),
                            border = BorderStroke(if (isSelected) 2.dp else 1.5.dp, cardBorder),
                            shape = RoundedCornerShape(18.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(95.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .focusRequester(focusRequester)
                                    .tvFocusable(
                                        focusedColor = CeylanColor,
                                        borderRadius = 18.dp,
                                        onClick = {
                                            viewModel.selectCategory(category)
                                            viewModel.setLiveCategorySelected(true)
                                        }
                                    )
                                    .padding(16.dp),
                                contentAlignment = Alignment.CenterStart
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        modifier = Modifier.weight(1f)
                                    ) {
                                        Icon(
                                            imageVector = if (isTous) Icons.Default.FolderSpecial else Icons.Default.Folder,
                                            contentDescription = null,
                                            tint = iconTint,
                                            modifier = Modifier.size(32.dp)
                                        )
                                        Spacer(modifier = Modifier.width(14.dp))
                                        Column {
                                            Text(
                                                text = category.uppercase(),
                                                color = textCol,
                                                fontSize = 15.sp,
                                                fontWeight = FontWeight.Black,
                                                maxLines = 1,
                                                overflow = TextOverflow.Ellipsis
                                            )
                                            Spacer(modifier = Modifier.height(2.dp))
                                            Text(
                                                text = "$count CHAÎNES",
                                                color = subTextCol,
                                                fontSize = 11.sp,
                                                fontWeight = FontWeight.Bold
                                            )
                                        }
                                    }
                                    if (isSelected) {
                                        Box(
                                            modifier = Modifier
                                                .background(Color(0xFF0D1E3A), shape = RoundedCornerShape(6.dp))
                                                .border(1.dp, Color.White.copy(alpha = 0.6f), shape = RoundedCornerShape(6.dp))
                                                .padding(horizontal = 8.dp, vertical = 4.dp)
                                        ) {
                                            Text(
                                                text = "SÉLECTIONNÉ",
                                                color = Color.White,
                                                fontSize = 9.sp,
                                                fontWeight = FontWeight.Black
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        } else if (activeChannel != null) {
            Column {
                // Screen Header with Navigation Path & Back Button
                Row(
                    modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        Button(
                            onClick = {
                                viewModel.setLiveCategorySelected(false)
                            },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = Color(0xFF161033),
                                contentColor = Color.White
                            ),
                            border = BorderStroke(1.5.dp, Color(0xFF00E5FF)),
                            shape = RoundedCornerShape(12.dp),
                            contentPadding = PaddingValues(horizontal = 14.dp, vertical = 8.dp),
                            modifier = Modifier.tvFocusable(
                                focusedColor = CeylanColor,
                                borderRadius = 12.dp,
                                onClick = {
                                    viewModel.setLiveCategorySelected(false)
                                }
                            )
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.ArrowBack, contentDescription = "Retour", modifier = Modifier.size(16.dp), tint = Color(0xFF00E5FF))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("CATÉGORIES", fontSize = 11.5.sp, fontWeight = FontWeight.Black)
                            }
                        }
                        
                        Column {
                            Text(
                                text = "TV / ${selectedCategory.uppercase()}",
                                color = Color.White,
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Black,
                                letterSpacing = 0.5.sp
                            )
                            Text("ZAPPING LIVE TV", color = Color(0xFF00E5FF), fontSize = 10.5.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                    
                    LiveClock()
                }

                HorizontalCategoryBar(
                    categories = liveCategories,
                    selectedCategory = selectedCategory,
                    onCategorySelected = { viewModel.selectCategory(it) }
                )

                Row(modifier = Modifier.weight(1f)) {
                    // Left 46%: Vertical scrollable list with dynamic page footer
                    Column(
                        modifier = Modifier
                            .weight(0.46f)
                            .fillMaxHeight()
                    ) {
                        val hierarchicalItems = remember(displayedChannels) {
                            buildHierarchicalItems(displayedChannels)
                        }

                        val listState = rememberLazyListState()
                        val activeIndex = remember(hierarchicalItems, activeChannel) {
                            hierarchicalItems.indexOfFirst {
                                it is HierarchicalItem.ChannelRow && it.channel.streamUrl == activeChannel.streamUrl
                            }
                        }
                        LaunchedEffect(activeIndex) {
                            if (activeIndex >= 0) {
                                listState.animateScrollToItem(activeIndex)
                            }
                        }

                        LazyColumn(
                            state = listState,
                            modifier = Modifier
                                .weight(1f)
                                .fillMaxWidth()
                                .background(Color(0xFF161033), shape = RoundedCornerShape(16.dp))
                                .border(1.5.dp, Color(0xFF332766), shape = RoundedCornerShape(16.dp))
                                .padding(10.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            items(
                                hierarchicalItems,
                                key = { item ->
                                    when (item) {
                                        is HierarchicalItem.CategoryHeader -> "hdr_${item.name}_${item.level}"
                                        is HierarchicalItem.ChannelRow -> if (item.channel.id != 0L) "ch_${item.channel.id}" else "ch_url_${item.channel.streamUrl}_${item.index}"
                                    }
                                }
                            ) { item ->
                                when (item) {
                                    is HierarchicalItem.CategoryHeader -> {
                                        CategoryHeaderRow(item = item)
                                    }
                                    is HierarchicalItem.ChannelRow -> {
                                        ChannelItemRow(
                                            item = item,
                                            isSelected = activeChannel.streamUrl == item.channel.streamUrl,
                                            onFocus = { channel -> viewModel.selectChannelPreview(channel) },
                                            onClick = { channel ->
                                                val now = System.currentTimeMillis()
                                                val isDoubleTap = (now - lastChannelClickTime < 500) && (lastClickChannelUrl == channel.streamUrl)
                                                lastChannelClickTime = now
                                                lastClickChannelUrl = channel.streamUrl
                                                
                                                if (isDoubleTap) {
                                                    if (selectedChannel?.streamUrl == channel.streamUrl && isPlaying) {
                                                        viewModel.setFullScreen(true)
                                                    } else {
                                                        viewModel.selectChannel(channel, keepFullScreen = true)
                                                    }
                                                } else {
                                                    val isAlreadyPlaying = selectedChannel?.streamUrl == channel.streamUrl && isPlaying
                                                    if (isAlreadyPlaying) {
                                                        viewModel.setFullScreen(true)
                                                    } else {
                                                        viewModel.selectChannel(channel)
                                                    }
                                                }
                                            },
                                            onCatchupClick = { channel ->
                                                showCatchupDialogForChannel = channel
                                            }
                                        )
                                    }
                                }
                            }
                        }
                        
                        Spacer(modifier = Modifier.height(10.dp))
                        
                        // PAGE footer typical of set-top box EPG
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(Color(0xFF161033), shape = RoundedCornerShape(12.dp))
                                .border(1.5.dp, Color(0xFF332766), shape = RoundedCornerShape(12.dp))
                                .padding(horizontal = 14.dp, vertical = 10.dp),
                            contentAlignment = Alignment.CenterStart
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(8.dp)
                                        .background(Color(0xFF00E5FF), shape = CircleShape)
                                )
                                Text(
                                    text = "PAGE $currentPage FROM $totalPages, FOUND $totalRecords RECORDS",
                                    color = Color(0xFF00E5FF),
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Black,
                                    letterSpacing = 0.5.sp
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.width(16.dp))

                    // Right 54%: Live video preview window + EPG below
                    Column(
                        modifier = Modifier
                            .weight(0.54f)
                            .fillMaxHeight(),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        // Video Player Preview Window (Widescreen 16:9, fully enlarged)
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .aspectRatio(16f / 9f)
                                .background(Color.Black, shape = RoundedCornerShape(16.dp))
                                .border(2.dp, CeylanColor, shape = RoundedCornerShape(16.dp))
                                .tvFocusable(
                                    focusedColor = CeylanColor,
                                    borderRadius = 16.dp,
                                    onClick = { 
                                        if (activeChannel != null) {
                                            if (selectedChannel?.streamUrl == activeChannel.streamUrl && isPlaying) {
                                                viewModel.setFullScreen(true)
                                            } else {
                                                viewModel.selectChannel(activeChannel, keepFullScreen = true)
                                            }
                                        }
                                    }
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            val playbackUrl by viewModel.playbackUrl.collectAsState()
                            val headers by viewModel.playbackHeaders.collectAsState()
                            val isTimeshiftActive by viewModel.isTimeshiftActive.collectAsState()
                            val playbackErrorState by viewModel.playbackError.collectAsState()
                            val playbackLoading by viewModel.playbackLoading.collectAsState()
                            
                            if (playbackUrl != null) {
                                SimpleVideoPlayer(streamUrl = playbackUrl!!, headers = headers, isMuted = false, viewModel = viewModel)
                            } else if (isTimeshiftActive) {
                                Box(
                                    modifier = Modifier
                                        .fillMaxSize()
                                        .background(Color(0xFF0B0E14)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    if (playbackLoading) {
                                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                            CircularProgressIndicator(color = Color(0xFF00E5FF), modifier = Modifier.size(28.dp))
                                            Spacer(modifier = Modifier.height(8.dp))
                                            Text("Chargement du replay...", color = Color.White, fontSize = 12.sp)
                                        }
                                    } else {
                                        Column(
                                            horizontalAlignment = Alignment.CenterHorizontally,
                                            modifier = Modifier.padding(12.dp)
                                        ) {
                                            Icon(
                                                imageVector = Icons.Default.Warning,
                                                contentDescription = null,
                                                tint = Color(0xFFEF4444),
                                                modifier = Modifier.size(28.dp)
                                            )
                                            Spacer(modifier = Modifier.height(6.dp))
                                            Text(
                                                text = "Programme indisponible en replay",
                                                color = Color.White,
                                                fontSize = 13.sp,
                                                fontWeight = FontWeight.Bold,
                                                textAlign = TextAlign.Center
                                            )
                                            Spacer(modifier = Modifier.height(4.dp))
                                            Text(
                                                text = playbackErrorState ?: "Ce flux d'archive n'est pas accessible.",
                                                color = Color(0xFF9CA3AF),
                                                fontSize = 11.sp,
                                                textAlign = TextAlign.Center
                                            )
                                            Spacer(modifier = Modifier.height(8.dp))
                                            Button(
                                                onClick = { viewModel.stopTimeshift() },
                                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF00E5FF)),
                                                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                                                shape = RoundedCornerShape(6.dp)
                                            ) {
                                                Text("REVENIR AU DIRECT", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                            }
                                        }
                                    }
                                }
                            } else if (playbackErrorState != null) {
                                Box(
                                    modifier = Modifier
                                        .fillMaxSize()
                                        .background(Color(0xFF0B0E14)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                        Icon(Icons.Default.Warning, contentDescription = null, tint = Color(0xFFEF4444), modifier = Modifier.size(28.dp))
                                        Spacer(modifier = Modifier.height(4.dp))
                                        Text(playbackErrorState ?: "Flux indisponible", color = Color.White, fontSize = 12.sp, textAlign = TextAlign.Center)
                                    }
                                }
                            } else if (playbackLoading) {
                                Box(
                                    modifier = Modifier
                                        .fillMaxSize()
                                        .background(Color.Black),
                                    contentAlignment = Alignment.Center
                                ) {
                                    CircularProgressIndicator(color = Color(0xFF00E5FF), modifier = Modifier.size(28.dp))
                                }
                            } else {
                                SimpleVideoPlayer(streamUrl = activeChannel.streamUrl, headers = emptyMap(), isMuted = false, viewModel = viewModel)
                            }


                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        // EPG details card
                        Card(
                            modifier = Modifier
                                .weight(1f)
                                .fillMaxWidth(),
                            colors = CardDefaults.cardColors(containerColor = Color(0xFF161033)),
                            border = BorderStroke(1.5.dp, Color(0xFF332766)),
                            shape = RoundedCornerShape(16.dp)
                        ) {
                            Column(modifier = Modifier.padding(14.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Box(
                                        modifier = Modifier
                                            .background(CeylanColor, shape = RoundedCornerShape(6.dp))
                                            .padding(horizontal = 9.dp, vertical = 4.dp)
                                    ) {
                                        Text("PROGRAM GUIDE", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Black)
                                    }
                                    Spacer(modifier = Modifier.width(10.dp))
                                    Text(activeChannel.name.uppercase(), color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Black, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                }
                                Spacer(modifier = Modifier.height(10.dp))
                                
                                val isTimeshiftActive by viewModel.isTimeshiftActive.collectAsState()
                                val currentTimeshiftProgram by viewModel.currentTimeshiftProgram.collectAsState()
                                
                                val epgList by viewModel.epgProgramsList.collectAsState()
                                val catchupList by viewModel.catchupEpg.collectAsState()
                                val programs = remember(activeChannel, epgList, catchupList) {
                                    val rawList = if (epgList.isNotEmpty()) {
                                        epgList.map { item ->
                                            EpgProgram(
                                                title = item.name,
                                                startTime = item.startTimeFormatted,
                                                endTime = item.stopTimeFormatted,
                                                description = item.description,
                                                startHour = 0,
                                                endHour = 0,
                                                startTimestamp = item.startTimestamp,
                                                endTimestamp = item.stopTimestamp,
                                                realId = item.realId,
                                                id = item.id,
                                                markArchive = item.markArchive
                                            )
                                        }
                                    } else if (catchupList.isNotEmpty()) {
                                        catchupList
                                    } else {
                                        getAutomaticEpgForChannel(activeChannel.name)
                                    }
                                    rawList.sortedBy { p ->
                                        if (p.startTimestamp > 0L) p.startTimestamp else (p.startHour * 3600).toLong()
                                    }
                                }
                                val currentHour = remember { java.util.Calendar.getInstance().get(java.util.Calendar.HOUR_OF_DAY) }
                                val currentMinute = remember { java.util.Calendar.getInstance().get(java.util.Calendar.MINUTE) }
                                
                                if (isTimeshiftActive && currentTimeshiftProgram != null) {
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .background(Color(0xFF22174B), shape = RoundedCornerShape(10.dp))
                                            .border(1.5.dp, CeylanColor, shape = RoundedCornerShape(10.dp))
                                            .padding(10.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Column(modifier = Modifier.weight(1f)) {
                                            Text(
                                                text = "🔴 TIMESHIFT EN COURS",
                                                color = Color.White,
                                                fontSize = 11.sp,
                                                fontWeight = FontWeight.Black
                                            )
                                            Text(
                                                text = currentTimeshiftProgram!!.title,
                                                color = Color.White,
                                                fontSize = 13.sp,
                                                fontWeight = FontWeight.Black,
                                                maxLines = 1,
                                                overflow = TextOverflow.Ellipsis
                                            )
                                            Text(
                                                text = "Replay de ${currentTimeshiftProgram!!.startTime} à ${currentTimeshiftProgram!!.endTime}",
                                                color = Color(0xFFA0A0C0),
                                                fontSize = 10.5.sp,
                                                fontWeight = FontWeight.SemiBold
                                            )
                                        }
                                        Button(
                                            onClick = { viewModel.stopTimeshift() },
                                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF00E5FF)),
                                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                                            shape = RoundedCornerShape(8.dp),
                                            modifier = Modifier.tvFocusable(onClick = { viewModel.stopTimeshift() })
                                        ) {
                                            Icon(
                                                imageVector = Icons.Default.PlayArrow,
                                                contentDescription = null,
                                                tint = Color.White,
                                                modifier = Modifier.size(14.dp)
                                            )
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Text("DIRECT", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Black)
                                        }
                                    }
                                    Spacer(modifier = Modifier.height(12.dp))
                                }
                                
                                Text(
                                    text = "PROGRAMMES DU JOUR",
                                    color = Color(0xFFA0A0C0),
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Black,
                                    letterSpacing = 0.5.sp
                                )
                                Spacer(modifier = Modifier.height(6.dp))
                                
                                LazyColumn(
                                    modifier = Modifier.fillMaxWidth().weight(1f),
                                    verticalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    items(programs, key = { "${it.title}_${it.startTimestamp}_${it.startHour}" }) { prog ->
                                        val isArchiveAvailable = true
                                        val nowSecs = System.currentTimeMillis() / 1000L
                                        val isCurrent = if (prog.startTimestamp > 0L) {
                                            nowSecs in (prog.startTimestamp / 1000L)..(prog.endTimestamp / 1000L)
                                        } else {
                                            currentHour >= prog.startHour && currentHour < prog.endHour
                                        }
                                        val isFuture = if (prog.startTimestamp > 0L) {
                                            (prog.startTimestamp / 1000L) > nowSecs
                                        } else {
                                            !isCurrent && prog.startHour > currentHour
                                        }
                                        val isPast = if (prog.startTimestamp > 0L) {
                                            (prog.endTimestamp / 1000L) <= nowSecs
                                        } else {
                                            !isCurrent && !isFuture
                                        }
                                        
                                        val bgSelected = isCurrent || (isTimeshiftActive && currentTimeshiftProgram?.title == prog.title)
                                        val itemAlpha = if (!isArchiveAvailable && isPast) 0.4f else if (isFuture) 0.6f else 1f
                                        
                                        val actionClick = {
                                            when {
                                                isPast && isArchiveAvailable -> {
                                                    viewModel.playCatchupProgram(
     channel = activeChannel,
                                                        program = EpgProgramItem(
                                                            name = prog.title,
                                                            description = prog.description,
                                                            startTimestamp = prog.startTimestamp,
                                                            stopTimestamp = prog.endTimestamp,
                                                            startTimeFormatted = prog.startTime,
                                                            stopTimeFormatted = prog.endTime,
                                                            realId = prog.realId,
                                                            id = prog.id,
                                                            markArchive = 1
                                                        )
                                                    )
                                                }
                                                isCurrent -> {
                                                    viewModel.stopTimeshift()
                                                    if (selectedChannel?.streamUrl != activeChannel.streamUrl) {
                                                        viewModel.selectChannel(activeChannel)
                                                    }
                                                }
                                                else -> {}
                                            }
                                        }

                                        Row(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .alpha(itemAlpha)
                                                .background(
                                                    if (bgSelected) Color(0xFF00E5FF).copy(alpha = 0.16f)
                                                    else Color(0xFF0B0726).copy(alpha = 0.6f),
                                                    shape = RoundedCornerShape(8.dp)
                                                )
                                                .border(
                                                    1.dp,
                                                    if (bgSelected) Color(0xFF00E5FF) else Color(0xFF332766),
                                                    shape = RoundedCornerShape(8.dp)
                                                )
                                                .tvFocusable(
                                                    focusedColor = CeylanColor,
                                                    borderRadius = 8.dp,
                                                    onClick = actionClick
                                                )
                                                .clickable { actionClick() }
                                                .padding(horizontal = 10.dp, vertical = 7.dp),
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.SpaceBetween
                                        ) {
                                            Column(modifier = Modifier.weight(1f)) {
                                                Row(verticalAlignment = Alignment.CenterVertically) {
                                                    Text(
                                                        text = "${prog.startTime} - ${prog.endTime}",
                                                        color = if (bgSelected) Color(0xFF00E5FF) else Color(0xFFA0A0C0),
                                                        fontSize = 11.sp,
                                                        fontWeight = FontWeight.Black
                                                    )
                                                    if (isCurrent) {
                                                        Spacer(modifier = Modifier.width(6.dp))
                                                        Box(
                                                            modifier = Modifier
                                                                .background(Color(0xFFEF4444), shape = RoundedCornerShape(4.dp))
                                                                .padding(horizontal = 5.dp, vertical = 2.dp)
                                                        ) {
                                                            Text("EN DIRECT", color = Color.White, fontSize = 8.sp, fontWeight = FontWeight.Black)
                                                        }
                                                    }
                                                }
                                                Text(
                                                    text = prog.title,
                                                    color = Color.White,
                                                    fontSize = 12.5.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    maxLines = 1,
                                                    overflow = TextOverflow.Ellipsis
                                                )
                                            }

                                            if (isPast && isArchiveAvailable) {
                                                Icon(
                                                    imageVector = Icons.Default.PlayArrow,
                                                    contentDescription = "Replay",
                                                    tint = Color(0xFF00E5FF),
                                                    modifier = Modifier.size(16.dp)
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        if (showCategoryMenu) {
            MagCategoryMenuPopup(
                categories = verticalMenuCategories,
                selectedCategory = selectedCategory,
                onCategorySelected = { cat ->
                    viewModel.selectCategory(cat)
                    showCategoryMenu = false
                },
                onDismiss = { showCategoryMenu = false }
            )
        }

        if (showCatchupDialogForChannel != null) {
            CatchupProgramsDialog(
                channel = showCatchupDialogForChannel!!,
                viewModel = viewModel,
                onDismiss = { showCatchupDialogForChannel = null }
            )
        }
    }
}

data class CatchupDateItem(
    val label: String,
    val subLabel: String,
    val isoDate: String
)

@Composable
fun CatchupProgramsDialog(
    channel: ChannelItem,
    viewModel: IptvViewModel,
    onDismiss: () -> Unit,
    onProgramPlayed: (() -> Unit)? = null
) {
    val catchupList by viewModel.catchupEpg.collectAsState()
    val loadingCatchup by viewModel.loadingCatchupEpg.collectAsState()
    val catchupError by viewModel.catchupError.collectAsState()

    val dateItems = remember {
        val list = mutableListOf<CatchupDateItem>()
        val cal = java.util.Calendar.getInstance()
        val sdfIso = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US)
        val sdfDisplay = java.text.SimpleDateFormat("EEE dd/MM", java.util.Locale.FRENCH)
        val sdfShort = java.text.SimpleDateFormat("dd/MM", java.util.Locale.FRENCH)

        for (i in 0..7) {
            val iso = sdfIso.format(cal.time)
            val shortDate = sdfShort.format(cal.time)
            val label = when (i) {
                0 -> "Aujourd'hui"
                1 -> "Hier"
                else -> sdfDisplay.format(cal.time).replaceFirstChar { if (it.isLowerCase()) it.titlecase(java.util.Locale.FRENCH) else it.toString() }
            }
            list.add(CatchupDateItem(label = label, subLabel = shortDate, isoDate = iso))
            cal.add(java.util.Calendar.DAY_OF_YEAR, -1)
        }
        list
    }

    var selectedDateIndex by remember { mutableIntStateOf(0) }
    val selectedDate = dateItems.getOrElse(selectedDateIndex) { dateItems.first() }

    LaunchedEffect(selectedDate.isoDate, channel) {
        viewModel.loadEpgForDate(channel, selectedDate.isoDate)
    }

    val programs = remember(catchupList) {
        if (catchupList.isNotEmpty()) catchupList
        else emptyList()
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color(0xEE080516))
                .clickable { onDismiss() },
            contentAlignment = Alignment.Center
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth(0.92f)
                    .fillMaxHeight(0.90f)
                    .background(Color(0xFF161033), shape = RoundedCornerShape(18.dp))
                    .border(2.dp, Color(0xFF332766), shape = RoundedCornerShape(18.dp))
                    .clickable(enabled = false) {}
                    .padding(22.dp)
            ) {
            Column(modifier = Modifier.fillMaxSize()) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .background(CeylanColor, shape = RoundedCornerShape(6.dp))
                                .padding(horizontal = 10.dp, vertical = 4.dp)
                        ) {
                            Text("REPLAY / ARCHIVES EPG", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Black)
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Text(
                            text = channel.name,
                            color = Color.White,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Black
                        )
                    }
                    IconButton(onClick = onDismiss) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Fermer",
                            tint = Color.White
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Date selector tabs (Aujourd'hui, Hier, J-2, J-3, ...)
                Text(
                    text = "CHOISIR UNE DATE :",
                    color = Color(0xFFA0A0C0),
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Black,
                    letterSpacing = 0.5.sp
                )
                Spacer(modifier = Modifier.height(6.dp))
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    itemsIndexed(dateItems) { index, item ->
                        val isDateSelected = index == selectedDateIndex
                        Box(
                            modifier = Modifier
                                .background(
                                    if (isDateSelected) CeylanColor else Color(0xFF0F0B24),
                                    shape = RoundedCornerShape(10.dp)
                                )
                                .border(
                                    1.dp,
                                    if (isDateSelected) CeylanColor else Color(0xFF332766),
                                    shape = RoundedCornerShape(10.dp)
                                )
                                .tvFocusable(
                                    focusedColor = Color(0xFF00E5FF),
                                    borderRadius = 10.dp,
                                    onClick = { selectedDateIndex = index }
                                )
                                .clickable { selectedDateIndex = index }
                                .padding(horizontal = 14.dp, vertical = 8.dp)
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(
                                    text = item.label,
                                    color = Color.White,
                                    fontSize = 14.sp,
                                    fontWeight = if (isDateSelected) FontWeight.Black else FontWeight.Bold
                                )
                                Text(
                                    text = item.subLabel,
                                    color = if (isDateSelected) Color.White.copy(alpha = 0.85f) else Color(0xFFA0A0C0),
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.SemiBold
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Main content
                if (loadingCatchup) {
                    Box(modifier = Modifier.fillMaxSize().weight(1f), contentAlignment = Alignment.Center) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            CircularProgressIndicator(color = CeylanColor, modifier = Modifier.size(36.dp))
                            Spacer(modifier = Modifier.height(12.dp))
                            Text(
                                text = "Chargement des archives pour ${selectedDate.label}...",
                                color = Color(0xFFA0A0C0),
                                fontSize = 14.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }
                } else if (programs.isEmpty()) {
                    Box(modifier = Modifier.fillMaxSize().weight(1f), contentAlignment = Alignment.Center) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(
                                text = if (catchupError != null) catchupError!! else "Aucun programme d'archive disponible pour ${selectedDate.label}",
                                color = Color(0xFFA0A0C0),
                                fontSize = 15.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                            Spacer(modifier = Modifier.height(12.dp))
                            Button(
                                onClick = { viewModel.loadEpgForDate(channel, selectedDate.isoDate, forceRefresh = true) },
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF00E5FF)),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Text("RÉESSAYER", color = Color.White, fontWeight = FontWeight.Black)
                            }
                        }
                    }
                } else {
                    LazyColumn(
                        modifier = Modifier.fillMaxWidth().weight(1f),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items(programs) { prog ->
                            val nowSecs = System.currentTimeMillis() / 1000L
                            val isCurrent = if (prog.startTimestamp > 0L) {
                                nowSecs in (prog.startTimestamp / 1000L)..(prog.endTimestamp / 1000L)
                            } else false
                            val isPast = if (prog.startTimestamp > 0L) {
                                (prog.endTimestamp / 1000L) <= nowSecs
                            } else true

                            val onPlayAction = {
                                viewModel.playCatchupProgram(
                                    channel = channel,
                                    program = EpgProgramItem(
                                        name = prog.title,
                                        description = prog.description,
                                        startTimestamp = prog.startTimestamp,
                                        stopTimestamp = prog.endTimestamp,
                                        startTimeFormatted = prog.startTime,
                                        stopTimeFormatted = prog.endTime,
                                        realId = prog.realId,
                                        id = prog.id,
                                        markArchive = 1
                                    )
                                )
                                onProgramPlayed?.invoke()
                                onDismiss()
                            }

                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(Color(0xFF0F0B24), shape = RoundedCornerShape(10.dp))
                                    .border(1.dp, Color(0xFF332766), shape = RoundedCornerShape(10.dp))
                                    .tvFocusable(
                                        focusedColor = CeylanColor,
                                        borderRadius = 10.dp,
                                        onClick = onPlayAction
                                    )
                                    .clickable { onPlayAction() }
                                    .padding(14.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text(
                                            text = "${prog.startTime} - ${prog.endTime}",
                                            color = Color(0xFF00E5FF),
                                            fontSize = 16.sp,
                                            fontWeight = FontWeight.Black
                                        )
                                        if (isCurrent) {
                                            Spacer(modifier = Modifier.width(8.dp))
                                            Box(
                                                modifier = Modifier
                                                    .background(Color(0xFFEF4444), shape = RoundedCornerShape(4.dp))
                                                    .padding(horizontal = 8.dp, vertical = 3.dp)
                                            ) {
                                                Text("EN DIRECT", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Black)
                                            }
                                        } else if (isPast) {
                                            Spacer(modifier = Modifier.width(8.dp))
                                            Box(
                                                modifier = Modifier
                                                    .background(Color(0xFF10B981), shape = RoundedCornerShape(4.dp))
                                                    .padding(horizontal = 8.dp, vertical = 3.dp)
                                            ) {
                                                Text("REPLAY DISPONIBLE", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Black)
                                            }
                                        }
                                    }
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        text = prog.title,
                                        color = Color.White,
                                        fontSize = 20.sp,
                                        fontWeight = FontWeight.Black
                                    )
                                    if (prog.description.isNotBlank()) {
                                        Spacer(modifier = Modifier.height(4.dp))
                                        Text(
                                            text = prog.description,
                                            color = Color(0xFFD1D5DB),
                                            fontSize = 15.sp,
                                            fontWeight = FontWeight.Medium,
                                            maxLines = 4,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                    }
                                }

                                Spacer(modifier = Modifier.width(12.dp))

                                Button(
                                    onClick = onPlayAction,
                                    colors = ButtonDefaults.buttonColors(containerColor = if (isCurrent) Color(0xFFEF4444) else Color(0xFF00E5FF)),
                                    shape = RoundedCornerShape(8.dp),
                                    contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.PlayArrow,
                                        contentDescription = null,
                                        tint = Color.White,
                                        modifier = Modifier.size(18.dp)
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        if (isCurrent) "DIRECT" else "REJOUER",
                                        color = Color.White,
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Black
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
}


fun extractPortalUrl(rawText: String): String? {
    val trimmed = rawText.trim()
    val urlRegex = Regex("""(https?://[^\s"'<>]+)""", RegexOption.IGNORE_CASE)
    val match = urlRegex.find(trimmed)
    return match?.value
}

fun extractMacAddress(rawText: String): String? {
    val macRegex = Regex("""([0-9A-Fa-f]{2}[:-]){5}([0-9A-Fa-f]{2})""")
    val match = macRegex.find(rawText)
    return match?.value
}

fun extractIpAddress(rawText: String): String? {
    val ipRegex = Regex("""\b(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\b""")
    val match = ipRegex.find(rawText)
    return match?.value
}

@Composable
fun ResumePlaybackDialog(
    data: IptvViewModel.ResumeDialogData,
    onDismiss: () -> Unit
) {
    val wp = data.watchProgress
    val posSec = wp.positionMs / 1000
    val min = posSec / 60
    val sec = posSec % 60
    val hours = min / 60
    val remainingMin = min % 60
    val timeFormatted = if (hours > 0) {
        String.format("%02d:%02d:%02d", hours, remainingMin, sec)
    } else {
        String.format("%02d:%02d", remainingMin, sec)
    }

    val resumeFocusRequester = remember { FocusRequester() }
    LaunchedEffect(Unit) {
        try {
            resumeFocusRequester.requestFocus()
        } catch (_: Exception) {}
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Icon(Icons.Default.PlayCircle, contentDescription = null, tint = Color(0xFF00E5FF))
                Text(
                    text = "Reprendre la lecture",
                    color = Color(0xFF00E5FF),
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp
                )
            }
        },
        text = {
            Column {
                Text(
                    text = wp.title,
                    color = Color.White,
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 15.sp
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "Vous vous êtes arrêté à $timeFormatted. Souhaitez-vous reprendre là où vous vous êtes arrêté ou recommencer depuis le début ?",
                    color = Color(0xFFCBD5E1),
                    fontSize = 13.5.sp
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    data.onResume()
                    onDismiss()
                },
                modifier = Modifier
                    .focusRequester(resumeFocusRequester)
                    .tvFocusable(
                        focusedColor = Color(0xFF00E5FF),
                        borderRadius = 8.dp,
                        onClick = {
                            data.onResume()
                            onDismiss()
                        }
                    ),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF00E5FF))
            ) {
                Icon(Icons.Default.PlayArrow, contentDescription = null, tint = Color.Black, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("Reprendre ($timeFormatted)", color = Color.Black, fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            OutlinedButton(
                onClick = {
                    data.onRestart()
                    onDismiss()
                },
                modifier = Modifier
                    .tvFocusable(
                        focusedColor = Color(0xFFFFD600),
                        borderRadius = 8.dp,
                        onClick = {
                            data.onRestart()
                            onDismiss()
                        }
                    ),
                border = BorderStroke(1.dp, Color(0xFFE2E8F0).copy(alpha = 0.4f)),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White)
            ) {
                Icon(Icons.Default.Refresh, contentDescription = null, tint = Color.White, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("Recommencer au début", color = Color.White, fontWeight = FontWeight.SemiBold)
            }
        },
        containerColor = Color(0xFF1E293B)
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LiveTvSubtitleSettingsDialog(
    viewModel: IptvViewModel,
    onDismiss: () -> Unit
) {
    val subtitlesEnabled by viewModel.subtitlesEnabled.collectAsState()
    val subtitleTranslationEnabled by viewModel.subtitleTranslationEnabled.collectAsState()
    val subtitleTargetLanguage by viewModel.subtitleTargetLanguage.collectAsState()
    val voiceSubtitlesEnabled by viewModel.voiceSubtitlesEnabled.collectAsState()
    val voiceSubtitleLanguage by viewModel.voiceSubtitleLanguage.collectAsState()
    val liveVoiceSourceLang by viewModel.liveVoiceSourceLang.collectAsState()
    val liveVoiceTargetLang by viewModel.liveVoiceTargetLang.collectAsState()
    val subtitleStyleMode by viewModel.subtitleStyleMode.collectAsState()
    val subtitleSizeState by viewModel.subtitleSizeState.collectAsState()

    val voiceSubtitleAutoCalibration by viewModel.voiceSubtitleAutoCalibration.collectAsState()
    val autoCalibratedOffsetMs by viewModel.autoCalibratedOffsetMs.collectAsState()
    val voiceSubtitleSyncOffsetMs by viewModel.voiceSubtitleSyncOffsetMs.collectAsState()
    val voiceSubtitleAutoDuration by viewModel.voiceSubtitleAutoDuration.collectAsState()
    val voiceSubtitleClearDelaySeconds by viewModel.voiceSubtitleClearDelaySeconds.collectAsState()

    val isDownloadingModel by com.example.data.SherpaSubtitleManager.isDownloadingModel.collectAsState()
    val downloadProgress by com.example.data.SherpaSubtitleManager.downloadProgress.collectAsState()
    val downloadStatusMessage by com.example.data.SherpaSubtitleManager.downloadStatusMessage.collectAsState()
    val isSpeechDetected by com.example.data.SherpaSubtitleManager.isSpeechDetected.collectAsState()

    val supportedLanguages = listOf(
        "fr" to "Français",
        "ar" to "Arabe",
        "en" to "Anglais",
        "es" to "Espagnol",
        "de" to "Allemand",
        "it" to "Italien",
        "ru" to "Russe",
        "pt" to "Portugais",
        "tr" to "Turc"
    )

    val styleOptions = listOf(
        "Vert néon (#00FF66)" to Color(0xFF00FF66),
        "Cyan (#00E5FF)" to Color(0xFF00E5FF),
        "Jaune classique" to Color(0xFFFFE000),
        "Blanc sur noir" to Color.White,
        "Bande blanche, texte noir" to Color.Black
    )

    val sizeOptions = listOf("Petit", "Moyen", "Grand", "Très Grand")

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(
            usePlatformDefaultWidth = false,
            dismissOnBackPress = true,
            dismissOnClickOutside = true
        )
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.Black.copy(alpha = 0.75f))
                .clickable(onClick = onDismiss),
            contentAlignment = Alignment.Center
        ) {
            Surface(
                modifier = Modifier
                    .widthIn(min = 320.dp, max = 640.dp)
                    .fillMaxHeight(0.92f)
                    .padding(horizontal = 16.dp, vertical = 12.dp)
                    .clickable(enabled = false) { /* stop scrim dismiss */ },
                shape = RoundedCornerShape(16.dp),
                color = Color(0xFF0F172A),
                border = BorderStroke(1.5.dp, Color(0xFF00E5FF).copy(alpha = 0.6f)),
                shadowElevation = 24.dp
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 20.dp, vertical = 14.dp)
                ) {
                    // En-tête
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Icon(Icons.Default.Subtitles, contentDescription = null, tint = Color(0xFF00E5FF), modifier = Modifier.size(22.dp))
                            Text(
                                text = "Sous-titres & Vocal TV",
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                fontSize = 17.sp
                            )
                        }
                        IconButton(
                            onClick = onDismiss,
                            modifier = Modifier
                                .size(36.dp)
                                .tvFocusable(onClick = onDismiss)
                        ) {
                            Icon(Icons.Default.Close, contentDescription = "Fermer", tint = Color.LightGray)
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f, fill = false)
                            .verticalScroll(rememberScrollState()),
                        verticalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        // 1. Boutons de Test Réel en Direct
                        Card(
                            colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B)),
                            border = BorderStroke(1.dp, Color(0xFF00E5FF).copy(alpha = 0.5f)),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(
                                modifier = Modifier.padding(12.dp),
                                verticalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                    Icon(Icons.Default.Bolt, contentDescription = null, tint = Color(0xFF00E5FF), modifier = Modifier.size(18.dp))
                                    Text(
                                        text = "TEST EN TEMPS RÉEL SUR LE FLUX EN COURS",
                                        color = Color(0xFF00E5FF),
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                                Text(
                                    text = if (subtitleTranslationEnabled) "ℹ️ Traduction activée : Seul le sous-titre traduit s'affiche sur la vidéo (original masqué)." else "ℹ️ Visualisez immédiatement le style et la taille choisis sur la vidéo.",
                                    color = if (subtitleTranslationEnabled) Color(0xFF10B981) else Color(0xFF94A3B8),
                                    fontSize = 11.sp
                                )
                                Row(
                                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Button(
                                        onClick = { viewModel.triggerSubtitlePreviewTest() },
                                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2563EB)),
                                        shape = RoundedCornerShape(8.dp),
                                        modifier = Modifier
                                            .weight(1f)
                                            .tvFocusable(onClick = { viewModel.triggerSubtitlePreviewTest() })
                                    ) {
                                        Text("⚡ Aperçu Style TV", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                    }
                                    Button(
                                        onClick = { viewModel.triggerVoiceSubtitleSimulationTest() },
                                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF10B981)),
                                        shape = RoundedCornerShape(8.dp),
                                        modifier = Modifier
                                            .weight(1f)
                                            .tvFocusable(onClick = { viewModel.triggerVoiceSubtitleSimulationTest() })
                                    ) {
                                        Text("🎙️ Aperçu Vocal IA", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }

                        // 2. Activation des sous-titres
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .tvFocusable(onClick = { viewModel.setSubtitlesEnabled(!subtitlesEnabled) })
                                .padding(vertical = 4.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text("Afficher les sous-titres", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                Text("Affiche les sous-titres synchronisés sur la vidéo", color = Color.Gray, fontSize = 11.sp)
                            }
                            Switch(
                                checked = subtitlesEnabled,
                                onCheckedChange = { 
                                    viewModel.setSubtitlesEnabled(it)
                                }
                            )
                        }

                        Divider(color = Color(0xFF334155))

                        // 3. Traduction en direct (ML Kit)
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .tvFocusable(onClick = { viewModel.setSubtitleTranslationEnabled(!subtitleTranslationEnabled) })
                                .padding(vertical = 4.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text("Traduction en direct (ML Kit)", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                Text("Affiche UNIQUEMENT le sous-titre traduit (masque l'original)", color = Color(0xFF10B981), fontSize = 11.sp, fontWeight = FontWeight.Medium)
                            }
                            Switch(
                                checked = subtitleTranslationEnabled,
                                onCheckedChange = { 
                                    viewModel.setSubtitleTranslationEnabled(it)
                                }
                            )
                        }

                        // 4. Sous-titrage Vocal IA (Sherpa-ONNX hors-ligne)
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .tvFocusable(onClick = { viewModel.setVoiceSubtitlesEnabled(!voiceSubtitlesEnabled) })
                                .padding(vertical = 4.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text("Sous-titres vocaux IA (Direct)", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                Text("Transcrit en continu la voix des chaînes sans sous-titres", color = Color.Gray, fontSize = 11.sp)
                            }
                            Switch(
                                checked = voiceSubtitlesEnabled,
                                onCheckedChange = { 
                                    viewModel.setVoiceSubtitlesEnabled(it)
                                }
                            )
                        }

                        Divider(color = Color(0xFF334155))

                        // 5. Configuration Universelle des Langues (Sherpa Source & ML Kit Cible)
                        Card(
                            colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B)),
                            border = BorderStroke(1.dp, Color(0xFF00E5FF).copy(alpha = 0.5f)),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(
                                modifier = Modifier.padding(12.dp),
                                verticalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Icon(Icons.Default.Translate, contentDescription = null, tint = Color(0xFF00E5FF), modifier = Modifier.size(20.dp))
                                    Text(
                                        text = "SÉLECTEURS DE LANGUES (VOIX & TRADUCTION)",
                                        color = Color(0xFF00E5FF),
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }

                                // Sélecteur 1 : Langue source (Sherpa-ONNX) : ce que la chaîne parle
                                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                                    ) {
                                        Text(
                                            text = "Langue source (Sherpa-ONNX) : ce que la chaîne parle",
                                            color = Color.White,
                                            fontSize = 12.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                        Text(
                                            text = "• Modèle offline",
                                            color = Color(0xFF10B981),
                                            fontSize = 10.sp
                                        )
                                    }
                                    LazyRow(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                                    ) {
                                        val sourceCodes = listOf("auto") + viewModel.allVoskModels.keys.toList()
                                        items(sourceCodes) { code ->
                                            val isSelected = if (code == "auto") {
                                                voiceSubtitleLanguage == "auto" || voiceSubtitleLanguage.isBlank()
                                            } else {
                                                voiceSubtitleLanguage != "auto" && liveVoiceSourceLang.equals(code, ignoreCase = true)
                                            }
                                            val displayName = when (code) {
                                                "auto" -> "✨ Auto (Détection)"
                                                "fr" -> "FR (Français)"
                                                "ar" -> "AR (العربية)"
                                                "en" -> "EN (Anglais)"
                                                "es" -> "ES (Español)"
                                                "de" -> "DE (Deutsch)"
                                                "it" -> "IT (Italiano)"
                                                "pt" -> "PT (Português)"
                                                "tr" -> "TR (Türkçe)"
                                                "ru" -> "RU (Русский)"
                                                else -> code.uppercase()
                                            }
                                            FilterChip(
                                                selected = isSelected,
                                                onClick = { 
                                                    viewModel.setLiveVoiceSourceLanguage(code)
                                                },
                                                label = { 
                                                    Text(
                                                        displayName, 
                                                        color = if (isSelected) Color.Black else Color.White, 
                                                        fontSize = 11.sp,
                                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                                                    ) 
                                                },
                                                colors = FilterChipDefaults.filterChipColors(
                                                    selectedContainerColor = Color(0xFF10B981),
                                                    containerColor = Color(0xFF0F172A)
                                                ),
                                                modifier = Modifier.tvFocusable(onClick = { viewModel.setLiveVoiceSourceLanguage(code) })
                                            )
                                        }
                                    }
                                }

                                // Sélecteur 2 : Langue cible (ML Kit) : ce que je veux lire
                                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                                    ) {
                                        Text(
                                            text = "Langue cible (ML Kit) : ce que je veux lire",
                                            color = Color.White,
                                            fontSize = 12.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                        Text(
                                            text = "• Traduction instantanée",
                                            color = Color(0xFF00E5FF),
                                            fontSize = 10.sp
                                        )
                                    }
                                    LazyRow(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                                    ) {
                                        val targetOptions = listOf(
                                            com.example.data.TranslationLanguageOption("none", "Original (Sans traduction)")
                                        ) + com.example.data.TranslationManager.availableLanguages

                                        items(targetOptions) { langOption ->
                                            val isSelected = if (langOption.code == "none") {
                                                !subtitleTranslationEnabled || liveVoiceTargetLang == "none"
                                            } else {
                                                subtitleTranslationEnabled && liveVoiceTargetLang.equals(langOption.code, ignoreCase = true)
                                            }
                                            FilterChip(
                                                selected = isSelected,
                                                onClick = { 
                                                    viewModel.setLiveVoiceTargetLanguage(langOption.code)
                                                },
                                                label = { 
                                                    Text(
                                                        langOption.displayName, 
                                                        color = if (isSelected) Color.Black else Color.White, 
                                                        fontSize = 11.sp,
                                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                                                    ) 
                                                },
                                                colors = FilterChipDefaults.filterChipColors(
                                                    selectedContainerColor = Color(0xFF00E5FF),
                                                    containerColor = Color(0xFF0F172A)
                                                ),
                                                modifier = Modifier.tvFocusable(onClick = { 
                                                    viewModel.setLiveVoiceTargetLanguage(langOption.code)
                                                })
                                            )
                                        }
                                    }
                                }

                                // Statuts de téléchargement Sherpa-ONNX et détection vocale
                                if (isDownloadingModel) {
                                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                        Text(
                                            text = downloadStatusMessage ?: "Téléchargement du modèle vocal Sherpa-ONNX...",
                                            color = Color(0xFF00E5FF),
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Medium
                                        )
                                        LinearProgressIndicator(
                                            progress = { downloadProgress },
                                            modifier = Modifier.fillMaxWidth(),
                                            color = Color(0xFF00E5FF)
                                        )
                                    }
                                } else if (isSpeechDetected) {
                                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                        Box(modifier = Modifier.size(8.dp).background(Color(0xFF10B981), CircleShape))
                                        Text("🎤 Voix détectée : transcription & traduction en direct", color = Color(0xFF10B981), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                    }
                                }

                                // Section Calibrage Audio / Texte Intelligent
                                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            text = "Calibrage Audio / Texte :",
                                            color = Color.White,
                                            fontSize = 12.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                        Text(
                                            text = if (voiceSubtitleAutoCalibration) "Auto intelligent (+${autoCalibratedOffsetMs} ms)" else if (voiceSubtitleSyncOffsetMs == 0) "0 ms (En phase)" else "${if (voiceSubtitleSyncOffsetMs > 0) "+" else ""}${voiceSubtitleSyncOffsetMs} ms",
                                            color = if (voiceSubtitleAutoCalibration) Color(0xFF10B981) else Color(0xFFF59E0B),
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                                    ) {
                                        FilterChip(
                                            selected = voiceSubtitleAutoCalibration,
                                            onClick = { viewModel.setVoiceSubtitleAutoCalibration(true) },
                                            label = {
                                                Text(
                                                    "✨ Auto intelligent (Recommandé)",
                                                    color = if (voiceSubtitleAutoCalibration) Color.Black else Color.White,
                                                    fontSize = 11.sp,
                                                    fontWeight = if (voiceSubtitleAutoCalibration) FontWeight.Bold else FontWeight.Normal
                                                )
                                            },
                                            colors = FilterChipDefaults.filterChipColors(
                                                selectedContainerColor = Color(0xFF10B981),
                                                containerColor = Color(0xFF0F172A)
                                            ),
                                            modifier = Modifier.tvFocusable(onClick = { viewModel.setVoiceSubtitleAutoCalibration(true) })
                                        )
                                        FilterChip(
                                            selected = !voiceSubtitleAutoCalibration,
                                            onClick = { viewModel.setVoiceSubtitleAutoCalibration(false) },
                                            label = {
                                                Text(
                                                    "Manuel (+/-)",
                                                    color = if (!voiceSubtitleAutoCalibration) Color.Black else Color.White,
                                                    fontSize = 11.sp,
                                                    fontWeight = if (!voiceSubtitleAutoCalibration) FontWeight.Bold else FontWeight.Normal
                                                )
                                            },
                                            colors = FilterChipDefaults.filterChipColors(
                                                selectedContainerColor = Color(0xFF00E5FF),
                                                containerColor = Color(0xFF0F172A)
                                            ),
                                            modifier = Modifier.tvFocusable(onClick = { viewModel.setVoiceSubtitleAutoCalibration(false) })
                                        )
                                    }

                                    if (!voiceSubtitleAutoCalibration) {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                                        ) {
                                            listOf(
                                                "-500ms" to -500,
                                                "-100ms" to -100,
                                                "0ms" to 0,
                                                "+100ms" to 100,
                                                "+500ms" to 500
                                            ).forEach { (label, step) ->
                                                Box(
                                                    modifier = Modifier
                                                        .weight(1f)
                                                        .background(
                                                            if (step == 0 && voiceSubtitleSyncOffsetMs == 0) Color(0xFF10B981).copy(alpha = 0.25f) else Color(0xFF1E293B),
                                                            RoundedCornerShape(6.dp)
                                                        )
                                                        .border(
                                                            1.dp,
                                                            if (step == 0 && voiceSubtitleSyncOffsetMs == 0) Color(0xFF10B981) else Color(0x33FFFFFF),
                                                            RoundedCornerShape(6.dp)
                                                        )
                                                        .tvFocusable(onClick = {
                                                            if (step == 0) viewModel.setVoiceSubtitleSyncOffsetMs(0)
                                                            else viewModel.setVoiceSubtitleSyncOffsetMs(voiceSubtitleSyncOffsetMs + step)
                                                        })
                                                        .clickable {
                                                            if (step == 0) viewModel.setVoiceSubtitleSyncOffsetMs(0)
                                                            else viewModel.setVoiceSubtitleSyncOffsetMs(voiceSubtitleSyncOffsetMs + step)
                                                        }
                                                        .padding(vertical = 6.dp),
                                                    contentAlignment = Alignment.Center
                                                ) {
                                                    Text(
                                                        text = label,
                                                        color = Color.White,
                                                        fontSize = 10.sp,
                                                        fontWeight = FontWeight.SemiBold
                                                    )
                                                }
                                            }
                                        }
                                    }
                                }

                                // Section Durée d'affichage Intelligente
                                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            text = "Temps d'affichage du texte :",
                                            color = Color.White,
                                            fontSize = 12.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                        Text(
                                            text = if (voiceSubtitleAutoDuration) "Intelligent (Selon longueur)" else "${voiceSubtitleClearDelaySeconds}s (Fixe)",
                                            color = if (voiceSubtitleAutoDuration) Color(0xFF10B981) else Color(0xFF00E5FF),
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                                    ) {
                                        FilterChip(
                                            selected = voiceSubtitleAutoDuration,
                                            onClick = { viewModel.setVoiceSubtitleAutoDuration(true) },
                                            label = {
                                                Text(
                                                    "🧠 Intelligent (Temps adapté)",
                                                    color = if (voiceSubtitleAutoDuration) Color.Black else Color.White,
                                                    fontSize = 11.sp,
                                                    fontWeight = if (voiceSubtitleAutoDuration) FontWeight.Bold else FontWeight.Normal
                                                )
                                            },
                                            colors = FilterChipDefaults.filterChipColors(
                                                selectedContainerColor = Color(0xFF10B981),
                                                containerColor = Color(0xFF0F172A)
                                            ),
                                            modifier = Modifier.tvFocusable(onClick = { viewModel.setVoiceSubtitleAutoDuration(true) })
                                        )
                                        FilterChip(
                                            selected = !voiceSubtitleAutoDuration,
                                            onClick = { viewModel.setVoiceSubtitleAutoDuration(false) },
                                            label = {
                                                Text(
                                                    "Fixe",
                                                    color = if (!voiceSubtitleAutoDuration) Color.Black else Color.White,
                                                    fontSize = 11.sp,
                                                    fontWeight = if (!voiceSubtitleAutoDuration) FontWeight.Bold else FontWeight.Normal
                                                )
                                            },
                                            colors = FilterChipDefaults.filterChipColors(
                                                selectedContainerColor = Color(0xFF00E5FF),
                                                containerColor = Color(0xFF0F172A)
                                            ),
                                            modifier = Modifier.tvFocusable(onClick = { viewModel.setVoiceSubtitleAutoDuration(false) })
                                        )
                                    }

                                    if (!voiceSubtitleAutoDuration) {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                                        ) {
                                            listOf(3 to "3s (Vif)", 5 to "5s (Normal)", 7 to "7s (Confort)", 9 to "9s (Long)").forEach { (sec, label) ->
                                                val isSel = voiceSubtitleClearDelaySeconds == sec
                                                Box(
                                                    modifier = Modifier
                                                        .weight(1f)
                                                        .background(
                                                            if (isSel) Color(0xFF10B981).copy(alpha = 0.25f) else Color(0xFF1E293B),
                                                            RoundedCornerShape(6.dp)
                                                        )
                                                        .border(
                                                            1.dp,
                                                            if (isSel) Color(0xFF10B981) else Color(0x33FFFFFF),
                                                            RoundedCornerShape(6.dp)
                                                        )
                                                        .tvFocusable(onClick = { viewModel.setVoiceSubtitleClearDelaySeconds(sec) })
                                                        .clickable { viewModel.setVoiceSubtitleClearDelaySeconds(sec) }
                                                        .padding(vertical = 6.dp),
                                                    contentAlignment = Alignment.Center
                                                ) {
                                                    Text(
                                                        text = label,
                                                        color = if (isSel) Color(0xFF10B981) else Color.White,
                                                        fontSize = 10.sp,
                                                        fontWeight = if (isSel) FontWeight.Bold else FontWeight.Normal
                                                    )
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }

                        Divider(color = Color(0xFF334155))

                        // 5. Palette de styles visuels
                        Text("Style visuel des sous-titres :", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            styleOptions.forEach { (styleName, textColor) ->
                                val isSelected = subtitleStyleMode.equals(styleName, ignoreCase = true) ||
                                    (styleName.contains("vert", ignoreCase = true) && subtitleStyleMode.contains("vert", ignoreCase = true)) ||
                                    (styleName.contains("cyan", ignoreCase = true) && subtitleStyleMode.contains("cyan", ignoreCase = true)) ||
                                    (styleName.contains("jaune", ignoreCase = true) && subtitleStyleMode.contains("jaune", ignoreCase = true)) ||
                                    (styleName.contains("blanc sur noir", ignoreCase = true) && (subtitleStyleMode.contains("blanc sur noir", ignoreCase = true) || subtitleStyleMode.contains("bande noire, texte blanc", ignoreCase = true)))
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(if (isSelected) Color(0xFF334155) else Color(0xFF1E293B))
                                        .border(1.dp, if (isSelected) Color(0xFF00E5FF) else Color.Transparent, RoundedCornerShape(8.dp))
                                        .tvFocusable(onClick = {
                                            viewModel.setSubtitleStyleMode(styleName)
                                            viewModel.triggerSubtitlePreviewTest()
                                        })
                                        .clickable {
                                            viewModel.setSubtitleStyleMode(styleName)
                                            viewModel.triggerSubtitlePreviewTest()
                                        }
                                        .padding(horizontal = 12.dp, vertical = 8.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                        Box(
                                            modifier = Modifier
                                                .size(14.dp)
                                                .background(textColor, CircleShape)
                                                .border(1.dp, Color.Gray, CircleShape)
                                        )
                                        Text(styleName, color = Color.White, fontSize = 11.sp, fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal)
                                    }
                                    if (isSelected) {
                                        Icon(Icons.Default.Check, contentDescription = null, tint = Color(0xFF00E5FF), modifier = Modifier.size(16.dp))
                                    }
                                }
                            }
                        }

                        // 6. Taille des sous-titres
                        Text("Taille des sous-titres :", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            sizeOptions.forEach { sizeName ->
                                val isSelected = subtitleSizeState.equals(sizeName, ignoreCase = true)
                                Button(
                                    onClick = { 
                                        viewModel.setSubtitleSizeState(sizeName)
                                        viewModel.triggerSubtitlePreviewTest()
                                    },
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = if (isSelected) Color(0xFF00E5FF) else Color(0xFF1E293B)
                                    ),
                                    modifier = Modifier
                                        .weight(1f)
                                        .tvFocusable(onClick = {
                                            viewModel.setSubtitleSizeState(sizeName)
                                            viewModel.triggerSubtitlePreviewTest()
                                        }),
                                    contentPadding = PaddingValues(horizontal = 4.dp, vertical = 6.dp)
                                ) {
                                    Text(
                                        text = sizeName,
                                        color = if (isSelected) Color.Black else Color.White,
                                        fontSize = 10.sp,
                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                        maxLines = 1
                                    )
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Button(
                        onClick = onDismiss,
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF10B981)),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .tvFocusable(onClick = onDismiss)
                    ) {
                        Text("Fermer & Appliquer", color = Color.White, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
fun TesterPlusieursMacDialog(
    initialPortalUrl: String,
    onDismiss: () -> Unit,
    viewModel: IptvViewModel
) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val clipboardManager = androidx.compose.ui.platform.LocalClipboardManager.current
    var portalUrl by remember { mutableStateOf(initialPortalUrl) }
    var macsText by remember { mutableStateOf("") }
    var smartPasteStatusMessage by remember { mutableStateOf<String?>(null) }
    val progress by viewModel.bulkMacTestProgress.collectAsState()
    val playlists by viewModel.playlists.collectAsState()

    var basePlaylistName by remember { mutableStateOf("") }
    var selectedValidMacs by remember { mutableStateOf(setOf<String>()) }
    var showFailedMacs by remember { mutableStateOf(false) }

    // Chargement ultra-rapide : uniquement les chaînes direct Live TV par défaut pour gagner du temps
    var loadLive by remember { mutableStateOf(true) }
    var loadMovies by remember { mutableStateOf(false) }
    var loadSeries by remember { mutableStateOf(false) }

    val detectedMacCount = remember(macsText) { extractAndNormalizeMacs(macsText).size }
    val validResults = remember(progress.results) { progress.results.filter { it.success } }
    val failedResults = remember(progress.results) { progress.results.filter { !it.success } }

    LaunchedEffect(portalUrl) {
        if (basePlaylistName.isBlank() && portalUrl.isNotBlank() && portalUrl != "http://") {
            basePlaylistName = extractStalkerPlaylistNameFromUrl(portalUrl, playlists.map { it.name })
        }
    }

    // Sélectionner automatiquement les nouvelles MAC valides au fur et à mesure
    LaunchedEffect(validResults) {
        if (validResults.isNotEmpty()) {
            val allValid = validResults.map { it.mac }.toSet()
            // Conserver les sélections existantes et ajouter les nouvelles
            selectedValidMacs = (selectedValidMacs + allValid).filter { allValid.contains(it) }.toSet()
        }
    }

    DisposableEffect(Unit) {
        onDispose {
            viewModel.resetBulkMacTest()
        }
    }

    AlertDialog(
        onDismissRequest = {
            if (progress.isTesting) {
                viewModel.cancelBulkMacTest()
            }
            onDismiss()
        },
        title = {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Icon(Icons.Default.Refresh, contentDescription = null, tint = Color(0xFF00E5FF))
                Text("Tester & Charger des Adresses MAC", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 18.sp)
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Bouton Coller Intelligemment en Masse
                Button(
                    onClick = {
                        val clipText = clipboardManager.getText()?.text ?: ""
                        if (clipText.isNotBlank()) {
                            // Si le texte contient un lien de portail http, le récupérer intelligemment
                            val urlRegex = Regex("""https?://[^\s/$.?#].[^\s]*""")
                            val foundUrl = urlRegex.find(clipText)?.value
                            if (!foundUrl.isNullOrBlank() && (portalUrl.isBlank() || portalUrl == "http://")) {
                                portalUrl = foundUrl
                                if (basePlaylistName.isBlank()) {
                                    basePlaylistName = extractStalkerPlaylistNameFromUrl(foundUrl, playlists.map { it.name })
                                }
                            }

                            // Extraire toutes les adresses MAC valides
                            val extracted = extractAndNormalizeMacs(clipText)
                            val current = extractAndNormalizeMacs(macsText)
                            val combined = (current + extracted).distinct()

                            if (combined.isNotEmpty()) {
                                macsText = combined.joinToString("\n")
                                smartPasteStatusMessage = "✅ ${extracted.size} adresse(s) MAC extraite(s) et normalisée(s) avec succès !"
                            } else {
                                smartPasteStatusMessage = "⚠️ Aucune adresse MAC valide détectée dans le presse-papier."
                            }
                        } else {
                            smartPasteStatusMessage = "⚠️ Le presse-papier est vide."
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF10B981)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(Icons.Default.ContentPaste, contentDescription = null, tint = Color.White, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("📋 Coller intelligemment les MAC en masse", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                }

                smartPasteStatusMessage?.let { msg ->
                    Text(
                        text = msg,
                        color = if (msg.startsWith("✅")) Color(0xFF10B981) else Color(0xFFF59E0B),
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Medium
                    )
                }

                OutlinedTextField(
                    value = portalUrl,
                    onValueChange = { 
                        portalUrl = it 
                        if (basePlaylistName.isBlank() && it.isNotBlank()) {
                            basePlaylistName = extractStalkerPlaylistNameFromUrl(it, playlists.map { pl -> pl.name })
                        }
                    },
                    label = { Text("URL du Portail Stalker") },
                    placeholder = { Text("http://example.com:8080/c/") },
                    modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = Color(0xFF00E5FF),
                        unfocusedBorderColor = Color(0xFF334155),
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White
                    )
                )

                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Liste d'adresses MAC :", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        Text(
                            text = "📊 $detectedMacCount MAC prête(s)",
                            color = if (detectedMacCount > 0) Color(0xFF00E5FF) else Color.Gray,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    OutlinedTextField(
                        value = macsText,
                        onValueChange = { 
                            macsText = it 
                            smartPasteStatusMessage = null
                        },
                        placeholder = { Text("00:1A:79:XX:XX:XX\n00:1A:79:YY:YY:YY\n(Une MAC par ligne)") },
                        minLines = 3,
                        maxLines = 5,
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = Color(0xFF00E5FF),
                            unfocusedBorderColor = Color(0xFF334155),
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White
                        )
                    )
                }

                // Carte de progression du test
                if (progress.isTesting || progress.isCompleted || progress.statusText.isNotEmpty()) {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = Color(0xFF0F172A)),
                        border = BorderStroke(1.dp, if (progress.isCompleted) Color(0xFF10B981) else Color(0xFF00E5FF).copy(alpha = 0.5f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text(
                                text = progress.statusText,
                                color = if (progress.isCompleted) Color(0xFF10B981) else Color(0xFF00E5FF),
                                fontSize = 12.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                            if (progress.isTesting) {
                                LinearProgressIndicator(
                                    progress = {
                                        if (progress.totalCount > 0) progress.currentIndex.toFloat() / progress.totalCount.toFloat() else 0f
                                    },
                                    modifier = Modifier.fillMaxWidth(),
                                    color = Color(0xFF00E5FF),
                                )
                            }
                            Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                                Text("✅ Valables : ${progress.successCount}", color = Color(0xFF10B981), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                Text("❌ Rejetées : ${progress.failureCount}", color = Color(0xFFEF4444), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }

                // Section 1 : MAC Valables avec Sélection et Actions Rapides
                if (validResults.isNotEmpty()) {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = Color(0xFF0D233A)),
                        border = BorderStroke(1.dp, Color(0xFF00E5FF)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "🏆 MAC valables (${validResults.size})",
                                    color = Color(0xFF00E5FF),
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "${selectedValidMacs.size}/${validResults.size} sélectionnée(s)",
                                    color = Color.White,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Medium
                                )
                            }

                            // Boutons Tout sélectionner / Tout désélectionner
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                OutlinedButton(
                                    onClick = {
                                        selectedValidMacs = validResults.map { it.mac }.toSet()
                                    },
                                    modifier = Modifier.weight(1f),
                                    colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFF00E5FF)),
                                    border = BorderStroke(1.dp, Color(0xFF00E5FF).copy(alpha = 0.5f)),
                                    contentPadding = PaddingValues(vertical = 4.dp, horizontal = 6.dp)
                                ) {
                                    Text("Tout sélectionner", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }

                                OutlinedButton(
                                    onClick = {
                                        selectedValidMacs = emptySet()
                                    },
                                    modifier = Modifier.weight(1f),
                                    colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.Gray),
                                    border = BorderStroke(1.dp, Color.Gray.copy(alpha = 0.4f)),
                                    contentPadding = PaddingValues(vertical = 4.dp, horizontal = 6.dp)
                                ) {
                                    Text("Désélectionner tout", fontSize = 11.sp)
                                }
                            }

                            // Nom de base des playlists
                            OutlinedTextField(
                                value = basePlaylistName,
                                onValueChange = { basePlaylistName = it },
                                label = { Text("Nom de base des playlists") },
                                placeholder = { Text("Stalker Portal") },
                                modifier = Modifier.fillMaxWidth(),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = Color(0xFF00E5FF),
                                    unfocusedBorderColor = Color(0xFF334155),
                                    focusedTextColor = Color.White,
                                    unfocusedTextColor = Color.White
                                )
                            )

                            // Sélection du contenu à importer (Direct uniquement par défaut pour un gain de temps maximal)
                            Card(
                                colors = CardDefaults.cardColors(containerColor = Color(0xFF0F172A)),
                                border = BorderStroke(1.dp, Color(0xFF1E293B)),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
                                    verticalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            "Contenu à importer :",
                                            color = Color.White,
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                        Text(
                                            text = if (loadLive && !loadMovies && !loadSeries) "⚡ Rapide (Live TV seul)" else "📦 Médias inclus",
                                            color = if (loadLive && !loadMovies && !loadSeries) Color(0xFF10B981) else Color(0xFF00E5FF),
                                            fontSize = 10.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }

                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        // Live TV (Coché par défaut)
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            modifier = Modifier.clickable { loadLive = !loadLive }
                                        ) {
                                            Checkbox(
                                                checked = loadLive,
                                                onCheckedChange = { loadLive = it },
                                                colors = CheckboxDefaults.colors(
                                                    checkedColor = Color(0xFF10B981),
                                                    checkmarkColor = Color.White
                                                )
                                            )
                                            Text(
                                                "Direct (Live)",
                                                color = if (loadLive) Color.White else Color.Gray,
                                                fontSize = 11.sp,
                                                fontWeight = if (loadLive) FontWeight.Bold else FontWeight.Normal
                                            )
                                        }

                                        // Films (Exclus par défaut pour gagner du temps)
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            modifier = Modifier.clickable { loadMovies = !loadMovies }
                                        ) {
                                            Checkbox(
                                                checked = loadMovies,
                                                onCheckedChange = { loadMovies = it },
                                                colors = CheckboxDefaults.colors(
                                                    checkedColor = Color(0xFF10B981),
                                                    checkmarkColor = Color.White
                                                )
                                            )
                                            Text(
                                                "Films",
                                                color = if (loadMovies) Color.White else Color.Gray,
                                                fontSize = 11.sp,
                                                fontWeight = if (loadMovies) FontWeight.Bold else FontWeight.Normal
                                            )
                                        }

                                        // Séries (Exclues par défaut pour gagner du temps)
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            modifier = Modifier.clickable { loadSeries = !loadSeries }
                                        ) {
                                            Checkbox(
                                                checked = loadSeries,
                                                onCheckedChange = { loadSeries = it },
                                                colors = CheckboxDefaults.colors(
                                                    checkedColor = Color(0xFF10B981),
                                                    checkmarkColor = Color.White
                                                )
                                            )
                                            Text(
                                                "Séries",
                                                color = if (loadSeries) Color.White else Color.Gray,
                                                fontSize = 11.sp,
                                                fontWeight = if (loadSeries) FontWeight.Bold else FontWeight.Normal
                                            )
                                        }
                                    }
                                }
                            }

                            // Boutons d'actions groupées : Créer les playlists & Charger intelligemment
                            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                Button(
                                    onClick = {
                                        if (selectedValidMacs.isNotEmpty()) {
                                            viewModel.createPlaylistsForValidMacs(
                                                portalUrl = portalUrl,
                                                macs = selectedValidMacs.toList(),
                                                customBaseName = basePlaylistName
                                            ) { count ->
                                                Toast.makeText(context, "✅ $count nouvelle(s) playlist(s) créée(s) avec succès !", Toast.LENGTH_LONG).show()
                                            }
                                        }
                                    },
                                    enabled = selectedValidMacs.isNotEmpty(),
                                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF10B981)),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Icon(Icons.Default.AddCircle, contentDescription = null, tint = Color.White, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("➕ Créer les playlists sélectionnées (${selectedValidMacs.size})", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                }

                                Button(
                                    onClick = {
                                        if (selectedValidMacs.isNotEmpty()) {
                                            viewModel.loadAllSelectedPlaylistsForMacs(
                                                portalUrl = portalUrl,
                                                macs = selectedValidMacs.toList(),
                                                customBaseName = basePlaylistName,
                                                loadLive = loadLive,
                                                loadMovies = loadMovies,
                                                loadSeries = loadSeries
                                            ) { loadedCount ->
                                                val modeStr = if (loadLive && !loadMovies && !loadSeries) "Direct Live TV" else "Direct + Médias"
                                                Toast.makeText(context, "🚀 $loadedCount playlist(s) chargée(s) avec succès ($modeStr) !", Toast.LENGTH_LONG).show()
                                            }
                                        }
                                    },
                                    enabled = selectedValidMacs.isNotEmpty() && (loadLive || loadMovies || loadSeries),
                                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF3B82F6)),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Icon(Icons.Default.Download, contentDescription = null, tint = Color.White, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    val buttonLabel = if (loadLive && !loadMovies && !loadSeries) {
                                        "⚡ Charger les chaînes Live TV uniquement (${selectedValidMacs.size})"
                                    } else {
                                        "📥 Charger les chaînes sélectionnées (${selectedValidMacs.size})"
                                    }
                                    Text(buttonLabel, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                }
                            }

                            Divider(color = Color(0xFF1E293B))

                            Text("Liste des MAC valides (Cliquez pour charger individuellement) :", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)

                            // Liste détaillée des MAC valides
                            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                validResults.forEach { res ->
                                    val isChecked = selectedValidMacs.contains(res.mac)
                                    Card(
                                        colors = CardDefaults.cardColors(
                                            containerColor = if (isChecked) Color(0xFF10B981).copy(alpha = 0.15f) else Color(0xFF1E293B)
                                        ),
                                        border = BorderStroke(1.dp, if (isChecked) Color(0xFF10B981) else Color(0xFF334155)),
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Row(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .padding(horizontal = 8.dp, vertical = 6.dp),
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.SpaceBetween
                                        ) {
                                            Row(
                                                verticalAlignment = Alignment.CenterVertically,
                                                horizontalArrangement = Arrangement.spacedBy(6.dp),
                                                modifier = Modifier.weight(1f)
                                            ) {
                                                Checkbox(
                                                    checked = isChecked,
                                                    onCheckedChange = { checked ->
                                                        selectedValidMacs = if (checked) {
                                                            selectedValidMacs + res.mac
                                                        } else {
                                                            selectedValidMacs - res.mac
                                                        }
                                                    },
                                                    colors = CheckboxDefaults.colors(
                                                        checkedColor = Color(0xFF10B981),
                                                        checkmarkColor = Color.White
                                                    )
                                                )

                                                Column {
                                                    Text(
                                                        text = res.mac,
                                                        color = Color.White,
                                                        fontSize = 12.sp,
                                                        fontWeight = FontWeight.Bold
                                                    )
                                                    if (res.isLoadingChannels) {
                                                        Text(
                                                            text = "🔄 Chargement intelligent des chaînes...",
                                                            color = Color(0xFF00E5FF),
                                                            fontSize = 10.sp,
                                                            fontWeight = FontWeight.Medium
                                                        )
                                                    } else if (res.channelsLoadedCount != null && res.channelsLoadedCount > 0) {
                                                        Text(
                                                            text = "📺 ${res.channelsLoadedCount} chaînes prêtes (${res.playlistName ?: "Playlist"})",
                                                            color = Color(0xFF10B981),
                                                            fontSize = 10.sp,
                                                            fontWeight = FontWeight.SemiBold
                                                        )
                                                    } else if (res.isCreated) {
                                                        Text(
                                                            text = "📁 Créée : ${res.playlistName ?: "Stalker ($res.mac)"}",
                                                            color = Color(0xFF93C5FD),
                                                            fontSize = 10.sp
                                                        )
                                                    } else {
                                                        Text(
                                                            text = "⚡ Valide (Prête à charger)",
                                                            color = Color(0xFF34D399),
                                                            fontSize = 10.sp
                                                        )
                                                    }
                                                }
                                            }

                                            // Bouton individuel Charger / Visionner
                                            if (res.isLoadingChannels) {
                                                CircularProgressIndicator(
                                                    modifier = Modifier.size(24.dp),
                                                    strokeWidth = 2.dp,
                                                    color = Color(0xFF00E5FF)
                                                )
                                            } else {
                                                Button(
                                                    onClick = {
                                                        viewModel.loadSmartPlaylistForMac(
                                                            portalUrl = portalUrl,
                                                            mac = res.mac,
                                                            customBaseName = basePlaylistName,
                                                            loadLive = loadLive,
                                                            loadMovies = loadMovies,
                                                            loadSeries = loadSeries,
                                                            onSuccess = { pl, count ->
                                                                val modeStr = if (loadLive && !loadMovies && !loadSeries) "Live TV" else "Direct + Médias"
                                                                Toast.makeText(context, "🚀 Playlist '${pl.name}' activée ($count chaînes $modeStr) !", Toast.LENGTH_LONG).show()
                                                                onDismiss()
                                                            },
                                                            onError = { err ->
                                                                Toast.makeText(context, "Erreur : $err", Toast.LENGTH_LONG).show()
                                                            }
                                                        )
                                                    },
                                                    colors = ButtonDefaults.buttonColors(
                                                        containerColor = if (res.channelsLoadedCount != null && res.channelsLoadedCount > 0) Color(0xFF00E5FF) else Color(0xFF10B981)
                                                    ),
                                                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp)
                                                ) {
                                                    Icon(
                                                        imageVector = if (res.channelsLoadedCount != null && res.channelsLoadedCount > 0) Icons.Default.PlayArrow else Icons.Default.Download,
                                                        contentDescription = null,
                                                        tint = Color.Black,
                                                        modifier = Modifier.size(14.dp)
                                                    )
                                                    Spacer(modifier = Modifier.width(4.dp))
                                                    Text(
                                                        text = if (res.channelsLoadedCount != null && res.channelsLoadedCount > 0) "Visionner" else "Charger",
                                                        color = Color.Black,
                                                        fontSize = 11.sp,
                                                        fontWeight = FontWeight.Bold
                                                    )
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                // Section 2 : MAC non retenues (Rejetées)
                if (failedResults.isNotEmpty()) {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = Color(0xFF1A1A2E)),
                        border = BorderStroke(1.dp, Color(0xFFEF4444).copy(alpha = 0.4f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { showFailedMacs = !showFailedMacs },
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "❌ MAC non retenues (${failedResults.size})",
                                    color = Color(0xFFEF4444),
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = if (showFailedMacs) "Masquer ▲" else "Afficher ▼",
                                    color = Color.Gray,
                                    fontSize = 10.sp
                                )
                            }

                            if (showFailedMacs) {
                                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                    failedResults.forEach { res ->
                                        Row(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .background(Color(0xFFEF4444).copy(alpha = 0.1f), RoundedCornerShape(4.dp))
                                                .padding(horizontal = 8.dp, vertical = 4.dp),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Text(res.mac, color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                            Text(
                                                text = res.errorMessage ?: "Échec d'authentification",
                                                color = Color(0xFFF87171),
                                                fontSize = 10.sp,
                                                maxLines = 1
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            if (progress.isTesting) {
                Button(
                    onClick = { viewModel.cancelBulkMacTest() },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFEF4444))
                ) {
                    Text("Annuler le test", color = Color.White, fontWeight = FontWeight.Bold)
                }
            } else {
                Button(
                    onClick = {
                        viewModel.testAndImportBulkMacs(portalUrl, macsText)
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF00E5FF)),
                    enabled = detectedMacCount > 0 && portalUrl.isNotBlank()
                ) {
                    Text("Lancer le test ($detectedMacCount MAC) ⚡", color = Color.Black, fontWeight = FontWeight.Bold)
                }
            }
        },
        dismissButton = {
            TextButton(
                onClick = {
                    if (progress.isTesting) {
                        viewModel.cancelBulkMacTest()
                    }
                    onDismiss()
                }
            ) {
                Text(if (progress.isCompleted) "Fermer" else "Annuler", color = Color.Gray)
            }
        },
        containerColor = Color(0xFF1E293B)
    )
}

sealed class HierarchicalItem {
    data class CategoryHeader(val name: String, val level: Int = 1) : HierarchicalItem()
    data class ChannelRow(val channel: ChannelItem, val index: Int, val level: Int = 1) : HierarchicalItem()
}

fun buildHierarchicalItems(channels: List<ChannelItem>): List<HierarchicalItem> {
    val result = mutableListOf<HierarchicalItem>()
    channels.forEachIndexed { index, channel ->
        result.add(HierarchicalItem.ChannelRow(channel = channel, index = index + 1, level = 1))
    }
    return result
}

@Composable
fun CategoryHeaderRow(item: HierarchicalItem.CategoryHeader) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp, horizontal = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = item.name.uppercase(),
            color = Color(0xFF00E5FF),
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = 1.sp
        )
    }
}

@Composable
fun ChannelItemRow(
    item: HierarchicalItem.ChannelRow,
    isSelected: Boolean,
    onFocus: (ChannelItem) -> Unit,
    onClick: (ChannelItem) -> Unit,
    modifier: Modifier = Modifier,
    onCatchupClick: ((ChannelItem) -> Unit)? = null
) {
    val channel = item.channel
    var isFocused by remember { mutableStateOf(false) }

    Row(
        modifier = modifier
            .fillMaxWidth()
            .onFocusChanged {
                isFocused = it.isFocused
                if (it.isFocused) {
                    onFocus(channel)
                }
            }
            .clip(RoundedCornerShape(14.dp))
            .background(
                when {
                    isFocused || isSelected -> Color(0xFF0D1E3A)
                    else -> Color(0xFF161033)
                }
            )
            .border(
                width = when {
                    isSelected -> 2.dp
                    isFocused -> 1.5.dp
                    else -> 0.dp
                },
                color = when {
                    isSelected -> Color(0xFF00E5FF)
                    isFocused -> Color(0xFF00E5FF).copy(alpha = 0.6f)
                    else -> Color.Transparent
                },
                shape = RoundedCornerShape(14.dp)
            )
            .clickable { onClick(channel) }
            .padding(horizontal = 14.dp, vertical = 11.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        val formattedIndex = if (item.index < 10) "0${item.index}" else "${item.index}"
        Text(
            text = formattedIndex,
            color = Color(0xFFFFD600),
            fontSize = 22.sp,
            fontWeight = FontWeight.Black,
            modifier = Modifier.width(42.dp)
        )

        if (channel.logoUrl.isNotBlank()) {
            AsyncImage(
                model = channel.logoUrl,
                contentDescription = channel.name,
                modifier = Modifier
                    .size(32.dp)
                    .clip(RoundedCornerShape(8.dp)),
                contentScale = ContentScale.Fit
            )
            Spacer(modifier = Modifier.width(12.dp))
        }

        Text(
            text = channel.name,
            color = Color.White,
            fontSize = 15.5.sp,
            fontWeight = if (isSelected || isFocused) FontWeight.Black else FontWeight.Bold,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.weight(1f)
        )

        if (channel.hasCatchup || channel.tvArchiveDuration > 0 || channel.catchupDurationDays > 0) {
            Spacer(modifier = Modifier.width(6.dp))
            IconButton(
                onClick = { onCatchupClick?.invoke(channel) },
                modifier = Modifier.size(30.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.History,
                    contentDescription = "Replay Catchup",
                    tint = Color(0xFF00E5FF),
                    modifier = Modifier.size(20.dp)
                )
            }
        }
    }
}

@Composable
fun ContinueWatchingRow(viewModel: IptvViewModel) {
    val watchProgressList by viewModel.watchProgressList.collectAsState()
    val limitedList = remember(watchProgressList) { watchProgressList.take(8) }
    if (limitedList.isEmpty()) return

    Column(modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = "REPRENDRE LA LECTURE",
                    color = Color(0xFF00E5FF),
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Black,
                    letterSpacing = 0.5.sp
                )
                Spacer(modifier = Modifier.width(8.dp))
                Box(
                    modifier = Modifier
                        .background(CeylanColor, shape = RoundedCornerShape(6.dp))
                        .padding(horizontal = 8.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = "${watchProgressList.size} EN COURS",
                        color = Color.White,
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Black
                    )
                }
            }

            // Clear history button
            Row(
                modifier = Modifier
                    .background(Color(0xFF25183E), shape = RoundedCornerShape(8.dp))
                    .border(1.dp, Color(0xFFEF4444).copy(alpha = 0.5f), shape = RoundedCornerShape(8.dp))
                    .tvFocusable(
                        focusedColor = Color(0xFFEF4444),
                        borderRadius = 8.dp,
                        onClick = { viewModel.clearAllWatchProgress() }
                    )
                    .clickable { viewModel.clearAllWatchProgress() }
                    .padding(horizontal = 10.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Default.Delete,
                    contentDescription = "Effacer l'historique",
                    tint = Color(0xFFEF4444),
                    modifier = Modifier.size(14.dp)
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = "EFFACER TOUT",
                    color = Color(0xFFEF4444),
                    fontSize = 10.5.sp,
                    fontWeight = FontWeight.Black
                )
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        LazyRow(
            horizontalArrangement = Arrangement.spacedBy(14.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            items(limitedList, key = { it.id }) { wp ->
                val isSeries = wp.contentType.equals("series", ignoreCase = true) ||
                    wp.seasonNumber > 0 || wp.episodeNumber > 0 ||
                    wp.title.contains(Regex("""(?i)(?:s\d+|e\d+|épisode|episode|حلقة|saison)"""))

                // Cleanly separate series title from episode title if present
                val parts = wp.title.split(" - ")
                val seriesName = if (isSeries && parts.size >= 2) parts.dropLast(1).joinToString(" - ").trim() else wp.title
                val rawEpName = if (isSeries && parts.size >= 2) parts.last().trim() else ""

                val episodeLabel = when {
                    wp.seasonNumber > 0 && wp.episodeNumber > 0 -> "Saison ${wp.seasonNumber} • Épisode ${wp.episodeNumber}"
                    wp.episodeNumber > 0 -> "Épisode ${wp.episodeNumber}" + (if (rawEpName.isNotBlank() && !rawEpName.contains("${wp.episodeNumber}")) " : $rawEpName" else "")
                    rawEpName.isNotBlank() -> rawEpName
                    else -> "Épisode en cours"
                }

                val progressPercent = if (wp.durationMs > 0) {
                    (wp.positionMs.toFloat() / wp.durationMs.toFloat()).coerceIn(0f, 1f)
                } else 0.5f

                val posSec = wp.positionMs / 1000
                val min = posSec / 60
                val sec = posSec % 60
                val timeFormatted = String.format("%02d:%02d", min, sec)

                Card(
                    modifier = Modifier
                        .width(350.dp)
                        .clickable {
                            viewModel.resumeWatchProgressDirectly(wp)
                        }
                        .tvFocusable(
                            focusedColor = CeylanColor,
                            borderRadius = 16.dp,
                            onClick = {
                                viewModel.resumeWatchProgressDirectly(wp)
                            }
                        ),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF161033)),
                    border = BorderStroke(1.5.dp, Color(0xFF332766))
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        // Top row: Type Badges & Remove button
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                horizontalArrangement = Arrangement.spacedBy(6.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                if (isSeries) {
                                    Box(
                                        modifier = Modifier
                                            .background(Color(0xFF8B5CF6).copy(alpha = 0.25f), shape = RoundedCornerShape(6.dp))
                                            .border(1.dp, Color(0xFF8B5CF6), shape = RoundedCornerShape(6.dp))
                                            .padding(horizontal = 7.dp, vertical = 2.dp)
                                    ) {
                                        Text("SÉRIE", color = Color(0xFFC4B5FD), fontSize = 9.5.sp, fontWeight = FontWeight.Black)
                                    }
                                    if (wp.episodeNumber > 0) {
                                        Box(
                                            modifier = Modifier
                                                .background(CeylanColor.copy(alpha = 0.25f), shape = RoundedCornerShape(6.dp))
                                                .border(1.dp, CeylanColor, shape = RoundedCornerShape(6.dp))
                                                .padding(horizontal = 7.dp, vertical = 2.dp)
                                        ) {
                                            Text(
                                                text = if (wp.seasonNumber > 0) "S${wp.seasonNumber} • EP ${wp.episodeNumber}" else "ÉPISODE ${wp.episodeNumber}",
                                                color = Color.White,
                                                fontSize = 9.5.sp,
                                                fontWeight = FontWeight.Black
                                            )
                                        }
                                    }
                                } else {
                                    Box(
                                        modifier = Modifier
                                            .background(CeylanColor.copy(alpha = 0.25f), shape = RoundedCornerShape(6.dp))
                                            .border(1.dp, CeylanColor, shape = RoundedCornerShape(6.dp))
                                            .padding(horizontal = 7.dp, vertical = 2.dp)
                                    ) {
                                        Text("FILM VOD", color = Color.White, fontSize = 9.5.sp, fontWeight = FontWeight.Black)
                                    }
                                }
                            }

                            // Delete individual item button
                            IconButton(
                                onClick = { viewModel.removeWatchProgress(wp.id) },
                                modifier = Modifier.size(24.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Close,
                                    contentDescription = "Supprimer de la liste",
                                    tint = Color(0xFFA0A0C0),
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        // Middle row: Poster / Media icon + Title & Episode details
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(52.dp)
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(Color(0xFF0F0B24))
                                    .border(1.dp, Color(0xFF332766), RoundedCornerShape(10.dp)),
                                contentAlignment = Alignment.Center
                            ) {
                                if (wp.posterUrl.isNotBlank()) {
                                    AsyncImage(
                                        model = wp.posterUrl,
                                        contentDescription = wp.title,
                                        modifier = Modifier.fillMaxSize(),
                                        contentScale = ContentScale.Crop
                                    )
                                } else {
                                    Icon(
                                        imageVector = if (isSeries) Icons.Default.LiveTv else Icons.Default.Theaters,
                                        contentDescription = null,
                                        tint = if (isSeries) Color(0xFF8B5CF6) else CeylanColor,
                                        modifier = Modifier.size(28.dp)
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.width(12.dp))

                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = if (isSeries) seriesName else wp.title,
                                    color = Color.White,
                                    fontSize = 13.5.sp,
                                    fontWeight = FontWeight.Black,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Spacer(modifier = Modifier.height(3.dp))
                                if (isSeries) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(
                                            imageVector = Icons.Default.PlayArrow,
                                            contentDescription = null,
                                            tint = Color(0xFF00E5FF),
                                            modifier = Modifier.size(13.dp)
                                        )
                                        Spacer(modifier = Modifier.width(3.dp))
                                        Text(
                                            text = episodeLabel,
                                            color = Color(0xFF00E5FF),
                                            fontSize = 12.sp,
                                            fontWeight = FontWeight.Bold,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                    }
                                } else {
                                    Text(
                                        text = "Reprendre la lecture du film",
                                        color = Color(0xFFA0A0C0),
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Medium
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        // Progress row: Arrêté à + LinearProgressIndicator
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Arrêté à $timeFormatted",
                                color = Color(0xFFA0A0C0),
                                fontSize = 11.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                            if (wp.durationMs > 0) {
                                val durSec = wp.durationMs / 1000
                                val dMin = durSec / 60
                                val dSec = durSec % 60
                                Text(
                                    text = String.format("%02d:%02d", dMin, dSec),
                                    color = Color(0xFF6B7280),
                                    fontSize = 10.5.sp,
                                    fontWeight = FontWeight.Normal
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(5.dp))

                        LinearProgressIndicator(
                            progress = { progressPercent },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(4.dp)
                                .clip(RoundedCornerShape(2.dp)),
                            color = if (isSeries) Color(0xFF00E5FF) else CeylanColor,
                            trackColor = Color(0xFF251D4A)
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun TvMoviesSection(viewModel: IptvViewModel) {
    val channels by viewModel.channels.collectAsState()
    val isMovieCategorySelected by viewModel.isMovieCategorySelected.collectAsState()
    val selectedCategory by viewModel.selectedCategory.collectAsState()
    val searchQuery by viewModel.searchQuery.collectAsState()
    val watchProgressList by viewModel.watchProgressList.collectAsState()

    val movies = remember(channels) {
        channels.filter { it.type.equals("Movie", ignoreCase = true) || it.type.equals("VOD", ignoreCase = true) }
    }

    val movieCategories = remember(movies) {
        listOf("Tous") + movies.map { it.groupName.trim() }.filter { it.isNotBlank() }.distinct().sorted()
    }

    val displayedMovies = remember(movies, selectedCategory, searchQuery) {
        movies.filter { movie ->
            val matchCat = selectedCategory == "Tous" || movie.groupName.equals(selectedCategory, ignoreCase = true)
            val matchQuery = searchQuery.isBlank() || movie.name.contains(searchQuery, ignoreCase = true)
            matchCat && matchQuery
        }
    }

    Box(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        if (movies.isEmpty()) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Default.PlayArrow, contentDescription = null, tint = Color(0xFF00E5FF), modifier = Modifier.size(64.dp))
                    Spacer(modifier = Modifier.height(16.dp))
                    Text("AUCUN FILM DISPONIBLE", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("Veuillez sélectionner ou importer une playlist contenant des films VOD.", color = Color.Gray, fontSize = 13.sp)
                }
            }
        } else if (!isMovieCategorySelected) {
            Column(modifier = Modifier.fillMaxSize()) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(bottom = 16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text("FILMS VOD / CATÉGORIES", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Black, letterSpacing = 1.sp)
                        Text("Sélectionnez une catégorie pour parcourir les films", color = Color(0xFF00E5FF), fontSize = 12.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 2.dp))
                    }
                    LiveClock()
                }

                LazyVerticalGrid(
                    columns = GridCells.Adaptive(minSize = 220.dp),
                    horizontalArrangement = Arrangement.spacedBy(16.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp),
                    modifier = Modifier.fillMaxSize()
                ) {
                    items(movieCategories) { cat ->
                        val count = if (cat == "Tous") movies.size else movies.count { it.groupName.equals(cat, ignoreCase = true) }
                        val isTous = cat == "Tous"

                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(120.dp)
                                .clickable {
                                    viewModel.selectCategory(cat)
                                    viewModel.setMovieCategorySelected(true)
                                }
                                .tvFocusable(
                                    focusedColor = Color(0xFF00E5FF),
                                    borderRadius = 18.dp,
                                    onClick = {
                                        viewModel.selectCategory(cat)
                                        viewModel.setMovieCategorySelected(true)
                                    }
                                ),
                            shape = RoundedCornerShape(18.dp),
                            colors = CardDefaults.cardColors(
                                containerColor = if (isTous) Color(0xFF0091EA) else Color(0xFF100D32)
                            ),
                            border = if (isTous) null else BorderStroke(1.2.dp, Color(0xFF261F58))
                        ) {
                            Box(modifier = Modifier.fillMaxSize().padding(18.dp)) {
                                Column(
                                    modifier = Modifier.fillMaxSize(),
                                    verticalArrangement = Arrangement.SpaceBetween
                                ) {
                                    if (isTous) {
                                        Text(
                                            text = "TOUS",
                                            color = Color.White,
                                            fontSize = 32.sp,
                                            fontWeight = FontWeight.Black,
                                            letterSpacing = 1.sp
                                        )
                                        Text(
                                            text = "$count Films",
                                            color = Color.White,
                                            fontSize = 18.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                    } else {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.Top
                                        ) {
                                            Text(
                                                text = cat,
                                                color = Color.White,
                                                fontSize = 18.sp,
                                                fontWeight = FontWeight.Bold,
                                                maxLines = 2,
                                                overflow = TextOverflow.Ellipsis,
                                                modifier = Modifier.weight(1f)
                                            )
                                            Spacer(modifier = Modifier.width(8.dp))
                                            Box(
                                                modifier = Modifier
                                                    .size(32.dp)
                                                    .background(Color(0xFF181344), shape = CircleShape),
                                                contentAlignment = Alignment.Center
                                            ) {
                                                Icon(
                                                    imageVector = Icons.Default.PlayArrow,
                                                    contentDescription = null,
                                                    tint = Color(0xFF00B0FF),
                                                    modifier = Modifier.size(18.dp)
                                                )
                                            }
                                        }
                                        Text(
                                            text = "$count Films",
                                            color = Color(0xFF00A2FF),
                                            fontSize = 15.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        } else {
            Column(modifier = Modifier.fillMaxSize()) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        Button(
                            onClick = { viewModel.setMovieCategorySelected(false) },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF161033), contentColor = Color.White),
                            border = BorderStroke(2.dp, Color(0xFF00E5FF)),
                            shape = RoundedCornerShape(16.dp),
                            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
                            modifier = Modifier.tvFocusable(
                                focusedColor = CeylanColor,
                                borderRadius = 16.dp,
                                onClick = { viewModel.setMovieCategorySelected(false) }
                            )
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.ArrowBack, contentDescription = "Retour", modifier = Modifier.size(16.dp), tint = Color(0xFF00E5FF))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("CATÉGORIES", fontSize = 12.sp, fontWeight = FontWeight.Black, color = Color(0xFF00E5FF))
                            }
                        }
                        Column {
                            Text("FILMS / ${selectedCategory.uppercase()}", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Black, letterSpacing = 0.5.sp)
                            Text("${displayedMovies.size} films disponibles", color = Color(0xFF00E5FF), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                    LiveClock()
                }

                LazyVerticalGrid(
                    columns = GridCells.Adaptive(minSize = 150.dp),
                    horizontalArrangement = Arrangement.spacedBy(14.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp),
                    modifier = Modifier.fillMaxSize()
                ) {
                    items(displayedMovies) { movie ->
                        val movieProgress = remember(movie, watchProgressList) {
                            watchProgressList.find { wp ->
                                wp.episodeId == movie.streamUrl ||
                                (wp.contentType.equals("movie", ignoreCase = true) && wp.title.equals(movie.name, ignoreCase = true))
                            }
                        }
                        val isMovieInProgress = movieProgress != null && movieProgress.positionMs > 5000L
                        val movieProgressPercent = if (movieProgress != null && movieProgress.durationMs > 0) {
                            (movieProgress.positionMs.toFloat() / movieProgress.durationMs.toFloat()).coerceIn(0f, 1f)
                        } else 0f

                        val handleMovieClick = {
                            val startPos = movieProgress?.positionMs ?: 0L
                            viewModel.selectChannel(
                                movie,
                                keepFullScreen = true,
                                skipResumeCheck = startPos > 0L,
                                startPositionMs = startPos
                            )
                        }

                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { handleMovieClick() }
                                .tvFocusable(
                                    focusedColor = CeylanColor,
                                    borderRadius = 16.dp,
                                    onClick = { handleMovieClick() }
                                ),
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = Color(0xFF161033)),
                            border = BorderStroke(1.5.dp, if (isMovieInProgress) CeylanColor else Color(0xFF332766))
                        ) {
                            Column {
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(190.dp)
                                        .background(Color(0xFF0C0721)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    if (movie.logoUrl.isNotBlank()) {
                                        AsyncImage(
                                            model = movie.logoUrl,
                                            contentDescription = movie.name,
                                            modifier = Modifier.fillMaxSize(),
                                            contentScale = ContentScale.Crop
                                        )
                                    } else {
                                        Icon(
                                            imageVector = Icons.Default.PlayArrow,
                                            contentDescription = null,
                                            tint = Color(0xFF00E5FF),
                                            modifier = Modifier.size(44.dp)
                                        )
                                    }

                                    // Badge if movie is in progress
                                    if (isMovieInProgress) {
                                        Box(
                                            modifier = Modifier
                                                .align(Alignment.TopEnd)
                                                .padding(8.dp)
                                                .background(CeylanColor, shape = RoundedCornerShape(6.dp))
                                                .padding(horizontal = 7.dp, vertical = 3.dp)
                                        ) {
                                            Text(
                                                text = "EN COURS",
                                                color = Color.White,
                                                fontSize = 9.sp,
                                                fontWeight = FontWeight.Black
                                            )
                                        }

                                        // Progress bar along bottom of poster
                                        LinearProgressIndicator(
                                            progress = { movieProgressPercent },
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .height(4.dp)
                                                .align(Alignment.BottomCenter),
                                            color = CeylanColor,
                                            trackColor = Color(0xFF251D4A)
                                        )
                                    }
                                }
                                Column(modifier = Modifier.padding(10.dp)) {
                                    Text(
                                        text = movie.name,
                                        color = Color.White,
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Bold,
                                        maxLines = 2,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    Spacer(modifier = Modifier.height(2.dp))
                                    if (isMovieInProgress && movieProgress != null) {
                                        val stoppedSec = movieProgress.positionMs / 1000
                                        val sMin = stoppedSec / 60
                                        val sSec = stoppedSec % 60
                                        Text(
                                            text = "Arrêté à %02d:%02d".format(sMin, sSec),
                                            color = Color(0xFF00E5FF),
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold,
                                            maxLines = 1
                                        )
                                    } else {
                                        Text(
                                            text = movie.groupName,
                                            color = Color(0xFFA0A0C0),
                                            fontSize = 11.sp,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
