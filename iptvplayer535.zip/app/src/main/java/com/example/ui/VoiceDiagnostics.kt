package com.example.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.SherpaSubtitleManager

/**
 * Petit bandeau de diagnostic (haut-gauche) affiché tant que les sous-titres vocaux sont activés
 * mais qu'aucun texte n'a encore été reconnu : état du modèle, format audio reçu du lecteur,
 * nombre de blocs audio reçus/décodés et niveau sonore. Disparaît dès qu'un sous-titre s'affiche.
 */
@Composable
fun VoiceDiagnosticsOverlay(enabled: Boolean) {
    if (!enabled) return
    val diag by SherpaSubtitleManager.diagnostics.collectAsState()
    val recognized by SherpaSubtitleManager.recognizedSpeechText.collectAsState()
    if (diag.isBlank() || !recognized.isNullOrBlank()) return
    Box(
        modifier = Modifier.fillMaxSize().padding(10.dp),
        contentAlignment = Alignment.TopStart
    ) {
        Text(
            text = diag,
            color = Color(0xFFFFE082),
            fontSize = 11.sp,
            modifier = Modifier
                .background(Color(0xAA000000), RoundedCornerShape(4.dp))
                .padding(horizontal = 6.dp, vertical = 3.dp)
        )
    }
}
