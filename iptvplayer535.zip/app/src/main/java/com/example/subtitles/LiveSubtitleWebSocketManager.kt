package com.example.subtitles

import android.graphics.Color
import android.graphics.Typeface
import android.os.Handler
import android.os.Looper
import android.util.Log
import androidx.media3.common.text.Cue
import androidx.media3.ui.CaptionStyleCompat
import androidx.media3.ui.SubtitleView
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import org.json.JSONObject
import java.net.URLEncoder
import java.util.concurrent.TimeUnit

data class LiveSubtitleData(
    val text: String,
    val start: Double,
    val end: Double,
    val isFinal: Boolean
)

/**
 * Client WebSocket haute performance pour le sous-titrage vocal Live Sherpa-ONNX.
 * Reçoit les chunks en streaming avec latence < 2s et alimente SubtitleView / PlayerView.
 */
class LiveSubtitleWebSocketManager(
    private val serverBaseWsUrl: String = "ws://192.168.1.100:8000" // Remplacer par l'IP de votre serveur Ubuntu
) {
    companion object {
        private const val TAG = "LiveSubtitleWs"
    }

    private val client = OkHttpClient.Builder()
        .pingInterval(10, TimeUnit.SECONDS)
        .connectTimeout(5, TimeUnit.SECONDS)
        .readTimeout(0, TimeUnit.MILLISECONDS)
        .build()

    private var webSocket: WebSocket? = null
    private val scope = CoroutineScope(Dispatchers.IO + Job())
    private val mainHandler = Handler(Looper.getMainLooper())

    private val _currentSubtitle = MutableStateFlow<LiveSubtitleData?>(null)
    val currentSubtitle: StateFlow<LiveSubtitleData?> = _currentSubtitle.asStateFlow()

    private var autoClearJob: Job? = null
    private var boundSubtitleView: SubtitleView? = null

    /**
     * Configure le style professionnel du SubtitleView (M3 / Broadcast TV standard)
     */
    fun attachSubtitleView(subtitleView: SubtitleView) {
        this.boundSubtitleView = subtitleView
        mainHandler.post {
            // Style : Texte blanc, fond noir semi-transparent (65%), contour net
            val customStyle = CaptionStyleCompat(
                Color.WHITE,                               // Couleur du texte
                Color.argb(165, 0, 0, 0),                  // Fond noir semi-transparent
                Color.TRANSPARENT,                         // Fond fenêtre
                CaptionStyleCompat.EDGE_TYPE_DROP_SHADOW,  // Ombre portée / contour
                Color.BLACK,                               // Couleur du contour
                Typeface.DEFAULT_BOLD                      // Police grasse lisible
            )
            subtitleView.setStyle(customStyle)
            subtitleView.setFractionalTextSize(0.045f) // 4.5% de la hauteur de l'écran
            subtitleView.setApplyEmbeddedStyles(false)
            subtitleView.setApplyEmbeddedFontSizes(false)
        }
    }

    fun detachSubtitleView() {
        this.boundSubtitleView = null
    }

    /**
     * Se connecte au WebSocket pour une chaîne donnée et démarre le flux.
     */
    fun startSubtitles(channelId: String, liveStreamUrl: String) {
        stopSubtitles()

        val encodedUrl = URLEncoder.encode(liveStreamUrl, "UTF-8")
        val wsUrl = "$serverBaseWsUrl/ws/subtitles/$channelId?url=$encodedUrl"
        Log.i(TAG, "Connexion au serveur de sous-titres : $wsUrl")

        val request = Request.Builder().url(wsUrl).build()

        webSocket = client.newWebSocket(request, object : WebSocketListener() {
            override fun onOpen(webSocket: WebSocket, response: Response) {
                Log.i(TAG, "WebSocket connecté pour chaîne $channelId")
            }

            override fun onMessage(webSocket: WebSocket, text: String) {
                try {
                    val json = JSONObject(text)
                    if (json.has("error")) {
                        Log.e(TAG, "Erreur serveur : ${json.getString("error")}")
                        return
                    }

                    val subText = json.optString("text", "").trim()
                    val start = json.optDouble("start", 0.0)
                    val end = json.optDouble("end", 0.0)
                    val isFinal = json.optBoolean("is_final", false)

                    if (subText.isNotEmpty()) {
                        val subData = LiveSubtitleData(subText, start, end, isFinal)
                        _currentSubtitle.value = subData
                        updateSubtitleView(subText, isFinal)
                    }
                } catch (e: Exception) {
                    Log.e(TAG, "Erreur parsing JSON sous-titre: ${e.message}")
                }
            }

            override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                Log.w(TAG, "WebSocket échec : ${t.message}. Tentative de reconnexion dans 3s...")
                scope.launch {
                    delay(3000)
                    if (this@LiveSubtitleWebSocketManager.webSocket != null) {
                        startSubtitles(channelId, liveStreamUrl)
                    }
                }
            }

            override fun onClosing(webSocket: WebSocket, code: Int, reason: String) {
                webSocket.close(1000, null)
            }
        })
    }

    private fun updateSubtitleView(text: String, isFinal: Boolean) {
        mainHandler.post {
            boundSubtitleView?.let { view ->
                val cue = Cue.Builder()
                    .setText(text)
                    .setTextSize(0.045f, Cue.TEXT_SIZE_TYPE_FRACTIONAL)
                    .build()
                view.setCues(listOf(cue))
            }
        }

        // Effacer automatiquement après 4 secondes de silence si phrase finale
        autoClearJob?.cancel()
        if (isFinal) {
            autoClearJob = scope.launch {
                delay(4000)
                mainHandler.post {
                    boundSubtitleView?.setCues(emptyList())
                }
                _currentSubtitle.value = null
            }
        }
    }

    fun stopSubtitles() {
        autoClearJob?.cancel()
        autoClearJob = null
        try {
            webSocket?.close(1000, "Arrêt demandé par le client")
        } catch (e: Exception) { }
        webSocket = null
        mainHandler.post {
            boundSubtitleView?.setCues(emptyList())
        }
        _currentSubtitle.value = null
    }
}
