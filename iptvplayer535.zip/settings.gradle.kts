pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
        maven { url = uri("https://alphacephei.com/maven/") }
        maven { url = uri("${rootDir}/repo") }
    }
}
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
        maven { url = uri("https://alphacephei.com/maven/") }
        maven { url = uri("${rootDir}/repo") }
        ivy {
            url = uri("https://github.com/k2-fsa/sherpa-onnx/releases/download/")
            patternLayout {
                artifact("v[revision]/[artifact]-[revision].[ext]")
            }
            metadataSources {
                artifact()
            }
        }
    }
}
rootProject.name = "Pro IPTV"
include(":app")
